function createElement(elementName, attributes, contents = null){
	var newElement = document.createElement(elementName);
	var attribute  = null;

	for(var attributeName in attributes){
		if(attributes.hasOwnProperty(attributeName)){
			attribute       = document.createAttribute(attributeName);
			attribute.value = attributes[attributeName];

			newElement.setAttributeNode(attribute);
		}
	}

	if(contents != null){
		if(contents instanceof Array){
			contents.forEach(function(content){
				appendNodeToElement(newElement, content);
			});
		}else{
			appendNodeToElement(newElement, contents);
		}
	}

	return newElement;
}

function toggleCollapsableNavigation(x){
	if(!x.matches){
		$("#nav-menu").collapse("show");
	} else {
		$("#nav-menu").collapse("hide");
	}
}

function setupHamburger(){
	var hamburger = document.querySelector(".hamburger");
	  
	hamburger.addEventListener("click", function() {
		hamburger.classList.toggle("is-active");
		$("#nav-menu").collapse("toggle");
  	});
}

function getLocation(href){
	var l = document.createElement("a");
	l.href = href;
	return l;
}

function setNavigation(){
	var path = window.location.pathname;
	path = path.replace(/\/$/, "");
	path = decodeURIComponent(path);

	$("#menu-items-ul li a").each(function(){
		var href = $(this).attr('href');
		
		if(href != "#"){
			href = getLocation(href).pathname;
		}

		if(path.substring(0, href.length) === href){
			$(this).closest('li').addClass('menu-item-li-selected');
		}
	});

	var x = window.matchMedia("(max-width: 991px)");
	toggleCollapsableNavigation(x);
	x.addListener(toggleCollapsableNavigation);
	setupHamburger();
}

$(document).ready(function(){
	setNavigation();
});
