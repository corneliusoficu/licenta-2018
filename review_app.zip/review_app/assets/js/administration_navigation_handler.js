function loadDataPage(event){
    var dataInfo = event.currentTarget.id;
    if(dataInfo){
        window.location.href = BASE_URL + "data/"+dataInfo;
    }
    
}

function handleRatingBoxes(settingsBoxes){
    
    $.each(settingsBoxes, function(key, value){
        $(value).on('click', loadDataPage);
    });
}

$(document).ready(function(){
    var settingsBoxes = $(".settings-cards-columns .card")
    handleRatingBoxes(settingsBoxes);
});