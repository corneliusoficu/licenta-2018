var statusMessage  = $("#status-message");
var actionSelect   = $("#action-select");
var dataTable      = $("#information-table");
var editModal      = $("#edit-modal");
var saveEditButton = $(".save-edit-information-button");

var tableName = null;

var tableAdditionalInformation = {
	columnNameStartIndex: 0,
	columnNameEndIndex: 0
};

function reloadDatatable(callback = null, resetPaging = false){
	dataTable.DataTable().ajax.reload(callback, resetPaging);
}

function appendNodeToElement(element, childElement){
	if(typeof childElement == "string"){
		childElement = document.createTextNode(childElement);
	}

	element.appendChild(childElement);
}

function handleSuccessfullDelete(response){
	swal("Succes!", "Resursa a fost stearsa cu succes!", "success");
	reloadDatatable();
}

function handleFailedDelete(response){
	var statusMessage = 'Eroare in stergerea resursei!';
	if(response && response.responseJSON && 'message' in response.responseJSON){
		statusMessage = response.responseJSON.message;
	}
	swal("Eroare!", statusMessage, "error");
}

function handleSuccessfulEdit(response){
	var statusMessage = 'message' in response ? response.message : "Resursa a fost modificate cu succes!";
	swal("Succes!",statusMessage, "success");
	reloadDatatable();
	$(editModal).modal('toggle');
}

function handleFailedEdit(response = null){

	var statusMessage = 'Eroare in modificarea resursei!';
	if(response && response.responseJSON && 'message' in response.responseJSON){
		statusMessage = response.responseJSON.message;
	}
	swal("Eroare!", statusMessage, "error");
	$(editModal).modal('toggle');
}

function sendEditInformation(resourceId){

	var editInputs = $(editModal).find('input, textarea').toArray();
	
	
	var reducer = (accumulator, currentValue) => { accumulator[currentValue.id] = $(currentValue).val(); return accumulator; };
	var editData = editInputs.reduce(reducer, {});

	if(tableName == null){
		return;
	}

	var endPoint = BASE_URL + 'data/update/' + tableName + '/' + resourceId;

	$.ajax({
        url:         endPoint,
        method:      'POST',
        ContentType: 'application/json',
        data:         editData,
        success:      handleSuccessfulEdit,
        error:        handleFailedEdit
    });
}

function sendDeleteRequest(resourceId){
	
	var endPoint = BASE_URL + 'data/delete/' + tableName + '/' + resourceId;
	$.ajax({
        url:         endPoint,
        method:      'DELETE',
        ContentType: 'application/json',
        success:      handleSuccessfullDelete,
        error:        handleFailedDelete
    });
}

function fillEditInformation(data, columnInformation){
	var modalBody = $(editModal).find('.modal-body');
	
	modalBody.html("");
	saveEditButton.unbind( "click" );

	for(dataKey in data){
		
		if (!(dataKey in columnInformation)){
			continue;
		}

		var columnData = columnInformation[dataKey];
		
		if(!("name"in columnData)){
			continue;
		}

		var columninfo = columnInformation[dataKey];

		var label      = createElement("label", {class: "control-label m-0"}, columnData["name"] + ': ');
		var labelCol   = createElement("div", {class: "col-lg-3 h-100"}, label);

		var dataEntry = data[dataKey] == null ? '' : data[dataKey];

		var element = "";

		if("type" in columnData){
			switch(columnData["type"]){
				case "bool":
					element = createElement("input", {type: "checkbox", id: dataKey});
					if(dataEntry == 1){
						element.setAttribute("checked", "checked");
						element.setAttribute("value", "1");
					} else {
						element.setAttribute("value", "0");
					}

					$(element).click(function(){
						if($(this).attr("value") == "1"){
							$(this).attr("value", "0");
						} else {
							$(this).attr("value", "1");
						}
					});
					break;
				case "number": //TODO: Implement input of type number
				case "string":
					element = createElement("input", {type: "text", class: "form-control", id: dataKey, value: dataEntry});
					break;
				case "textarea":
					element = createElement("textarea", {type: "text", class: "form-control", id: dataKey}, dataEntry);
					break;
				case "date":
					element = createElement("input", {type: "text", class: "form-control", id: dataKey, value: dataEntry});
					$(element).daterangepicker({
						startDate: dataEntry,
						singleDatePicker: true,
						locale: {
							format: 'YYYY-MM-DD'
						}
					});
			}
		} else {
			element = createElement("p", {}, dataEntry );
		}
		var inputGroupDiv = createElement("div", {class: "input-group"}, element);
		var inputCol      = createElement("div", {class: "col-lg-9"}, inputGroupDiv);

		var row = createElement("div", {class: "row p-1 inline-items-row"}, [labelCol, inputCol]);

		modalBody.append(row);
	}

	saveEditButton.click(function(event){
		if('DT_RowId' in data){
			sendEditInformation(data['DT_RowId']);
		}else{
			handleFailedEdit();
		}
	});

	editModal.modal();
}

function generatateColumnData(columnData){
	 
	const editButton   = '<i class="fas fa-edit mr-2 cursor-p edit-row-button"></i>';
	const deleteButton = '<i class="fas fa-trash-alt cursor-p delete-row-button"></i>';

	var indexColumnDef = {
		"searchable": false,
		"orderable": false,
		"targets": 0,
		"render": function(data,type,full,meta){
			return meta.settings._iDisplayStart + meta.row + 1;
		}
	};
	
	var actionsColumnDef = {
		"width": "10%",
		"orderable": false,
		"searchable": false,
		"className": "dt-center",
		"targets": -1,
		"render": function(data,type,full,meta){
			return editButton + deleteButton;
		}
	}

	var index = 1;

	tableAdditionalInformation.columnNameStartIndex = index;

	var columnDataInformation = Object.keys(columnData).map(x => ({
		"data": x,
		"targets": index++,
	}));

	tableAdditionalInformation.columnNameEndIndex = index - 1;

	columnDataInformation.push(indexColumnDef, actionsColumnDef);

	return columnDataInformation;
}

function loadDataTable(url, table_name, columnData){

	var table = dataTable.DataTable({
		"serverSide": true,
		"paging": true,
		"orderMulti": false,
		"ajax": {
			"url": url,
			"data": {
				"table": table_name
			}
		},
		"columnDefs": generatateColumnData(columnData),
		"order": [[ 1, 'asc' ]]
	});

	tableName = table_name;

	$(dataTable).on('click', 'td .edit-row-button', function(){
		var currentRow = table.row($(this).parents('tr'));
		var resourceId = currentRow.id();
		var data       = currentRow.data();
		var colHeader  = null;
		
		var index = 0;

		fillEditInformation(data, columnData)
	});

	$(dataTable).on('click', 'td .delete-row-button', function(){
		var resourceId = table.row($(this).parents('tr')).id();
		swal({
			title: "Sunteti sigur ca vreti sa stergeti aceasta resursa?",
			icon: "warning",
			buttons: {
				cancel: {
				  text: "Anuleaza",
				  value: false,
				  visible: true,
				},
				confirm: {
				  text: "Continua",
				  value: true,
				  closeModal: true
				}
			  },
			dangerMode: true,
		})
		.then(value => {
			if(value == true){
				sendDeleteRequest(resourceId);
			}
		});
	});

}

