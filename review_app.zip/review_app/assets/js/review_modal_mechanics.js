
var largeRatingSelections = null;
var smallRatingSelections = null;
var reviewInformation = null;

function changeToNumbers(x) {
    if(x.matches) {
        largeRatingSelections.hide();
        smallRatingSelections.show();
        reviewInformation.show();
    } else {
        largeRatingSelections.show();
        smallRatingSelections.hide();
        reviewInformation.hide();
    }
}

$(document).ready(()=>{

    $('.next').click(()=>{
        var nextId = $(".tab-pane.active.show").next().attr("id");
        $('[href=\'#'+nextId+'\']').tab('show');
        return false;
    });

    $('.previous').click(()=>{
        var prevId = $(".tab-pane.active.show").prev().attr("id");
        $('[href=\'#'+prevId+'\']').tab('show');
        return false;
    });

    $('#btn-close-modal').click(()=>{
        $('#review-form-modal').modal('toggle');
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {

        var step = $(e.target).data('step');
        var percent = (parseInt(step) / 5) * 100;
        
        $('.progress-bar').css({width: percent + '%'});
        $('.progress-bar').text(percent + '%');
    
    })

    $('#review-form-modal').on('hidden.bs.modal', function () {
        $('[href="#step1"').tab('show');
    });
});



