 var editButton = null;
 var saveButton = null;
 var cancelButton = null;
 var groupSelect2 = null;
 var groupDisplay = null;
 var loadingSpinner = null;

 const END_POINT_CHANGE_GROUP = BASE_URL + "registration/change_user_group"
 
 function createSelect2Item(defaultValue = null){
    if(!groupSelect2.data('select2')){
        groupSelect2.select2({
            width: '100px'
        });

        if(defaultValue != null){
            var defaultOption = new Option(defaultValue, defaultValue, true, true);
            groupSelect2.append(defaultOption).trigger('change');
        }
    } else {
        groupSelect2.show();
        groupSelect2.next(".select2-container").show();
    }
}

function createSelect(){

    var currentGroup = groupDisplay.text();
    
    if(!currentGroup){ currentGroup = null }
    
    createSelect2Item(currentGroup);

    editButton.hide();
    groupDisplay.hide();

    saveButton.show();
    cancelButton.show();

}

function restoreGroupDisplay(){
    saveButton.hide();
    cancelButton.hide();
    loadingSpinner.hide();

    editButton.show();
    groupSelect2.hide();
    groupSelect2.next(".select2-container").hide();

    groupDisplay.show();
}

function modifyGroupDisplay(response){
    var response = JSON.parse(response);
    if('new_group' in response){
        groupDisplay.text(response.new_group);
    }        
    restoreGroupDisplay();
}

function changeStudentGroup(){
    loadingSpinner.show();
    saveButton.hide();
    
    const data = {new_group: groupSelect2.val()};
    $.ajax({
        url:          END_POINT_CHANGE_GROUP,
        method:       "POST",
        data:         data,
        ContentType: 'application/json',
        success: modifyGroupDisplay,
        error:   restoreGroupDisplay
    });
}

$(document).ready(function(){

    editButton = $(".change-group-btn");
    saveButton = $(".save-group-btn");
    cancelButton = $(".cancel-group-btn");
    groupSelect2 = $(".group-select");
    groupDisplay = $("#student-group");
    loadingSpinner = $(".loading-spinner");

    editButton.click(createSelect);
    cancelButton.click(restoreGroupDisplay);
    saveButton.click(changeStudentGroup);
}); 