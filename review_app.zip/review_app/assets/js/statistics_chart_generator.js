// const chartist

const END_POINT_PROFESSORS_STATISTIC = BASE_URL + 'statistics/get_statistics_for_year';

function populate_chart(data) {
    if(data.length == 0){
        $('#teachers-reviews-nr-chart').hide();
        return;
    }
    data.sort(function(a, b){
        return parseInt(a.count) - parseInt(b.count);
    });

    var getFullName = (x) => {
        return  ((x.rank != null) ? x.rank : '') + x.full_name
    }

    labels = data.map(x => getFullName(x));
    values = data.map(x => ({meta: getFullName(x), value: parseInt(x.count)}));

    var labelsHeight = labels.length * 30;
    var containerHeight = $('#chartContainer').outerHeight();

    var chartSize = Math.max(labelsHeight, containerHeight) + 'px';

    $('#chartContainer').height(chartSize);

    new Chartist.Bar('#chartContainer', {
        labels: labels,
        series: [ values ]
      }, {
        seriesBarDistance: 1,
        reverseData: false,
        horizontalBars: true,
        height: chartSize,
        axisY: {
          offset: 150
        },
        axisX: {
            onlyInteger: true,
        },
        plugins: [
            Chartist.plugins.tooltip()
        ]
      });
}

function handle_error(error) {
    swal({
        title: "Eroare!",
        text: "Statisticile nu au putut fi obtinute!",
        icon: "error",
        button: "OK",
      });
}

function get_teachers_nr_reviews_statistic() {
    $.ajax({
        url:     END_POINT_PROFESSORS_STATISTIC,
        method:  "GET",
        ContentType: 'application/json',
        success: populate_chart,
        error:   handle_error
    });
}

$(document).ready(()=>{
    
    var teachersNrReviewsPerYear = $("#chartContainer");
    if(teachersNrReviewsPerYear.length){
        get_teachers_nr_reviews_statistic();
    }
});
