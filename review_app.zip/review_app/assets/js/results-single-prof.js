var changeProfBtn, cancelChangeProfBtn, setProfBtn;
var profText;
var profSelect;

function display_chartist_line_chart(container, data){
    $(container).height('400px');

    var options = {
        showArea: true,
        chartPadding: {
            top: 20,
            left: 20,
            bottom: 50
        },
        plugins: [
            Chartist.plugins.ctPointLabels({
                textAnchor: 'middle'
            })
        ]
    };

    new Chartist.Line(container, data, options);
}

function displayAvgGradeEvolutionChart(evolution){

    if(evolution.length == 0){
        $("#avg-grade-ev-container").hide();
        return;
    }

    $("#avg-grade-ev-container").show();

    var data = {
        labels: evolution.map(x=>x.year_period.replace(/\s/g,'')+' Sem.'+x.semester),
        series: [
            evolution.map(x=>x.avg_grade)
        ]
    }

    display_chartist_line_chart("#avg-grade-ev-chart", data);
}

function displayAverageParticipationEvolutionChart(evolution){
    
    if(evolution.length == 0){
        $("#avg-participation-ev-container").hide();
        return;
    }

    // evolution = evolution.filter(ev=>ev.avg_participated > 0);

    $("#avg-participation-ev-container").show();

    var data = {
        labels: evolution.map(x=>x.year_period.replace(/\s/g,'')+' Sem.'+x.semester),
        series: [
            evolution.map(x=>{
                if(x.avg_participated == 0){
                    return 0;
                }else{
                    return x.avg_participated;
                }
            })
        ]
    }
    display_chartist_line_chart("#avg-paticipation-ev-chart", data);

}

function displayNrEvaluationsEvolutionChart(evolution){
    if(evolution.length == 0){
        $("#nr-evals-container").hide();
        return;
    }

    $("#nr-evals-container").show();

    var data = {
        labels: evolution.map(x=>x.year_period.replace(/\s/g,'')+' Sem.'+x.semester),
        series: [
            evolution.map(x=>x.nr_evals)
        ]
    }

    display_chartist_line_chart("#nr-evals-chart", data);
}

function getAvgGradeEvolutionForProfessor(){
    $.ajax({
        url: BASE_URL + 'professors/avg_grade_evolution?prof_id='+PROF_ID,
        success: displayAvgGradeEvolutionChart,
        error: function(){$("#avg-grade-ev-container").hide();},
        dataType: 'json',
    })
}

function getAvgParticipationForProfessor(){
    $.ajax({
        url: BASE_URL + 'professors/avg_participation?prof_id='+PROF_ID,
        success: displayAverageParticipationEvolutionChart,
        error: function(){$("#avg-participation-ev-container").hide();},
        dataType: 'json'
    })
}

function getNrEvalsEvolutionForProfessor(){
    $.ajax({
        url: BASE_URL + 'professors/nr_evals_evolution?prof_id='+PROF_ID,
        success: displayNrEvaluationsEvolutionChart,
        error: function(){$("#nr-evals-container").hide();},
        dataType: 'json'
    });
}

function displayProfessorEditInformation(){
    changeProfBtn.toggle();
    cancelChangeProfBtn.toggle();
    setProfBtn.toggle();

    profText.toggle();
    
    profSelect.select2({
        width: '300px'
    });
    profSelect.toggle();
}

function restoreProfessorNameDisplay(){
    changeProfBtn.toggle();
    cancelChangeProfBtn.toggle();
    setProfBtn.toggle();
    profText.toggle();
    profSelect.toggle();
    profSelect.next(".select2-container").toggle();
}

$(document).ready(function(){
    changeProfBtn       = $("#change-prof-btn");
    cancelChangeProfBtn = $("#cancel-change-prof-btn");
    setProfBtn          = $("#save-prof-btn");

    profText   = $("#prof-name-text");
    profSelect = $("#professor-select");

    changeProfBtn.click(displayProfessorEditInformation);
    cancelChangeProfBtn.click(restoreProfessorNameDisplay);

    $("#professors-table-link").click(function(){
        window.location = BASE_URL + 'professors/professors-results?period='+EV_PERIOD_ID;
    });

    setTimeout(getAvgGradeEvolutionForProfessor, 50);
    setTimeout(getAvgParticipationForProfessor, 100);
    setTimeout(getNrEvalsEvolutionForProfessor, 150);
});