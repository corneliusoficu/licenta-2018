var navRequestTypes = null;
var professorSelect = null;
var professorsGroupSelects = null;

function setupSelect2Elements(){
    $(professorSelect).each(function(index, select){
        var endPoint = BASE_URL + 'professors/search';
        if($(select).hasClass('all-professors')){
            endPoint += '/all';
        }else{
            endPoint += '/unselected';
        }
        $(select).select2({
            ajax:{
                url: endPoint,
                dataType: 'json',
                delay: 500
            },
            width: '100%',
            
        });
    });

    $(professorsGroupSelects).each(function(index, select){
        $(select).select2({
            width: '100%'
        });
    });
}

function createTeacherAccount(email, accountId, adminGroup, requestId){
    if(!accountId || !email){
        swal("Eroare!", "Trebuie sa specificati un cont de profesor si un email!", "error");
        return;
    }

    $.ajax({
        url: BASE_URL + 'professors/approve_professor_request',
        method: "POST",
        data: {email: email, accountId: accountId, adminGroup: adminGroup, id: requestId},
        success: function(response){ 
            location.reload(); 
        },
        error: function(response){ swal("Eroare!", "Eroare in trimitearea cererii", "error"); }
    })
}

function aproveRequest(event){
    var table      = $(this).parent().find('.request-information-table');
    var email      = table.find('.request-email').html();
    var accountId  = table.find('.professor-account-select').val();
    var adminGroup = table.find('.professor-group-select').val();
    var requestId  = $(this).parent().find(".request-id").text();
 
    swal({
        title: "Sunteti sigur ca vreti sa creati acest cont?",
        text: "Se va trimite un email catre contul specificat si profesorul va putea intra in aplicatie!",
        icon: "warning",
        buttons: [
            "Anulati",
            "Acceptati"
        ]
    }).then((response) => {
        if (response) {
            createTeacherAccount(email, accountId, adminGroup, requestId);
        }
    });

    console.log(email, accountId);
}

function sendDeclineRequest(requestId){
    $.ajax({
        url: BASE_URL + 'professors/decline_professor_request',
        method: "POST",
        data: {id: requestId},
        success: function(response) {
            location.reload(); 
        },
        error: function(response){ swal("Eroare!", "Eroare in repingerea cererii", "error"); }
    });
}

function declineRequest(event){
    var table = $(this).parent().find('.request-information-table');
    var requestId = $(this).parent().find(".request-id").text();
    
    swal({
        title: "Sunteti sigur ca vreti sa respingeti aceasta cerere?",
        icon: "warning",
        buttons: [
            "Anulati",
            "Respingeti"
        ],
        dangerMode: true
    }).then((response) => {
        if (response) {
            sendDeclineRequest(requestId);
        }
    });
}

function setupActiveRequestTypeNav(){
    
    var path = window.location.pathname;
	path = path.replace(/\/$/, "");
	path = decodeURIComponent(path);

    navRequestTypes.each(function(index, navItem){
        var href = $(navItem).attr('href');

        if(href != "#"){
			href = getLocation(href).pathname;
        }
        
        if(path.substring(0, href.length) === href){
			$(navItem).addClass('active');
		}
    });
}

function changeToPendingRequest(){
    var requestId = $(this).parent().find(".request-id").text();

    $.ajax({
        url: BASE_URL + 'professors/change_request_to_pending',
        method: "POST",
        data: {id: requestId},
        success: function(response) {
            location.reload(); 
        },
        error: function(response){ swal("Eroare!", "Eroare in mutarea cererii in asteptare!", "error"); }
    });

}

$(document).ready(function(){
    navRequestTypes        = $(".nav-item .nav-link");
    professorSelect        = $(".professor-account-select");
    professorsGroupSelects = $(".professor-group-select");

    setupActiveRequestTypeNav();
    setupSelect2Elements();

    $('.aprove-request-btn').click(aproveRequest);
    $('.decline-request-btn').click(declineRequest);
    $('.change-to-pending-request-btn').click(changeToPendingRequest);
});