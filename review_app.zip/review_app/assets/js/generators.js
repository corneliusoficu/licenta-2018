
const RO_DAYS_OF_WEEK = ["Du", "Lu", "Ma", "Mi", "Jo", "Vi", "Sa"];
const RO_MONTHS       = ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"];

$(document).ready(function(){
    const periodSelectionInput = $("#periodSelectionInput");
    periodSelectionInput.daterangepicker({
        locale: {
            cancelLabel: 'Anuleaza',
            applyLabel: 'Confirma',
            firstDay: 1,
            format: 'DD-MM-YYYY',
            "daysOfWeek": RO_DAYS_OF_WEEK,
            "monthNames": RO_MONTHS
        }
    });

    const uploadDiv = $('#upload-div');
    const uploadInput = uploadDiv.find('input[type="file"]');

    $('input.form-check-input[value="old_scraper_upload"]').on('click', (event)=>{
        uploadDiv.css('visibility','visible');
        uploadInput.prop("disabled", false);
        
    });

    $('input.form-check-input[value!="old_scraper_upload"]').on('click', (event)=>{
        uploadDiv.css('visibility','hidden');
        uploadInput.prop("disabled", true);
    });
});

