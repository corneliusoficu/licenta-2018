const CARD_SUBJECT_QUERY   = "#subject";
const CARD_TYPE_QUERY      = "#type";
const CARD_PROFESSOR_QUERY = "#professor";

const MODAL_SUBJECT_QUERY      = "#evaluation-information #subject";
const MODAL_TYPE_QUERY         = "#evaluation-information #type";
const MODAL_PROFESSOR_QUERY    = "#evaluation-information #professor";
const MODAL_TIMETABLE_ID_QUERY = "#timetable-id";
const END_POINT                = BASE_URL + "evaluation/new_review";

const SELECTED_BOX_CLASS = "rating-box-selected";
const SELECTED_SMALL_BOX_CLASS = "rating-box-id-selected";

const ERROR_NOT_ALL_REVIEWED              = "Trebuie sa raspunzi la toate intrebarile!";
const ERROR_TIMES_PARTICIPATED_NOT_FILLED = "Trebuie sa selectezi la cate seminarii/cursuri ai participat!";

var modalForm;            
var review_cards;         
var ratingBoxes;
var smallRatingBoxes;
var largeRatingSelection;
var smallRatingSelection;
var reviewInformation;
var lastBox;              
var sendReviewButton;     
var questionAnswerGroups; 
var reviewErrorText;      
var currentTimetableId;   
var searchInput;          
var reviewBoxesContainer;

var currentDimension = null;
var debounceTimeout  = null;

function handleRatingBoxes(ratingBoxes){
    
    $.each(ratingBoxes, function(key, value){
        $(value).on('click', function(){
            var parent = $(this).parent();
            var selectedBoxes = $(parent).find('.'+SELECTED_BOX_CLASS);

            if($(selectedBoxes).length > 0){
                $.each(selectedBoxes, function(key_sel_box, value_sel_box){
                    $(value_sel_box).removeClass(SELECTED_BOX_CLASS);
                });
            }

            if(!$(this).hasClass(SELECTED_BOX_CLASS)){
                $(this).addClass(SELECTED_BOX_CLASS);
            }
        });
    });
}

function handleSmallRatingBoxes(smallRatingBoxes){
    
    $.each(smallRatingBoxes, function(key, value){
        $(value).on('click',function(){
            var parent = $(this).parent();
            var selectedBoxes = $(parent).find('.'+SELECTED_BOX_CLASS);

            if($(selectedBoxes).length > 0){
                $.each(selectedBoxes, function(key_sel_box, value_sel_box){
                    $(value_sel_box).removeClass(SELECTED_BOX_CLASS);
                });
            }

            if(!$(this).hasClass(SELECTED_BOX_CLASS)){
                $(this).addClass(SELECTED_BOX_CLASS);
            }
        });
    });
}

function resetModal(ratingBoxes, reviewErrorText){
    $.each(ratingBoxes, function(key, value){
        if($(value).hasClass(SELECTED_BOX_CLASS))
            {
                $(value).removeClass(SELECTED_BOX_CLASS);
            }
    });

    $.each(smallRatingBoxes, function(key, value){
        if($(value).hasClass(SELECTED_BOX_CLASS))
            {
                $(value).removeClass(SELECTED_BOX_CLASS);
            }
    });

    $('#positive-remark').val('');
    $('#negative-remark').val('');
    $('#times-participated').val($('#times-participated option:first').val());

    $(reviewErrorText).hide();
}

function getReviewResults(questionAnwerGroups, currentTimetableId){

    var reviewResult               = {
        timetableId: currentTimetableId,
        questionAnswers: [],
        timesParticipated: '-',
        remarks: {
            positive: "",
            negative: ""
        }
    };

    $.each(questionAnwerGroups, function(key, value){

        var questionId        = $(value).find(".question-label").attr('id');
        
        var questionSelection = null;
        if(currentDimension == "large"){
            questionSelection = $(value).find(".rating-selection");
        } else {
            questionSelection = $(value).find(".small-rating-selection");
        }
        

        var ratingValue = $(questionSelection).find("."+SELECTED_BOX_CLASS).first().attr('id');

        if(ratingValue !== undefined)
        {
            var questionAnswer = {
                "questionId":     questionId,
                "questionAnswer": ratingValue
            }
            reviewResult.questionAnswers.push(questionAnswer);
        }
    });

    var positiveRemark = $("#positive-remark").val();
    var negativeRemark = $("#negative-remark").val();

    if(positiveRemark){
        reviewResult.remarks.positive = positiveRemark;
    }

    if(negativeRemark){
        reviewResult.remarks.negative = negativeRemark;
    }

    reviewResult.timesParticipated = $('#times-participated').val();

    if(questionAnwerGroups.length != reviewResult.questionAnswers.length){
        console.log(questionAnwerGroups.length, reviewResult.questionAnswers.length);
        return -1;
    } else if(reviewResult.timesParticipated === '-') {
        return -2;
    } else {
        return reviewResult;
    }
}

function handleSuccessfulReview(){

    var idRow = $(lastBox).find(".card-id-content");
    var checkMark = createElement("i", {class: "far fa-check-circle already-reviewed-check"});
    idRow.append(checkMark);

    $(lastBox).removeClass('subject-card');
    $(lastBox).unbind( "click" );

    swal({
        title: "Evaluare salvata!",
        text: "Multumim pentru feedback-ul furnizat!",
        icon: "success",
        button: "OK",
    });
}

function handleFailedReview(response){
    swal({
        title: "Eroare!",
        text: response.responseText,
        icon: "error",
        button: "OK",
      });
}

function removeAllChildren(element){

    while(element.hasChildNodes()){
        element.removeChild(element.lastChild);
    }
}

function sendReviewResult(reviewResult){

    var postData = {
        'reviewResult': reviewResult
    };

    $.ajax({
        url:     END_POINT,
        method:  "POST",
        ContentType: 'application/json',
        data:    postData,
        success: handleSuccessfulReview,
        error:   handleFailedReview
    });
}

function createNewReviewCard(reviewCardInformation){
    var cardDiv = document.createElement("div");
    cardDiv.classList.add("card", "d-flex", "flex-column", "justify-content-between");

    var cardBlockDiv = document.createElement("div");
    cardBlockDiv.classList.add("card-body", "card-subject-content", "text-center"); 

    var cardBlockForIdDiv = document.createElement("div");
    cardBlockForIdDiv.classList.add("card-body", "card-id-content", "text-right"); 

    var subjectH4 = document.createElement("h4");
    subjectH4.classList.add("card-title"); 
    subjectH4.id = 'subject';
    subjectH4.innerHTML = reviewCardInformation["subject"];

    var smallText = document.createElement("small");
    smallText.classList.add("text-muted");
    smallText.innerHTML = reviewCardInformation['type']; 

    var typeP = document.createElement("p");
    typeP.classList.add("card-text"); 
    typeP.id = 'type';
    typeP.appendChild(smallText); 

    var professorP = document.createElement("p");
    professorP.classList.add('card-text');
    professorP.id = 'professor';
    professorP.innerHTML = ((reviewCardInformation['rank'] != null) ? reviewCardInformation['rank'] : '') + ' ' + reviewCardInformation['full_name'];

    var timetableIdP = document.createElement("p");
    timetableIdP.innerHTML = reviewCardInformation['id'];
    timetableIdP.id = 'timetable-id';
    timetableIdP.setAttribute("hidden", "");

    cardBlockDiv.appendChild(subjectH4);
    cardBlockDiv.appendChild(typeP);
    cardBlockDiv.appendChild(professorP);

    cardBlockForIdDiv.appendChild(timetableIdP);

    if(reviewCardInformation.already_reviewed !== "1"){
        cardDiv.classList.add("subject-card");
    }else{
        var checkedMark = createElement("i", {class: "far fa-check-circle ml-auto already-reviewed-check", align: "right"});
        cardBlockForIdDiv.appendChild(checkedMark);
    }

    cardDiv.appendChild(cardBlockDiv);
    cardDiv.appendChild(cardBlockForIdDiv);

    return cardDiv;
}

function fillReviewBoxes(reviewsInformation){
    
    if(reviewsInformation.length > 0){
        removeAllChildren(reviewBoxesContainer);
        reviewsInformation.forEach(function(element){

            var newCard = createNewReviewCard(element);
            if(element.already_reviewed !== "1"){
                $(newCard).on('click', onClickReviewBoxHandler);
            }
            reviewBoxesContainer.appendChild(newCard);
        });
    }
}

function executeAjaxRequest(urlDest, method, callbackFunctionSuccess){
    $.ajax({
        url:    urlDest,
        method: method
    }).done(callbackFunctionSuccess);
}

function requestReviewInformation(){

    var searchURL = BASE_URL + "evaluation/get_reviews_for_query?q=";
    var inputMessage = $(this).val();

    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(function(){
        executeAjaxRequest(searchURL + inputMessage, "GET", fillReviewBoxes);
    }, 500);
}

function onClickReviewBoxHandler(){
    var subject     = $(this).find(CARD_SUBJECT_QUERY).text();
    var type        = $(this).find(CARD_TYPE_QUERY).text();
    var professor   = $(this).find(CARD_PROFESSOR_QUERY).text();

    $(modalForm).find(MODAL_SUBJECT_QUERY).text(subject);
    $(modalForm).find(MODAL_TYPE_QUERY).text(type);
    $(modalForm).find(MODAL_PROFESSOR_QUERY).text(professor);

    currentTimetableId = $(this).find(MODAL_TIMETABLE_ID_QUERY).text();

    if(lastBox != this){
        resetModal(ratingBoxes, reviewErrorText);
        lastBox = this;
    }
    
    modalForm.modal();
}

function detectScreenSize(x){
    if(x.matches){
        largeRatingSelection.hide();
        smallRatingSelection.show();
        reviewInformation.show();
        currentDimension = "small";
    }else{
        largeRatingSelection.show();
        smallRatingSelection.hide();
        reviewInformation.hide();
        currentDimension = "large";
    }
}

$(document).ready(function(){
    modalForm            = $("#review-form-modal");
    review_cards         = $(".subject-card");
    largeRatingSelection = $(".rating-selection");
    smallRatingSelection = $(".small-rating-selection");
    ratingBoxes          = $(".rating-box");
    smallRatingBoxes     = $(".rating-box-id");
    lastBox              = null;
    sendReviewButton     = $("#btn-send-review");
    questionAnswerGroups = $(".question-answer-group");
    reviewErrorText      = $("#review-form-error");
    currentTimetableId   = null;
    searchInput          = $("#review-search-input");
    reviewBoxesContainer = $("#review-boxes-container")[0];
    reviewInformation    = $(".review-information");

    $.each(review_cards, function(key, value){
        $(value).on('click', onClickReviewBoxHandler);
    });

    handleRatingBoxes(ratingBoxes);
    handleSmallRatingBoxes(smallRatingBoxes);

    $(sendReviewButton).on('click', function(){
        var reviewResults = getReviewResults(questionAnswerGroups, currentTimetableId);
        console.log(reviewResults);
        if(reviewResults === -1){   
            $(reviewErrorText).text(ERROR_NOT_ALL_REVIEWED);
            $(reviewErrorText).show();
        }else if(reviewResults === -2){
            $(reviewErrorText).text(ERROR_TIMES_PARTICIPATED_NOT_FILLED);
            $(reviewErrorText).show();
        }else{
            $(modalForm).modal('hide');
            $(reviewErrorText).hide();
            sendReviewResult(reviewResults);
        }
    });

    var x = window.matchMedia("(max-width: 991px)");
    detectScreenSize(x);
    x.addListener(detectScreenSize);

    $(searchInput).on("paste keyup", requestReviewInformation);
});
