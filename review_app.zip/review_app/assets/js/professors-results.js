const ENDPOINT_PROFESSORS_GENERAL_STATS = BASE_URL + 'professors/general-statistics';

function setupTable(){
    $('#professors-table').DataTable({
        "paging": true,
        "columnDefs": [{
            "targets": -1,
            "searchable": false,
            "orderable": false
        }]
    });
}

$(document).ready(function(){
    setupTable();
});