var changeEvPeriodBtn, cancelEvPeriodSelectionBtn, submitEvPeriodBtn;
var evPeriodText;
var evPeriodSelect;

function displayEvPeriodEditInformation(){
    changeEvPeriodBtn.toggle();
    cancelEvPeriodSelectionBtn.toggle();
    submitEvPeriodBtn.toggle();
    evPeriodText.toggle();
    
    evPeriodSelect.select2({
        width: '300px'
    });
    evPeriodSelect.toggle();
}

function restoreEvPeriodDisplay(){
    changeEvPeriodBtn.toggle();
    cancelEvPeriodSelectionBtn.toggle();
    submitEvPeriodBtn.toggle();
    evPeriodText.toggle();
    evPeriodSelect.toggle();
    evPeriodSelect.next(".select2-container").toggle();
}

function setupDistributionChart(container, distr){
    var labelsBachelor = distr.bachelor.map(x =>{
        x.year = 'Anul ' + x.year;
        return x;
    });
    if(!('master' in distr) || !('bachelor' in distr)){
        $("#evaluation-year-distribution").hide();
        return;
    }
    var distr = labelsBachelor.concat(distr.master);
    distr.sort((a, b)=>{
        return a.number - b.number;
    });

    var labels = distr.map(x=>{return x.year});
    var series = distr.map((x, index)=>{return {meta: labels[index], value: x.number}});

    var data = {
        labels: labels,
        series: series
    };

    console.log(data);

    var labelsHeight = distr.length * 40;
    var containerHeight = $(container).outerHeight();
    var chartSize = Math.max(labelsHeight, containerHeight) + 'px';

    $(container).height(chartSize);

    var options = {
        horizontalBars: true,
        height: chartSize,
        distributeSeries: true,
        chartPadding: 50,
        axisY: {
            offset: 70
        },
        plugins: [
            Chartist.plugins.tooltip(),
        ],
    };

    new Chartist.Bar(container, data, options);
}

function setupNrEvalsEvolutionGraph(container, data, onlyInteger = true){
    
    $(container).height('400px');

    // evolution = [
    //     {year_period: '2009-2010', semester: "1", nr_reviews: 1430},
    //     {year_period: '2009-2010', semester: "2", nr_reviews: 1000},
    //     {year_period: '2010-2011', semester: "1", nr_reviews: 600},
    //     {year_period: '2010-2011', semester: "2", nr_reviews: 800},
    //     {year_period: '2011-2012', semester: "1", nr_reviews: 1000},
    //     {year_period: '2011-2012', semester: "2", nr_reviews: 950},
    //     {year_period: '2012-2013', semester: "1", nr_reviews: 840},
    //     {year_period: '2012-2013', semester: "2", nr_reviews: 652},
    //     {year_period: '2013-2014', semester: "1", nr_reviews: 1320},
    //     {year_period: '2013-2014', semester: "2", nr_reviews: 800},
    //     {year_period: '2014-2015', semester: "1", nr_reviews: 800},
    //     {year_period: '2014-2015', semester: "2", nr_reviews: 500},
    //     {year_period: '2016-2017', semester: "1", nr_reviews: 600},
    //     {year_period: '2016-2017', semester: "2", nr_reviews: 400},
    //     {year_period: '2017-2018', semester: "1", nr_reviews: 1320},
    //     {year_period: '2017-2018', semester: "2", nr_reviews: 980}
    // ];
    
    var options = {
        axisY: {
            onlyInteger: onlyInteger,
        },
        showArea: true,
        chartPadding: {
            top: 20,
            left: 20,
            bottom: 100
        },
        plugins: [
            Chartist.plugins.ctPointLabels({
                textAnchor: 'middle'
            })
        ]
    }

    new Chartist.Line(container, data, options);

    var chartLabels = $(container).find('.ct-label');
    console.log(chartLabels);
}

function setupCharts(){
    if(typeof distribution !== 'undefined'){
        setupDistributionChart("#evaluation-distribution", distribution);
    }

    if(typeof nrReviewsEvolution !== 'undefined'){
        var data = {
            labels: nrReviewsEvolution.map(x=>x.year_period.replace(/\s/g,'') + ' Sem.' + x.semester),
            series: [
                nrReviewsEvolution.map(x=>x.nr_reviews),
            ]
        };
    
        setupNrEvalsEvolutionGraph("#nr-reviews-evolution", data);
    }

    if(typeof avgGradeEvolution !== 'undefined'){
        var data = {
            labels: avgGradeEvolution.map(x=>x.year_period.replace(/\s/g,'') + ' Sem.' + x.semester),
            series: [
                avgGradeEvolution.map(x=>x.avg_grade),
            ]
        };
        setupNrEvalsEvolutionGraph("#avg-grade-evolution", data, false);
    }
    
}

$(document).ready(function(){
    changeEvPeriodBtn = $("#change-ev-period-btn");
    cancelEvPeriodSelectionBtn = $("#cancel-ev-period-selection-btn");
    submitEvPeriodBtn = $("#save-ev-period-selection-btn");

    evPeriodText   = $("#ev-period-text");
    evPeriodSelect = $("#ev-period-selection-select");
    
    changeEvPeriodBtn.click(displayEvPeriodEditInformation);
    cancelEvPeriodSelectionBtn.click(restoreEvPeriodDisplay);

    setupCharts();
});