var loginButton = null;
var form = null;

function animateLoading(){
    loginButton.html("Incarcare...");
    loginButton.css('cursor', 'auto');
    loginButton.attr("disabled", "disabled");


}

$(document).ready(function(){
    loginButton = $("#login-submit-button");
    form = $("#login-form");
    form.submit(animateLoading);
});

