$(document).ready(function(){
    var groupSelect = $(".select-group").first();
    groupSelect.select2({
        width: '75px'
    });
});