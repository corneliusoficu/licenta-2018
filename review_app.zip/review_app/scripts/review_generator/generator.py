import random

import db

MAX_NR_REVIEWS_PER_TIMETABLE_ENTRY = 5
MIN_NR_REVIEWS_PER_TIMETABLE_ENTRY = 1


def main():
	questions = db.session.query(db.Question).all()
	size_questions = len(questions)

	review_values = db.session.query(db.ReviewValue).all()
	size_review_values = len(review_values)

	timetable_entries = db.session.query(db.Timetable).all()

	index_review = 1

	try:

		for timetable_entry in timetable_entries:
			nr_reviews = random.randint(MIN_NR_REVIEWS_PER_TIMETABLE_ENTRY, MAX_NR_REVIEWS_PER_TIMETABLE_ENTRY)
			for review_index in range(0, nr_reviews):
				new_review = db.Review(timetable_entry_id=timetable_entry.id_subject)
				db.session.add(new_review)
				db.session.flush()
				for question_index in range(0, size_questions):
					question = questions[question_index]
					review_value_index = random.randint(0, size_review_values - 1)
					review_result = review_values[review_value_index]

					new_answer = db.Response(review_id = new_review.review_id, question_id = question.id, review_result = review_result.id)
					db.session.add(new_answer)

					print("# %d ---------------------------------------------------------------------------------\n" % (index_review) +
						  "Review no: %d / %d | Question no: %d / %d\n" % (review_index + 1, nr_reviews, question_index + 1, size_questions) +
						  "Subject: %s  | Teacher: %s | Group: %s | Type: %s\n" % (timetable_entry.subject, timetable_entry.professor.full_name, timetable_entry.group, timetable_entry.type) +
						  "Question: %s | Grade: %s" % (question.question_text, review_result.value))
					index_review += 1

		db.session.commit()
	except Exception as e:
		print(e)
		db.session.rollback()
	finally:
		db.session.close()



if __name__ == "__main__":
	main()
