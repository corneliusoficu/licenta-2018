from sqlalchemy import *
from sqlalchemy.orm import create_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from sqlalchemy.orm import contains_eager, joinedload
from sqlalchemy.orm import relationship

MYSQL_CONNECTION_STRING = 'mysql+mysqlconnector://root:root@localhost:3306/evaluation'

Base = declarative_base()
engine = create_engine(MYSQL_CONNECTION_STRING, echo=True)
metadata = MetaData(bind=engine)
Session = sessionmaker(bind=engine)
session = Session()


class Professor(Base):
	__table__ = Table('professors', metadata, autoload=True)


class Timetable(Base):
	__table__ = Table('timetable', metadata, autoload=True)
	professor = relationship('Professor', backref='timetable')


class ReviewValue(Base):
	__table__ = Table('review_values', metadata, autoload=True)


class Question(Base):
	__table__ = Table('questions', metadata, autoload=True)


class Response(Base):
	__table__ = Table('responses', metadata, autoload=True)


class Review(Base):
	__table__ = Table('reviews', metadata, autoload=True)
	responses = relationship("Response", backref="reviews")
