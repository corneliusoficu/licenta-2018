import re
import db

import datetime

professors_tables = [
	'profesori2009_2010_sem1',
	'profesori2009_2010_sem2',
	'profesori2010_2011_sem1',
	'profesori2010_2011_sem2',
	'profesori2011_2012_sem1',
	'profesori2012_2013_sem1',
	'profesori2012_2013_sem2',
	'profesori2013_2014_sem1',
	'profesori2013_2014_sem2',
	'profesori2014_2015_sem1',
	'profesori2014_2015_sem2',
	'profesori2015_2016_sem1',
	'profesori2015_2016_sem2',
	'profesori2016_2017_sem1',
	'profesori2016_2017_sem2',
	'profesori2017_2018_sem1'
]

professors_contents = {}
all_profs_from_db = []


def determine_ev_period_interval(professors):
	min_date = datetime.date(2099, 12, 12)
	max_date = datetime.date(1970,  1,  1)
	for professor in professors:
		if professor.data < min_date:
			min_date = professor.data
		if professor.data > max_date:
			max_date = professor.data
	return min_date, max_date


def generate_ev_period(name, professors):
	regex_ev_period = r'profesori(\d{4}_\d{4})_sem(\d)'
	searchObj = re.search(regex_ev_period, name)

	if not searchObj:
		return

	year_period = searchObj.group(1)
	year_period = re.sub(r"_", " - ", year_period)
	semester = searchObj.group(2)

	start_date, end_date = determine_ev_period_interval(professors)

	return {
		'year_period': year_period,
		'semester': semester,
		'start_of_evaluation': start_date,
		'end_of_evaluation': end_date,
		'is_current': 0
	}


def get_professor_rank_and_name_from_string(professor_rank_full_name):
	regex_rank_and_name = r"((?:(?:drd|Colab|Lect|Conf|dr|Asist|Dr|Prof|Cerc|Prep)\. )+|(?:(?:drd|Colab|Lect|Conf|dr|Asist|Dr|Prof|Cerc|Prep)\.)+ )(.*)"
	searchObj = re.search(regex_rank_and_name, professor_rank_full_name)

	if not searchObj:
		return '', professor_rank_full_name

	rank = searchObj.group(1)
	full_name = searchObj.group(2).strip()

	return rank, full_name


def extract_professors_name_data(professors, professors_dict):

	for professor in professors:
		rank, full_name = get_professor_rank_and_name_from_string(professor.cadru_didactic)
		reversed_name = db.reverse_professor_name(full_name)
		if full_name not in professors_dict and reversed_name in professors_dict:
			professors_dict[reversed_name] = rank
		else:
			professors_dict[full_name] = rank


def extract_contents_from_professors_tables():
	print("Extracting all table contents from professors tables specified!")
	for professor_table_name in professors_tables:
		professors = db.get_professors_data(professor_table_name)
		print("Extracted %d rows from %s" % (len(professors), professor_table_name))
		professors_contents[professor_table_name] = professors


def extract_all_professor_data():
	profs_dict = {}
	for table_name in professors_contents:
		extract_professors_name_data(professors_contents[table_name], profs_dict)
	print("Found the following professors in all tables: ")
	print(profs_dict)
	return profs_dict


def get_subjects_with_reviews(reviews):
	subjects = []

	for review in reviews:
		subject = review.disciplina
		subject_information = subject.split(" - ")
		try:
			if len(subject_information) != 3:
				raise Exception("The 3 elements format is not respected")
			subject_title = subject_information[0].strip()
			subject_professor = review.cadru_didactic
			subject_type = subject_information[2].strip().lower()

		except Exception as e:
			if len(subject_information) >= 2:
				subject_title = subject_information[0]
				subject_professor = review.cadru_didactic
				subject_type = 'seminar'
			else:
				print("Less than 2 elements present, workaround impossible")
				continue
			print("%s, %s" % (e, str(subject)))

		professor_rank, professor_name = get_professor_rank_and_name_from_string(subject_professor)

		new_review = {
			'positive_remark': review.c1,
			'negative_remark': review.c2,
			'date_added': review.data.strftime("%Y-%m-%d"),
			'times_participated': review.q21,
			'responses': []
		}

		for id_q in range(1, 21):
			new_review['responses'].append({
				'question_id': id_q,
				'review_result': getattr(review, "q"+str(id_q))
			})
		is_found = False
		for sj in subjects:
			if sj['title'] == subject_title and sj['professor'] == professor_name and sj['type'] == subject_type:
				sj['reviews'].append(new_review)
				is_found = True
				break

		if not is_found:
			subjects.append({
				'year': '',
				'group': '',
				'title': subject_title,
				'professor': professor_name,
				'type': subject_type,
				'reviews': [new_review]
			})

	return subjects


def find_professor_id(professor_name):

	rev_prof_name = db.reverse_professor_name(professor_name)
	for prof in all_profs_from_db:
		if prof.full_name == professor_name:
			return prof.id_professor
		if prof.full_name == rev_prof_name:
			return prof.id_professor
	raise Exception("No professor in database with name: %s" % professor_name)


def extract_reviews():

	try:

		for table_name, review_data in professors_contents.iteritems():

			if len(review_data) == 0:
				continue

			ev_period = generate_ev_period(table_name, review_data)
			subjects = get_subjects_with_reviews(review_data)
			print("Extracted subjects for following evalution period: %s, sem. %s, %s -> %s" % (ev_period['year_period'],
																								ev_period['semester'],
																								ev_period['start_of_evaluation'],
																								ev_period['end_of_evaluation']))
			new_ev_period_db = db.EvaluationPeriod(
				year_period=ev_period['year_period'],
				semester=ev_period['semester'],
				start_of_evaluation=ev_period['start_of_evaluation'],
				end_of_evaluation=ev_period['end_of_evaluation'],
				is_current=0
			)
			db.session.add(new_ev_period_db)
			db.session.flush()
			print("Inserted new evaluation period with id: %d" % new_ev_period_db.id)

			# Inserting each subject in the table
			for subject in subjects:
				prof_id = find_professor_id(subject['professor'])
				new_timetable_entry = db.Timetable(
					subject=subject['title'],
					year=subject['year'],
					group=subject['group'],
					type=subject['type'],
					professor_id=prof_id,
					evaluation_period_id=new_ev_period_db.id
				)
				db.session.add(new_timetable_entry)
				db.session.flush()
				print("Inserted new subject: %s - %s" % (new_timetable_entry.subject, new_timetable_entry.type))

				# Inserting each review for the subject
				for review in subject['reviews']:
					new_review_db = db.Review(
						timetable_entry_id = new_timetable_entry.id_subject,
						positive_remark = review['positive_remark'],
						negative_remark = review['negative_remark'],
						date_added = review['date_added'],
						times_participated = review['times_participated']
					)
					db.session.add(new_review_db)
					db.session.flush()

					for response in review['responses']:
						new_response_db = db.Response(
							review_id = new_review_db.review_id,
							question_id = response['question_id'],
							review_result = response['review_result']
						)
						db.session.add(new_response_db)
						db.session.flush()
				print("Added %d reviews for subject %s - %s" % (len(subject['reviews']),
																new_timetable_entry.subject,
																new_timetable_entry.type))

		db.session.commit()
	except Exception as e:
		print(e)
		db.session.rollback()


def import_from_old_format():
	global all_profs_from_db

	print("Starting importing from old format..")
	extract_contents_from_professors_tables()
	profs_dict = extract_all_professor_data()
	db.update_or_insert_professors(profs_dict)
	all_profs_from_db = db.get_all_profs()
	extract_reviews()

	# for professor_table_name in professors_tables:
	# 	professors = db.get_professors_data(professor_table_name)
	# 	if len(professors) == 0:
	# 		continue
	# 	ev_period = generate_ev_period(professor_table_name, professors)
	# 	# print(ev_period)



if __name__ == '__main__':
	import_from_old_format()
