from sqlalchemy import *
from sqlalchemy.orm import create_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from sqlalchemy.orm import contains_eager, joinedload
from sqlalchemy.orm import relationship

MYSQL_CONNECTION_STRING = 'mysql+mysqlconnector://evaluare:kRWEudQ7uc@85.122.23.145:3306/evaluare'

Base = declarative_base()
engine = create_engine(MYSQL_CONNECTION_STRING, echo=False)
metadata = MetaData(bind=engine)
Session = sessionmaker(bind=engine)
session = Session()


class Professor(Base):
	__table__ = Table('professors', metadata, autoload=True)


class Timetable(Base):
	__table__ = Table('timetable', metadata, autoload=True)
	professor = relationship('Professor', backref='timetable')
	evaluation_period = relationship('EvaluationPeriod', backref='timetable')


class Response(Base):
	__table__ = Table('responses', metadata, autoload=True)


class Review(Base):
	__table__ = Table('reviews', metadata, autoload=True)


class EvaluationPeriod(Base):
	__table__ = Table('evaluation_period', metadata, autoload=True)


class UserReview(Base):
	__table__ = Table('user_reviews', metadata, autoload=True)


def get_ev_period_id(year_period, semester):
	found_ev_period = session.query(EvaluationPeriod).\
		filter(EvaluationPeriod.year_period == year_period).\
		filter(EvaluationPeriod.semester == semester).\
		first()
	if not found_ev_period:
		raise Exception("No ev period found for year_period: %s, semester: %s" % (year_period, semester))
	return found_ev_period.id


def get_professors_data(tablename):
	class ProfessorsClass(Base):
		__table__ = Table(tablename, metadata, autoload=True)

	professors = session.query(ProfessorsClass).all()
	return professors


def get_student_reviews(tablename):
	class StudenReviewClass(Base):
		__table__ = Table(tablename, metadata, autoload=True)

	student_reviews = session.query(StudenReviewClass).all()
	return student_reviews


def reverse_professor_name(full_name):
	names = full_name.split(" ", 1)
	first_name_first_full_name = " ".join(names[::-1])
	return first_name_first_full_name


def update_or_insert_professors(professors):

	try:
		for professor_name, rank in professors.iteritems():
			found_prof = session.query(Professor).filter(Professor.full_name == professor_name).first()
			if not found_prof:
				rev_full_name = reverse_professor_name(professor_name)
				found_prof = session.query(Professor).filter(Professor.full_name == rev_full_name).first()

			if not found_prof:
				new_prof = Professor(rank=rank, full_name=professor_name)
				session.add(new_prof)
			elif found_prof.rank != rank:
				found_prof.rank = rank
		session.commit()
	except Exception as e:
		print(e)
		session.rollback()


def get_all_profs():
	return session.query(Professor).all()

