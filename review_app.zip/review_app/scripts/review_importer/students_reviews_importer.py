import re

import db
import reviews_importer

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

students_table = [
	'studenti2009_2010_sem1',
	'studenti2009_2010_sem2',
	'studenti2010_2011_sem1',
	'studenti2010_2011_sem2',
	'studenti2011_2012_sem1',
	'studenti2012_2013_sem1',
	'studenti2012_2013_sem2',
	'studenti2013_2014_sem1',
	'studenti2013_2014_sem2',
	'studenti2014_2015_sem1',
	'studenti2014_2015_sem2',
	'studenti2015_2016_sem1',
	'studenti2015_2016_sem2',
	'studenti2016_2017_sem1',
	'studenti2016_2017_sem2',
	'studenti2017_2018_sem1'
]


def get_ev_period(table_name):
	regex_ev_period = r'studenti(\d{4}_\d{4})_sem(\d)'
	searchObj = re.search(regex_ev_period, table_name)

	if not searchObj:
		return

	year_period = searchObj.group(1)
	year_period = re.sub(r"_", " - ", year_period)
	semester = searchObj.group(2)

	return year_period, semester


def find_professor_id(professor_name, all_profs):
	rev_prof_name = db.reverse_professor_name(professor_name)
	for prof in all_profs:
		if prof.full_name == professor_name:
			return prof.id_professor
		if prof.full_name == rev_prof_name:
			return prof.id_professor
	raise Exception("No professor in database with name: %s" % professor_name)


def determine_subject_information(subject_string):
	subject_information = subject_string.split(" - ")
	try:
		if len(subject_information) != 3:
			raise Exception("The 3 elements format is not respected")
		subject_title = subject_information[0].strip()
		subject_type = subject_information[2].strip().lower()

	except Exception as e:
		if len(subject_information) >= 2:
			subject_title = subject_information[0]
			subject_type = 'seminar'
		else:
			print("Less than 2 elements present, workaround impossible")
			print("%s" % subject_string)
			raise Exception("Less than 2 elements present, workaround impossible")

	return subject_type, subject_title


def get_timetable_entry_id(subject_title, type, professor_id, ev_period_id):
	timetable_entry = db.session.query(db.Timetable). \
		filter(db.Timetable.subject == subject_title). \
		filter(db.Timetable.type == type). \
		filter(db.Timetable.professor_id == professor_id).\
		filter(db.Timetable.evaluation_period_id == ev_period_id).\
		first()

	if not timetable_entry:
		return None

	return timetable_entry.id_subject


def extract_and_insert_student_reviews():

	all_professors = db.get_all_profs()
	inserted_user_reviews = {}

	try:
		for table_name in students_table:
			all_student_evaluations = db.get_student_reviews(table_name)

			print("Found %d student evaluations"%len(all_student_evaluations))

			if len(all_student_evaluations) == 0:
				continue

			ev_period_year, ev_period_sem = get_ev_period(table_name)
			ev_period_id = db.get_ev_period_id(ev_period_year, ev_period_sem)

			for student_evaluation in all_student_evaluations:
				professor_rank, professor_full_name = reviews_importer.get_professor_rank_and_name_from_string(student_evaluation.cadru_didactic)
				professor_id = find_professor_id(professor_full_name, all_professors)
				subject_type, subject_title = determine_subject_information(student_evaluation.disciplina)

				timetable_entry_id = get_timetable_entry_id(subject_title, subject_type, professor_id, ev_period_id)
				if timetable_entry_id == None:
					print(bcolors.FAIL + "Failed to identify subject in timetable for: %s %s %s" % (subject_type, subject_title, professor_full_name) + bcolors.ENDC)
				else:
					print("Identified subject: %d %s %s %s, reviewed by %s" % (timetable_entry_id, subject_type, subject_title, professor_full_name, student_evaluation.cont))

					reviewed_subject_ids = inserted_user_reviews.get(student_evaluation.cont)
					already_reviewed = False

					if reviewed_subject_ids is None:
						inserted_user_reviews[student_evaluation.cont] = set()
						inserted_user_reviews[student_evaluation.cont].add(timetable_entry_id)
					elif timetable_entry_id in inserted_user_reviews[student_evaluation.cont]:
						already_reviewed = True
						print(bcolors.FAIL + "Student %s already reviewed subject %d" % (
						student_evaluation.cont, timetable_entry_id) + bcolors.ENDC)
					else:
						inserted_user_reviews[student_evaluation.cont].add(timetable_entry_id)

					if not already_reviewed:
						new_student_review = db.UserReview(
							username=student_evaluation.cont,
							subject_id=timetable_entry_id
						)
						db.session.add(new_student_review)

		db.session.commit()
	except Exception as e:
		print(e)
		db.session.rollback()


if __name__ == '__main__':
	extract_and_insert_student_reviews()
