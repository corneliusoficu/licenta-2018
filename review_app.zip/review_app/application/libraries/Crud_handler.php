<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Crud_handler{

        const MAX_FIELD_LENGTH = 300;

        private $error_message;
        private $db_tables_mapping;
        private $CI;

        public function __construct()
        {   
            $this->CI =& get_instance();
            $this->CI->load->database();

            $this->db_tables_mapping = $this->CI->config->item('db_tables_mapping');
  
        }

        public function update_model($model_name, $id)
        {

            if(!isset($model_name) || !isset($id))
            {
                $this->error_message = 'Tabel sau id nespecificat!';
                return FALSE;
            }

            $table_data = access_array_element([$model_name], $this->db_tables_mapping);

            if($table_data == NULL)
            {
                $this->error_message = 'Nu exista informatii pentru tabelul specificat!';
                return FALSE;
            }

            parse_str(file_get_contents("php://input"), $put_data);
            
            if(!$this->are_put_fields_valid($put_data, $table_data['columns']))
            {
                return FALSE;
            }

            $pk_column   = access_array_element(['index_col'], $table_data);
            $table_name = access_array_element(['table_name'], $table_data);

            if(!$pk_column || !$table_name)
            {
                $this->error_message = 'Nu au putut fi obtinute informatii despre numele tabelei sau a cheii primare!';
                return FALSE;
            }

            try
            {   
                $this->CI->db->db_debug = FALSE;
                $this->CI->db->set($put_data);
                $this->CI->db->where($pk_column, $id);
                $this->CI->db->update($table_name);
                $this->CI->db->db_debug = TRUE;

                $db_error = $this->CI->db->error();

                if ($db_error['code'] != 0) {
                    throw new Exception('Database error! Error Code [' . $db_error['code'] . '] Error: ' . $db_error['message']);
                }

                return TRUE;
            }
            catch (Exception $e)
            {
                $this->error_message = $e->getMessage();
                return FALSE;
            }
        }

        public function delete_model($model_name, $id)
        {   
            
            if(!$model_name || !$id)
            {
                $this->error_message = 'Tabela sau id-ul nu au fost furnizare!';
                return FALSE;
            }

            $table_data = access_array_element([$model_name], $this->db_tables_mapping);

            if(!$table_data)
            {
                $this->error_message = 'Nu exista informatii pentru tabelul specificat!';
                return FALSE;
            }

            $pk_column   = access_array_element(['index_col'], $table_data);
            $table_name = access_array_element(['table_name'], $table_data);

            if(!$pk_column || !$table_name)
            {
                $this->error_message = 'Nu au putut fi obtinute informatii despre numele tabelei sau a cheii primare!';
                return FALSE;
            }

            try
            {   
                $this->CI->db->db_debug = FALSE;
                $this->CI->db->delete($table_name, array($pk_column => $id));
                $this->CI->db->db_debug = TRUE;

                $db_error = $this->CI->db->error();
                if (!empty($db_error['code'] || !empty($db_error['message']))) {
                    throw new Exception('Database error! Error Code [' . $db_error['code'] . '] Error: ' . $db_error['message']);
                }

                return TRUE;
            }
            catch (Exception $e)
            {
                $this->error_message = $e->getMessage();
                return FALSE;
            }
        }

        public function get_error_message()
        {
            return $this->error_message;
        }

        private function are_put_fields_valid($put_data, $columns_data)
        {   
            $column_names = array_keys($columns_data);

            if(count($put_data) == 0)
            {   
                $this->error_message = 'Nu a fost furnizata nici-o informatie pentru editare!';
                return FALSE;
            }

            foreach($put_data as $field => $field_value)
            {
                if(!in_array($field, $column_names))
                {   
                    $this->error_message = "Campul $field nu exista in tabela!";
                    return FALSE;
                }
                if(strlen($field_value) > self::MAX_FIELD_LENGTH )
                {   
                    $max = self::MAX_FIELD_LENGTH;
                    $this->error_message = "Lungimea campului $field depaseste $max de caractere!";
                    return FALSE;
                }
            }
            return TRUE;
        }
    }



    

    