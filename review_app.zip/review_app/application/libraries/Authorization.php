<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Authorization {

        protected $CI;

        protected $LOGIN_URL = "/registration/login";

        public function __construct()
        {   
            $this->CI =& get_instance();
            $this->CI->load->library('session');
            $this->CI->load->helper('url');

            $this->LOGIN_URL = "/registration/login";
        }

        public function redirect_login()
        {
            $url = '/registration/login';
            if($this->CI->session->has_userdata('user'))
            {
                $user = $this->CI->session->userdata('user');
                if($user->user_type == 'professor')
                {
                    $url = '/registration/professors/signin';
                }
            }

            redirect($url);
        }

        public function store_user_session($user, $user_type = 'student')
        {
            $session_data['user']                 = $user;
            $session_data['user']->is_logged_in   = TRUE;
            $session_data['user']->user_type      = $user_type;

            $this->CI->session->set_userdata($session_data);
        }

        public function get_user_session()
        {
            $this->authorize_logged_in();
    
            return $this->CI->session->userdata('user');
        }

        public function authorize_logged_in()
        {
            if(!$this->is_user_logged_in())
            {
                $this->CI->session->set_flashdata('registration_messages', array("Trebuie sa te autentifici!"));
                $this->redirect_login();
            }
        }

        public function is_user_logged_in()
        {
            if($this->CI->session->has_userdata('user'))
            {
                
                $user = $this->CI->session->userdata('user');
                return $user->is_logged_in;
            }
            else
            {
                return FALSE;
            }
        }

        public function logout_user()
        {
            $this->CI->session->sess_destroy();
            var_dump($this->LOGIN_URL);
            $this->redirect_login();
        }

        public function set_user_field($key, $value)
        {
            if($this->CI->session->has_userdata('user'))
            {
                $session_data['user']          = $this->CI->session->userdata('user');
                $session_data['user']->{$key} = $value;
                $this->CI->session->set_userdata($session_data);
            }
        }

        public function has_permission($permission_name)
        {   
            $this->authorize_logged_in();

            $user = $this->CI->session->userdata('user');
            if(!isset($user->permissions))
            {
                return FALSE;
            }
            else
            {
                foreach($user->permissions as $permission)
                {
                    if($permission->permission_name == $permission_name)
                    {
                        return TRUE;
                    }
                }

                return FALSE;
            }
            
        }

        public function validate_permission($permission_name)
        {
            if(!$this->has_permission($permission_name))
            {
                show_error("You are not allowed to access this resource", 403);
            }
        }
    }