<?php
    class MY_Form_validation extends CI_Form_validation{

        public function __construct($CI)
        {
            $this->CI = $CI;
            $this->CI->load->helper('form');
        }

        public function validate_form_data($config, $redirect_location)
        {   
            $this->set_rules($config);
            $this->set_error_delimiters('', ';');

            if(!$this->run())
            {
                if(isset($redirect_location))
                {
                    $errors_list = explode(";", validation_errors());
                    
                    if(count($errors_list) > 0)
                    {
                        array_pop($errors_list);
                    }

                    $this->CI->session->set_flashdata('registration_messages', $errors_list);
                    redirect($redirect_location);
                }
            }
        }
    }

    