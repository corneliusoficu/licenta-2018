<?php
    $route['professors/requests'] = 'Professors_accounts_controller';
    $route['professors/requests/(:any)'] = 'Professors_accounts_controller/requests_view/$1';

    $route['professors/search/(:any)'] = 'Professors_accounts_controller/search_professor/$1';

    $route['professors/results']             = 'Results_controller';
    $route['professors/periods']             = 'Results_controller/get_periods';
    $route['professors/faculty-results']     = 'Results_controller/faculty_results_page';
    $route['professors/professors-results']  = 'Results_controller/professors_results_page';
    $route['professors/general-statistics']  = 'Results_controller/general_statitstics';
    $route['professors/result']              = 'Results_controller/results_for_professor';
    $route['professors/avg_grade_evolution'] = 'Results_controller/get_avg_grade_evolution';
    $route['professors/avg_participation']   = 'Results_controller/get_avg_participation';
    $route['professors/nr_evals_evolution']  = 'Results_controller/get_nr_evals_evolution';

    $route['professors/approve_professor_request'] = 'Professors_accounts_controller/approve_professor_request';
    $route['professors/decline_professor_request'] = 'Professors_accounts_controller/decline_professor_request';
    $route['professors/change_request_to_pending'] = 'Professors_accounts_controller/change_request_to_pending';

