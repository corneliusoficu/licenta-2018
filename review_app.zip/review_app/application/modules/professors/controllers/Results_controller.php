<?php
    class Results_controller extends MX_Controller{

        const RESOURCES = [
            'css' => [
                'general/select2.min',
                'general/chartist-plugin-legend',
                'general/chartist-plugin-tooltip',
                'general/chartist',
                'results'
            ],
            'js' => [
                'general/select2.min',
                'general/chartist.min',
                'general/chartist-plugin-pointlabels.min',
                'general/chartist-plugin-tooltip',
                'general/chartist-plugin-legend',
                'results'
            ]
        ];

        public function __construct()
        {
            // $this->authorization->validate_permission('can_see_own_results');
            
            $this->load->helper('url_helper');
            $this->load->model('generators/evaluation_period');
            $this->load->model('evaluation/review');
        }

        public function get_periods_data()
        {
            $evaluation_periods = $this->evaluation_period->get_all_by_date_desc();
            $eval_period        = NULL;

            if(count($evaluation_periods) > 0)
            {
                $eval_period = $evaluation_periods[0];
            }
            
            $period_id              = $this->input->get('period');
            $is_period_id_specified = isset($period_id);

            foreach($evaluation_periods as $period)
            {
                if(!$is_period_id_specified && $period->is_current == TRUE)
                {
                    $eval_period = $period;
                    break;
                }
                else if($is_period_id_specified && $period->id == $period_id)
                {
                    $eval_period = $period;
                    break;
                }
            }

            $data['all_evaluation_periods'] = $evaluation_periods;
            $data['evaluation_period']      = $eval_period;

            return $data;
        }

        public function index()
        {   
            $data = $this->get_periods_data();
            $this->display_results($data);
        }

        public function display_results($data)
        {
            $header_data['resources'] = self::RESOURCES;
            $header_data['title']     = 'Rezultate';

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('results_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function professors_results_page()
        {   

            $prof_id = $this->input->get('prof_id');
            $data    = $this->get_periods_data();

            if(isset($prof_id))
            {
                $this->results_for_professor($prof_id, $data);
                return;
            }

            $header_data['resources'] = [
                'css' => [
                    'general/select2.min',
                    'results',
                    'professors-results'
                ],
                'js' => [
                    'general/select2.min',
                    'professors-results',
                    'results'
                ],
                'js_remote' => array(
                    'https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js'
                ),
                'css_remote' => array(
                    'https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.css'
                ),
            ];
            $header_data['title']     = 'Rezultate Profesori';
            
            $this->load->model('data/professor');

            $rankings         = $this->professor->get_professor_rankings($data['evaluation_period']->id);
            $data['rankings'] = $rankings;

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('professor_results_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function faculty_results_page()
        {
            $header_data['resources'] = self::RESOURCES;
            $header_data['title']     = 'Rezultate Facultate';
            $data = $this->get_periods_data();

            $current_period = $data['evaluation_period'];

            $this->load->helper('statistics/statistics_helper');

            if($current_period)
            {
                $distribution         = $this->review->get_nr_reviews_distribution_by_years($current_period);
                $data['distribution']         = convert_distribution_to_faculty_type($distribution);
                $data['statistics']           = get_faculty_statistics($current_period);
                $data['nr_reviews_evolution'] = $this->review->get_nr_reviews_evolution();
                $data['avg_grade_evolution']  = $this->review->get_avg_grade_evolution();
            }
           
            $this->load->view('templates/review_header', $header_data);
            $this->load->view('faculty_results_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function results_for_professor($prof_id, $data)
        {   
            $resources = [
                'css' => [
                    'general/select2.min',
                    'general/chartist-plugin-legend',
                    'general/chartist-plugin-tooltip',
                    'general/chartist',
                    'results',
                    'results-single-prof'
                ],
                'js' => [
                    'general/select2.min',
                    'general/chartist.min',
                    'general/chartist-plugin-pointlabels.min',
                    'general/chartist-plugin-tooltip',
                    'general/chartist-plugin-legend',
                    'results',
                    'results-single-prof'
                ]
            ];

            $this->load->model('data/professor');

            $data['prof']          = $this->professor->get_by_id($prof_id);
            $data['general_stats'] = $this->professor->get_professor_general_statistics($prof_id, $data['evaluation_period']->id);
            $data['all_profs']     = $this->professor->get_all();

            $header_data['resources'] = $resources;
            $header_data['title']     = 'Rezultate';

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('single_professor_results_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function get_avg_grade_evolution()
        {
            $this->load->model("data/professor");
            $professor_id = $this->input->get('prof_id');
            $evolution    = $this->professor->get_professor_avg_grade_evolution($professor_id);
            echo json_encode($evolution);
        }

        public function get_avg_participation()
        {
            $this->load->model("data/professor");
            $professor_id = $this->input->get('prof_id');
            $evolution    =  $this->professor->get_professor_avg_participation_evolution($professor_id);
            echo json_encode($evolution);
        }

        public function get_nr_evals_evolution()
        {
            $this->load->model("data/professor");
            $professor_id = $this->input->get('prof_id');
            $evolution = $this->professor->get_professor_nr_evals_evolution($professor_id);
            echo json_encode($evolution);
        }

    }