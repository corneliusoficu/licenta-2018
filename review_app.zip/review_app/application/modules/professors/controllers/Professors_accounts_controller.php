<?php
     class Professors_accounts_controller extends MX_Controller {

        const RESOURCES = [
            'css' => [
                'general/select2.min',
                'professors_accounts'
                
            ],
            'js' => [
                'general/select2.min',
                'general/sweetalert.min',
                'professors_accounts'
            ],
        ];

        public function __construct()
        {
            $this->authorization->validate_permission('can_create_professor_accounts');
            parent::__construct();

            $this->load->helper('url_helper');
            $this->load->helper('professors/professors_name_helper');
            $this->load->helper('professors/professors_accounts_helper');
            $this->load->helper('frontend/select2_helper');
            $this->load->library('pagination');

            $this->load->model('data/professor');
            $this->load->model('professors/professor_account_request');
            $this->load->model('registration/group');
        }

        public function index()
        {
            $this->requests_view('pending');
        }

        public function requests_view($type)
        {
            $groups = $this->group->get_all_groups();
            $data['groups'] = $groups;
            
            $header_data['resources'] = self::RESOURCES;
            $header_data['title']     = 'Conturi Profesori';

            $config['base_url'] = base_url(). "professors/requests/$type";

            $nr_requests = $this->professor_account_request->count($type);

            $config['total_rows'] = $nr_requests;
            $config['per_page'] = 10;
            $config['uri_segment'] = 4;
            $config['full_tag_open'] 	= '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close'] 	= '</ul></nav></div>';
            $config['num_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['num_tag_close'] 	= '</span></li>';
            $config['cur_tag_open'] 	= '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close'] 	= '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['next_tagl_close'] 	= '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['prev_tagl_close'] 	= '</span></li>';
            
            $config['first_link'] = '&laquo; Primul';

            $config['first_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';

            $config['last_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['last_tagl_close'] 	= '</span></li>';

            $config['last_link'] = 'Ultimul';

            $this->pagination->initialize($config);
            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;

            $requests = $this->professor_account_request->fetch_requests($config['per_page'], $page, $type);
            if($requests != FALSE)
            {   
                $data['results'] = $requests;
            }

            $data['links'] = $this->pagination->create_links();

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('professors/professors_accounts_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function search_professor($type)
        {   
            if($type != 'all')
            {
                $professors = $this->professor->get_matching_query(TRUE);
            }
            else
            {
                $professors = $this->professor->get_matching_query();
            }
            
            $professors = convert_professors_to_select2_format($professors);

            header('Content-Type: application/json');
            echo json_encode($professors);
        }

        public function approve_professor_request()
        {   
            $email        = $this->input->post('email');
            $professorId  = $this->input->post('accountId');
            $adminGroup   = $this->input->post('adminGroup');
            $id           = $this->input->post('id');

            $professor_data = $this->professor->store_professor_credentials($professorId, $email, $adminGroup);

            if(!$professor_data)
            {
                http_response_code(400);
                return;
            }

            $ret_val = $this->professor_account_request->change_status($id, "APPROVED");

            if(!$ret_val)
            {
                echo "Nu exista nici-o cerere ce contine id-ul furnizat!";
                http_response_code(400);
                return;
            }

            send_credentials_by_email($professor_data);

        }

        public function decline_professor_request()
        {
            $id = $this->input->post('id');
            $request = $this->professor_account_request->change_status($id, "DECLINED");
            
            if(!$request)
            {
                echo "Nu exista nici-o cerere ce contine id-ul furnizat!";
                http_response_code(400);
                return;
            }

            $this->professor->clear_professor_credentials($request->email);
        }

        public function change_request_to_pending()
        {
            $id = $this->input->post('id');
            
            $request = $this->professor_account_request->get_by_id($id);

            if(!$request)
            {
                echo "Nici-o cerere cu id-ul specificat a put fi gasita!";
                http_response_code(400);
                return;
            }

            $professor = $this->professor->get_by_email($request->email);

            if($professor != NULL)
            {
                echo "Acest email este deja asociat unui cont de profesor!";
                http_response_code(400);
                return;
            }

            if($this->professor_account_request->is_email_already_pending_or_aproved($request->email))
            {
                echo "Exista deja o cerere aprobata sau in asteptare pentru aceasta adresa de email!";
                http_response_code(400);
                return;
            }

            $this->professor_account_request->change_status($id, 'PENDING');
        }
     }