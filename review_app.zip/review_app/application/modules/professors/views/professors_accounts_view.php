<div class="requests-page">


    <div class="card ">
        <div class="card-body p-4">
            <h5 class="card-title mb-16">Cereri pentru conturi</h5>
            <p>Vizualizati si aprobati cererile pentru conturile profesorilor</p> 
            <ul class="nav nav-tabs request-type-tabs">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url() ?>professors/requests/pending">In asteptare</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url() ?>professors/requests/approved">Aprobate</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url() ?>professors/requests/declined">Respinse</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url() ?>professors/requests/all">Toate</a>
                </li>
            </ul>

            <?php if(isset($results)): ?>
                <?php $index = 0 ?>
                <?php foreach($results as $result): ?>

                    <?php
                        $color_class = null;
                        $text        = null;
                        switch($result->status)
                        {
                            case 'PENDING':
                                $color_class = 'yellow-p';
                                $text        = 'In asteptare';
                                break;
                            case 'APPROVED':
                                $color_class = 'green-p';
                                $text        = 'Aprobat';
                                break;
                            case 'DECLINED':
                                $color_class = 'red-p';
                                $text        = 'Respins';
                                break;
                            default:
                                $color_class = 'yellow-p';
                                break;
                        }   
                    ?>

                    <div class="card request-card">

                        <div class="card-header cursor-p d-flex justify-content-between align-items-center flex-wrap" id="heading<?=$index?>" data-toggle="collapse" data-target="#collapse<?=$index?>" aria-expanded="true" aria-controls="collapseOne">
                            <p class="header-text" >
                                <?php echo $result->last_name . " " . $result->first_name ?>
                            </p>
                            <p><?=$result->email?></p>
                            <p class="request-type <?=$color_class?>"><?=$text?></p>
                        </div>

                        <div class="collapse" id="collapse<?=$index?>">
                            <div class="card-body p-4">
                                <p class="request-id" hidden><?=$result->id?></p>
                                <?php if($result->status == 'PENDING'): ?>
                                    <table class="request-information-table">
                                        <tr>
                                            <td class="table-label">Nume: </td>
                                            <td class="request-last-name"><?=$result->last_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Prenume: </td>
                                            <td class="request-first-name"><?=$result->first_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Email:</td>
                                            <td class="request-email"><?=$result->email?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Data cerere:</td>
                                            <td><?=$result->date_of_request?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Cont profesor:</td>
                                            <td>
                                                <select class="professor-account-select"></select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-label">Grup:</td>
                                            <td>
                                                <select class="professor-group-select">
                                                    <?php foreach($groups as $group): ?>
                                                        <option value="<?=$group->id?>" <?php if($group->id == 4):?>selected<?php endif?>><?=$group->name?></option>
                                                    <?php endforeach ?>
                                                </select>
                                            </td> 
                                        </tr>
                                    </table>

                                    <button class="btn btn-success cursor-p aprove-request-btn" type="submit">Aproba</button>
                                    <button class="btn btn-danger cursor-p decline-request-btn" type="submit">Respinge</button>
                                <?php elseif($result->status == 'APPROVED'): ?>
                                    <table class="request-information-table">
                                        <tr>
                                            <td class="table-label">Nume: </td>
                                            <td class="request-last-name"><?=$result->last_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Prenume: </td>
                                            <td class="request-first-name"><?=$result->first_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Email:</td>
                                            <td class="request-email"><?=$result->email?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Data cerere:</td>
                                            <td><?=$result->date_of_request?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Cont profesor:</td>
                                            <td>
                                                <select class="professor-account-select all-professors">
                                                    <option selected value="<?=$result->id_professor?>"><?=$result->rank?> <?=$result->full_name?></option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-label">Grup:</td>
                                            <td>
                                                <select class="professor-group-select">
                                                    <?php foreach($groups as $group): ?>
                                                        <option value="<?=$group->id?>" <?php if($group->id == $result->administrative_group_id):?>selected<?php endif?>><?=$group->name?></option>
                                                    <?php endforeach ?>
                                                </select>
                                            </td> 
                                        </tr>
                                    </table>

                                    <button class="btn btn-primary cursor-p modify-request-btn" type="submit">Modifica</button>
                                    <button class="btn btn-danger cursor-p decline-request-btn" type="submit">Respinge</button>

                                <?php elseif($result->status == 'DECLINED'): ?>
                                    <table class="request-information-table">
                                        <tr>
                                            <td class="table-label">Nume: </td>
                                            <td class="request-last-name"><?=$result->last_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Prenume: </td>
                                            <td class="request-first-name"><?=$result->first_name?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Email:</td>
                                            <td class="request-email"><?=$result->email?></td> 
                                        </tr>
                                        <tr>
                                            <td class="table-label">Data cerere:</td>
                                            <td><?=$result->date_of_request?></td> 
                                        </tr>
                                    </table>
                                    <button class="btn btn-primary cursor-p change-to-pending-request-btn" type="submit">In asteptare</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php $index++ ?>  
                <?php endforeach ?>

                <?php echo $links; ?>
            <?php endif ?>
        </div>      
    </div>
</div>