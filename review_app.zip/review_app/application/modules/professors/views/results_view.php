<?php if(isset($evaluation_period)): ?>
    
    <div class = "card evaluation-period-card">
        <div class="card-body text-center">
            <h3>Rezultate pentru urmatoarea perioada:</h3>
            
            <form method="GET">
                
                <?php $ev_period_text = 'Semestrul ' . $evaluation_period->semester . ', ' . $evaluation_period->year_period ?>
                <h4 id="ev-period-text"><?=$ev_period_text?></h4>
                <div class="form-group">
                    <select name="period" id="ev-period-selection-select">
                        <?php foreach($all_evaluation_periods as $period): ?>
                            <?php $ev_period_text = 'Semestrul ' . $period->semester . ', ' . $period->year_period ?> 
                            <?php if ($period->id == $evaluation_period->id): ?>
                                <option selected value="<?=$evaluation_period->id?>"><?=$ev_period_text?></option>"
                            <?php else: ?>
                                <option value="<?=$period->id?>"><?=$ev_period_text?></option>"
                            <?php endif ?>
                        <?php endforeach ?>
                    </select>
                </div>
                <button type="button" id="change-ev-period-btn" class="btn btn-primary cursor-p mt-2">Schimba</button>
                <button type="button" id="cancel-ev-period-selection-btn" class="btn btn-danger cursor-p mt-2">Anuleaza</button>
                <button type="submit" id="save-ev-period-selection-btn" class="btn btn-success cursor-p mt-2">Seteaza</button>
            </form> 
        </div>
    </div>
<?php endif ?>