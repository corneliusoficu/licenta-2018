<?php if(isset($evaluation_period)): ?>
    <div class="faculty-statistics-container">
        <div class = "card evaluation-period-card">
            <div class="card-body text-center">
                <h3>Rezultate pentru perioada:</h3>
                
                <form method="GET">
                    
                    <?php $ev_period_text = 'Semestrul ' . $evaluation_period->semester . ', ' . $evaluation_period->year_period ?>
                    <h4 id="ev-period-text"><?=$ev_period_text?></h4>
                    <div class="form-group">
                        <select name="period" id="ev-period-selection-select">
                            <?php foreach($all_evaluation_periods as $period): ?>
                                <?php $ev_period_text = 'Semestrul ' . $period->semester . ', ' . $period->year_period ?> 
                                <?php if ($period->id == $evaluation_period->id): ?>
                                    <option selected value="<?=$evaluation_period->id?>"><?=$ev_period_text?></option>"
                                <?php else: ?>
                                    <option value="<?=$period->id?>"><?=$ev_period_text?></option>"
                                <?php endif ?>
                                
                            <?php endforeach ?>
                        </select>
                    </div>
                    <button type="button" id="change-ev-period-btn" class="btn btn-primary cursor-p mt-2">Schimbati</button>
                    <button type="button" id="cancel-ev-period-selection-btn" class="btn btn-danger cursor-p mt-2">Anuleaza</button>
                    <button type="submit" id="save-ev-period-selection-btn" class="btn btn-success cursor-p mt-2">Seteaza</button>
                </form> 
            </div>
        </div>

        <div id="statistics-row">
                <?php if(isset($statistics)): ?>
                    <div class="d-flex flex-row flex-wrap statistics-cards-row">
                        <?php foreach($statistics as $index => $statistic): ?>
                            <?php if(isset($statistic) && array_key_exists('name', $statistic) && array_key_exists('value', $statistic)): ?>
                                <?php if($index == count($statistics) - 1): ?>
                                    <div class="card statistic-card" style="margin-right: 0;">
                                <?php else: ?>
                                    <div class="card statistic-card">
                                <?php endif ?>
                                    <div class="card-body">
                                        <h5 class="card-title"><?=$statistic['name']?></h5>
                                    </div>
                                    <div class="card-body">
                                        <h2 class="card-title mt-2"><?=$statistic['value']?></h2>
                                    </div>
                                </div>
                            <?php endif ?>
                        <?php endforeach ?>
                    </div>
                <?php endif ?>
        </div>

        <script>
            var distribution = <?php echo json_encode($distribution) ?>
        </script>

        <div id="evaluation-year-distribution" class="ct-graph-container">
            <h5>Distributia numarului de evaluari in functie de anul studentilor</h5>
            <div id="evaluation-distribution"></div>
        </div>

        <script>
            var nrReviewsEvolution = <?php echo json_encode($nr_reviews_evolution) ?>
        </script>

        <div id="nr-evals-evolution" class="ct-graph-container">
            <h5>Evolutia numarului de evaluari</h5>
            <div id="nr-reviews-evolution"></div>
        </div>

        <script>
            var avgGradeEvolution = <?php echo json_encode($avg_grade_evolution) ?>
        </script>
        <div id="average-grade-evolution" class="ct-graph-container">
            <h5>Evolutia notei medii [1-4]</h5>
            <div id="avg-grade-evolution"></div>
        </div>

    </div>
<?php endif ?>