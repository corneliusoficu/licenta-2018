<div class="professor-results-container">
    <div class = "card evaluation-period-card">
        <div class="card-body text-center">
            <h3>Rezultate pentru perioada:</h3>
            <script>const EV_PERIOD_ID = <?php echo $evaluation_period->id?>;</script>
            <form method="GET">
                
                <?php $ev_period_text = 'Semestrul ' . $evaluation_period->semester . ', ' . $evaluation_period->year_period ?>
                <h4 id="ev-period-text"><?=$ev_period_text?></h4>
                <div class="form-group">
                    <select name="period" id="ev-period-selection-select">
                        <?php foreach($all_evaluation_periods as $period): ?>
                            <?php $ev_period_text = 'Semestrul ' . $period->semester . ', ' . $period->year_period ?> 
                            <?php if ($period->id == $evaluation_period->id): ?>
                                <option selected value="<?=$evaluation_period->id?>"><?=$ev_period_text?></option>"
                            <?php else: ?>
                                <option value="<?=$period->id?>"><?=$ev_period_text?></option>"
                            <?php endif ?>
                            
                        <?php endforeach ?>
                    </select>
                </div>
                <button type="button" id="change-ev-period-btn" class="btn btn-primary cursor-p mt-2">Schimbati</button>
                <button type="button" id="cancel-ev-period-selection-btn" class="btn btn-danger cursor-p mt-2">Anuleaza</button>
                <button type="submit" id="save-ev-period-selection-btn" class="btn btn-success cursor-p mt-2">Seteaza</button>
            </form> 
        </div>
    </div>

    <div class = "card professor-results-card">
        <div class="card-body">
        <table id="professors-table" class="display" cellspacing="0">
            <thead>
                <tr>
                    <th>Cadru didactic</th>
                    <th>Numar evaluari</th>
                    <th>Numar materii predate</th>
                    <th>Medie nepronuntari per evaluare</th>
                    <th>Nota medie [1-4]</th>
                    <th>Medie participare la seminar/curs a studentilor</th>
                    <th>Actiuni</th>
                </tr>
        </thead>
            <tbody>
                <!-- <?php print_arr($rankings); ?> -->
                <?php foreach($rankings as $ranking): ?>
                    <tr>
                        <td><?=$ranking->full_name?></td>
                        <td><?=$ranking->nr_reviews?></td>
                        <td><?=$ranking->nr_subjects?></td>
                        <td><?=round($ranking->nr_zero_results,2)?></td>
                        <td><?=round($ranking->avg_grade,2)?></td>
                        <td><?=round($ranking->avg_times_participated,2)?></td>
                        <td align="center"><a href="<?php echo base_url() . 'professors/professors-results?prof_id='.$ranking->id_professor.'&period='.$evaluation_period->id;?>" class="btn btn-primary" role="button" aria-pressed="true">Detalii</a></td>
                    </tr>
                <?php endforeach ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Cadru didactic</th>
                    <th>Numar evaluari</th>
                    <th>Numar materii predate</th>
                    <th>Medie nepronuntari per evaluare</th>
                    <th>Nota medie [1-4]</th>
                    <th>Medie participare la seminar/curs a studentilor</th>
                    <th>Actiuni</th>
                </tr>
            </tfoot>
        </table>
        </div>

    </div>
</div>
            