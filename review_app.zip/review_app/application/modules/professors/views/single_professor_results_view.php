<div class="professor-results-container">
    
    <div id="results-navigation-container" class="d-flex flex-row flex-wrap">
        <div class="card nav-card cursor-p" id="professors-table-link">
            <h4><i class="fas fa-table mr-2"></i>Tabel profesori</h4>
        </div>
        <div class="card nav-card cursor-p" id="professors-subject-link">
            <h4><i class="fas fa-chart-bar mr-2"></i>Rezultate materii</h4>
        </div>
    </div>

    <form method="GET" class="d-flex flex-row flex-wrap prof-stats-params">

        <div class = "card professor-information-card">
            <div class="card-body">
                <div class="name-container text-center">
                    <h3>Cadru didactic:<h3>
                    <h4 id="prof-name-text"><?php echo $prof->rank . ' ' . $prof->full_name ?></h3>
                    <div class="form-group">
                        <script>const PROF_ID = <?=$prof->id_professor?>;</script>
                        <select name="prof_id" id="professor-select">
                            <?php foreach($all_profs as $proffesor): ?>
                                <?php //$prof_text = 'Semestrul ' . $period->semester . ', ' . $period->year_period ?> 
                                <?php if ($proffesor->id_professor == $prof->id_professor): ?>
                                    <option selected value="<?=$proffesor->id_professor?>"><?=$proffesor->rank . $proffesor->full_name?></option>"
                                <?php else: ?>
                                    <option value="<?=$proffesor->id_professor?>"><?=$proffesor->rank . $proffesor->full_name?></option>"
                                <?php endif ?>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <button type="button" id="change-prof-btn" class="btn btn-primary cursor-p mt-2">Schimbati</button>
                    <button type="button" id="cancel-change-prof-btn" class="btn btn-danger cursor-p mt-2">Anuleaza</button>
                    <button type="submit" id="save-prof-btn" class="btn btn-success cursor-p mt-2">Seteaza</button>
                </div>
            </div>
        </div>

        <div class = "card evaluation-period-card">
            <div class="card-body text-center">
                    <h3>Rezultate pentru perioada:</h3>    
                    <?php $ev_period_text = 'Semestrul ' . $evaluation_period->semester . ', ' . $evaluation_period->year_period ?>
                    <h4 id="ev-period-text"><?=$ev_period_text?></h4>
                    <div class="form-group">
                        <script>const EV_PERIOD_ID = <?=$evaluation_period->id?>;</script>
                        <select name="period" id="ev-period-selection-select">
                            <?php foreach($all_evaluation_periods as $period): ?>
                                <?php $ev_period_text = 'Semestrul ' . $period->semester . ', ' . $period->year_period ?> 
                                <?php if ($period->id == $evaluation_period->id): ?>
                                    <option selected value="<?=$evaluation_period->id?>"><?=$ev_period_text?></option>"
                                <?php else: ?>
                                    <option value="<?=$period->id?>"><?=$ev_period_text?></option>"
                                <?php endif ?>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <button type="button" id="change-ev-period-btn" class="btn btn-primary cursor-p mt-2">Schimbati</button>
                    <button type="button" id="cancel-ev-period-selection-btn" class="btn btn-danger cursor-p mt-2">Anuleaza</button>
                    <button type="submit" id="save-ev-period-selection-btn" class="btn btn-success cursor-p mt-2">Seteaza</button>
                
            </div>
        </div>        
    </form>

    <div id="general-stats-row">
        
        <?php if(isset($general_stats)): ?>
            <div class="d-flex flex-row flex-wrap prof-stats-cards-row">
                <div class="card statistic-card">
                    <h5>Numarul de evaluari primite</h5>
                    <div class="card-body">
                        <h2><?=$general_stats->nr_reviews?></h2>
                    </div>
                </div>

                <div class="card statistic-card">
                    <h5>Numarul de materii predate</h5>
                    <div class="card-body">
                        <h2><?=$general_stats->nr_subjects?></h2>
                    </div>
                </div>

                <?php if($general_stats->avg_grade): ?>
                    <div class="card statistic-card">
                        <h5>Nota medie [1-4] pentru toate materiile</h5>
                        <div class="card-body">
                            <h2><?=round($general_stats->avg_grade,2)?></h2>
                        </div>
                    </div>
                <?php endif ?>

                <?php if($general_stats->nr_zero_results): ?>
                    <div class="card statistic-card">
                        <h5>Numarul de nepronuntari per evaluare</h5>
                        <div class="card-body">
                            <h2><?=round($general_stats->nr_zero_results,2)?></h2>
                        </div>
                    </div>
                <?php endif ?>

                <?php if($general_stats->avg_times_participated): ?>
                    <div class="card statistic-card" style="margin-right: 0;">
                        <h5>Media de participare la curs/seminar a studentilor</h5>
                        <div class="card-body">
                            <h2><?=round($general_stats->avg_times_participated,2)?></h2>
                        </div>
                    </div>
                <?php endif ?>

            </div>
        <?php endif ?>
    </div>

    <div class="ct-graph-container">
        <h5>Evolutia notei medii [1-4]</h5>
        <div id="avg-grade-ev-chart"></div>
    </div>

    <div id="avg-participation-ev-container" class="ct-graph-container">
        <h5>Evolutia participarii la seminarii/cursuri a studentilor</h5>
        <div id="avg-paticipation-ev-chart"></div>
    </div>

    <div id="nr-evals-container" class="ct-graph-container">
        <h5>Evolutia numarului de evaluari</h5>
        <div id="nr-evals-chart"></div>
    </div>
</div>

