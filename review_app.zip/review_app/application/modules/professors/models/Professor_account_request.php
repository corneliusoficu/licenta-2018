<?php
    class Professor_account_request extends CI_Model{

        const TABLE_NAME = "professors_accounts_requests";

        function __construct()
        {
            $this->load->database();
        }

        public function store_new_account_request()
        {   
            $email      = $this->input->post('email');
            $first_name = $this->input->post('first-name');
            $last_name  = $this->input->post('last-name');

            $query = $this
            ->db->where('email', $email)
            ->where_in('status', ['PENDING','APPROVED'])
            ->get(self::TABLE_NAME);

            if($query->num_rows() >= 1)
            {
                return FALSE;
            }

            $data = array(
                'email'           => $email,
                'first_name'      => $first_name,
                'last_name'       => $last_name,
                'status'          => 'PENDING',
                'date_of_request' => date('Y-m-d H:i:s')
            );

            $this->db->insert(self::TABLE_NAME, $data);

            return TRUE;
        }
        
        public function fetch_requests($limit, $start, $request_type = 'ALL')
        {   

            $request_type = strtoupper($request_type);

            $this->db->limit($limit, $start);
            $this->db
            ->order_by('date_of_request', 'DESC');
            
            if($request_type != 'ALL')
            {
                $this->db->where('status', strtoupper($request_type));
            }

            if($request_type == 'APPROVED')
            {
                $this->db->join('professors', 'professors.email = ' . self::TABLE_NAME . '.email');
            }
            elseif($request_type == 'ALL')
            {
                $this->db->join('professors', 'professors.email = ' . self::TABLE_NAME . '.email', 'left');
            }

            $query = $this->db->get(self::TABLE_NAME);
            
            if($query->num_rows() > 0)
            {
                foreach($query->result() as $row)
                {
                    $data[] = $row;
                }
                return $data;
            }

            return FALSE;
        }

        public function is_email_already_pending_or_aproved($email)
        {
            $query = $this->db
            ->where('email', $email)
            ->where_in('status', ['APROVED', 'PENDING'])
            ->get(self::TABLE_NAME);

            return $query->num_rows() > 0;
        }

        public function get_by_id($id)
        {
            $query = $this->db->where('id', $id)->get(self::TABLE_NAME);

            if($query->num_rows() != 1)
            {
                return FALSE;
            }

            return $query->row();
        }

        public function count($type = 'ALL')
        {
            if(strtoupper($type) != 'ALL')
            {
                $this->db->where('LOWER(`status`)', strtolower($type));
            }
            return $this->db->count_all_results(self::TABLE_NAME);
        }

        public function change_status($id, $new_status)
        {
            $query = $this->db->where('id', $id)->get(self::TABLE_NAME);
            if($query->num_rows() != 1)
            {
                return FALSE;
            }

            $this->db->where('id', $id);

            $this->db->update(self::TABLE_NAME, [
                'status' => $new_status
            ]);

            return $this->db->where('id', $id)->get(self::TABLE_NAME)->row();
        }
        
    }