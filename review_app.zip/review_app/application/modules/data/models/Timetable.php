<?php
    class Timetable extends CI_Model
    {
        private $TABLE_NAME             = "timetable";
        private $PROFESSORS_TABLE_NAME  = "professors";
        private $EVAL_PERIOD_TABLE_NAME = "evaluation_period";

        public $CHECK_USER_ALREADY_REVIEWED_QUERY=
        "
            select if(count(subject_id) > 0, 1, null) from user_reviews a
            join timetable b on b.id_subject = a.subject_id 
            join evaluation_period c on c.id = b.evaluation_period_id
            where a.username = '%s' and c.is_current = 1
            and b.subject = `timetable`.subject and b.type = `timetable`.type and b.professor_id = `timetable`.professor_id
        ";

        public function __construct()
        {
            $this->load->database();
        }

        public function get_subject_for_id($id)
        {
            $query = $this->db->where('id_subject', $id)
            ->get($this->TABLE_NAME);

            if($query->num_rows() > 0)
            {
                return $query->result()[0];
            }
            
            return null;
        }

        public function save_timetable($timetable, $evaluation_period_id)
        {
            foreach($timetable as $timetableEntry)
            {   
                $this->Timetable->insert_timetable_entry($timetableEntry, $evaluation_period_id);
            }
        }

        public function insert_timetable_entry($entry, $evaluation_period_id)
        {
            $data = [
                'subject'              => $entry['Subject'],
                'year'                 => $entry['Year'],
                'type'                 => $entry['Type'],
                'group'                => $entry['Group'],
                'professor_id'         => $entry['Id'],
                'evaluation_period_id' => $evaluation_period_id
            ];

            $this->db->insert($this->TABLE_NAME, $data);
        }

        public function get_timetable_info_for_year_query($username, $user_group, $search_query)
        {

            if($search_query == "")
            {
                return $this->get_review_items_for_student_group($username, $user_group);
            }

            $year = get_year_from_group($user_group);

            $search_db_query_where = "(subject like '%$search_query%' or full_name like '%$search_query%' or type like '%$search_query%')";

            $sub_query = sprintf($this->CHECK_USER_ALREADY_REVIEWED_QUERY, $username);

            $query = $this->db
            ->select("*, ($sub_query) as already_reviewed", false)
            ->from($this->TABLE_NAME)
            ->join($this->PROFESSORS_TABLE_NAME, 
                    "$this->TABLE_NAME.professor_id = $this->PROFESSORS_TABLE_NAME.id_professor")
            ->join($this->EVAL_PERIOD_TABLE_NAME, "$this->TABLE_NAME.evaluation_period_id = $this->EVAL_PERIOD_TABLE_NAME.id")
            ->where("$this->TABLE_NAME.year", $year)
            ->where("$this->EVAL_PERIOD_TABLE_NAME.is_current", TRUE)
            ->where($search_db_query_where)
            ->group_by(array('subject', 'type', 'full_name'))
            ->get();

            return $this->create_array_from_query_result($query->result());  
        }

        //TODO: Error handling
        public function get_all_groups_from_timetable()
        {
            $TABLE_NAME = "timetable";
            $COLUMN     = "group";

            $this->db->select($COLUMN);
            $this->db->distinct();
            $this->db->order_by($COLUMN, "ASC");

            $query = $this->db->get($TABLE_NAME);
            $groups = array();
            
            foreach($query->result() as $row)
            {
                array_push($groups, $row->group);
            }

            return $groups;

        }

        public function get_groups_by_query()
        {
            $query = $this->db
            ->select('group')
            ->distinct()
            ->from($this->TABLE_NAME)
            ->join("$this->EVAL_PERIOD_TABLE_NAME", 
            "$this->TABLE_NAME.evaluation_period_id = $this->EVAL_PERIOD_TABLE_NAME.id")
            ->where("$this->EVAL_PERIOD_TABLE_NAME.is_current", TRUE)
            ->order_by("$this->TABLE_NAME.group", "ASC");

            $group_like = $this->input->get('q');
            if($group_like)
            {
                $query->like("$this->TABLE_NAME.group", $group_like);
            }

            $query = $query->get();

            return $query->result();
        }

        public function get_review_items_for_student_group($username, $group)
        {
            $ci = get_instance();

            $course_ids = get_course_ids_from_group($group);
            array_push($course_ids, $group);
            
            $sub_query = sprintf($this->CHECK_USER_ALREADY_REVIEWED_QUERY, $username);

            $query = $this->db
            ->select("*, ($sub_query) as already_reviewed", false)
            ->from($this->TABLE_NAME)
            ->join($this->PROFESSORS_TABLE_NAME, 
                    "$this->TABLE_NAME.professor_id = $this->PROFESSORS_TABLE_NAME.id_professor")
            ->join($this->EVAL_PERIOD_TABLE_NAME,
                    "$this->TABLE_NAME.evaluation_period_id = $this->EVAL_PERIOD_TABLE_NAME.id")
            ->where('is_current', 1)
            ->where_in('group', $course_ids)
            ->order_by('subject ASC, type ASC, full_name ASC')
            ->get();

            return $this->create_array_from_query_result($query->result());
        }

        public function get_evaluation_period($timetable_entry_id)
        {
            $query = $this->db
            ->select("*")->from($this->TABLE_NAME)
            ->join($this->EVAL_PERIOD_TABLE_NAME, "$this->EVAL_PERIOD_TABLE_NAME.id = $this->TABLE_NAME.evaluation_period_id")
            ->where("$this->TABLE_NAME.id_subject", $timetable_entry_id)
            ->get();

            if(count($query->result()) > 0)
            {
                return $query->result()[0];
            } 
            else 
            {
                return NULL;
            }
        }

        public function get_number_of_professors_for_active_period()
        {
            $nr_professors = $this->db
            ->select("$this->TABLE_NAME.professor_id")
            ->distinct()
            ->from("$this->TABLE_NAME")
            ->join("$this->EVAL_PERIOD_TABLE_NAME", "$this->EVAL_PERIOD_TABLE_NAME.id = $this->TABLE_NAME.evaluation_period_id")
            ->where("$this->EVAL_PERIOD_TABLE_NAME.is_current", TRUE)
            ->count_all_results();

            return $nr_professors;
        }

        public function get_number_of_subjects_for_active_period($eval_period = NULL)
        {   
            $this->db
            ->select("$this->TABLE_NAME.subject")
            ->distinct()
            ->from("$this->TABLE_NAME")
            ->join("$this->EVAL_PERIOD_TABLE_NAME", "$this->EVAL_PERIOD_TABLE_NAME.id = $this->TABLE_NAME.evaluation_period_id");
            
            if($eval_period == NULL)
            {
                $this->db->where("$this->EVAL_PERIOD_TABLE_NAME.is_current", TRUE);
            }
            else
            {
                $this->db->where("$this->EVAL_PERIOD_TABLE_NAME.id", $eval_period->id);
            }
            
            $subjects = $this->db->count_all_results();
            return $subjects;
        }

        public function get_number_of_professors_for_period($eval_period)
        {   
            $nr_professors = $this->db
            ->select("$this->TABLE_NAME.professor_id")
            ->distinct()
            ->from("$this->TABLE_NAME")
            ->join("$this->EVAL_PERIOD_TABLE_NAME", "$this->EVAL_PERIOD_TABLE_NAME.id = $this->TABLE_NAME.evaluation_period_id")
            ->where("$this->EVAL_PERIOD_TABLE_NAME.id", $eval_period->id)
            ->count_all_results();

            return $nr_professors;
        }

        private function create_array_from_query_result($query_result){
            $info = array();
            foreach($query_result as $row)
            {
                $new_entry = array(
                    "id"                => $row->id_subject,
                    "subject"           => $row->subject,
                    "year"              => $row->year,
                    "type"              => $row->type,
                    "group"             => $row->group,
                    "professor_id"      => $row->professor_id,
                    "full_name"         => $row->full_name,
                    "rank"              => $row->rank,
                    "already_reviewed" => $row->already_reviewed
                );
                array_push($info, $new_entry);
            }
            return $info;
        }
    }
?>