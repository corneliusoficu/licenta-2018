<?php
    class Professor extends CI_Model{
        
        private $TABLE_NAME           = "professors";
        private $TIMETABLE_TABLE_NAME = "timetable";

        public function __construct()
        {
            $this->load->helper('professors/professors_accounts_helper');
            $this->load->database();
        }

        public function insert_or_update($professor_full_name, $professor_rank)
        {
            $this->db->where("full_name", $professor_full_name);
            $q = $this->db->get($this->TABLE_NAME);

            if($q->num_rows() > 0)
            {
                $this->db->where("full_name", $professor_full_name);
                $data = array(
                    'rank' => $professor_rank
                );
                $this->db->update($this->TABLE_NAME, $data);
            }
            else
            {
                $data = array(
                    'full_name' => $professor_full_name,
                    'rank' => $professor_rank
                );

                $this->db->insert($this->TABLE_NAME, $data);
            }

            $this->db->where("full_name", $professor_full_name);
            return $this->db->get($this->TABLE_NAME)->row()->id_professor;
        }

        public function delete_all()
        {
            $this->db->empty_table($this->TABLE_NAME);
        }

        //TODO: Check if update succesfull!
        public function update_professor($id)
        {
            $put_data = array();
            parse_str(file_get_contents("php://input"), $put_data);
            
            $this->db->set($put_data);
            $this->db->where('id_professor', $id);
            $this->db->update($this->TABLE_NAME);

            $query = $this->db->select('*')
                              ->where('id_professor', $id)
                              ->where($put_data)
                              ->get($this->TABLE_NAME);

            return $query->result();
            
        }

        //TODO: Maybe implement soft delete strategy, but I have to see how to handle the associated resources
        public function delete_professor($id)
        {
            $this->db->delete($this->TABLE_NAME, array('id_professor' => $id));
            $this->db->delete($this->TIMETABLE_TABLE_NAME, array('professor_id' => $id));

            $nr_profs                      = count($this->db->select('*')->where('id_professor', $id)->get($this->TABLE_NAME)->result());
            $nr_timetable_entries_for_prof = count($this->db->select('*')->where('professor_id', $id)->get($this->TIMETABLE_TABLE_NAME)->result());
            
            return ($nr_profs == 0 && nr_timetable_entries_for_prof == 0);
        }

        public function get_all($empty_email = FALSE)
        {   
            if($empty_email == TRUE)
            {
                $this->db->where('email', NULL);
            }
            $query = $this->db->get($this->TABLE_NAME);
            return $query->result();
        }

        public function get_all_as_csv($fields = NULL)
        {
            $this->load->dbutil();
            $this->db->from($this->TABLE_NAME);
            
            if($fields != NULL)
            {
                $this->db->select($fields);
            }

            $query = $this->db->get();

            $professors_csv = $this->dbutil->csv_from_result($query);
            return $professors_csv;
        }

        public function get_matching_query($empty_email = FALSE)
        {   
            $q = $this->input->get('q');
            if($q == null)
            {
                return $this->get_all($empty_email);
            }
            else
            {   
                $q = $this->db->escape("%$q%");
                $where = "(full_name like $q OR rank like $q)";
                $this->db->where($where);

                if($empty_email == TRUE)
                {
                    $this->db->where('email', NULL);
                }

                $query = $this->db->get($this->TABLE_NAME);
                return $query->result();
            }
        }

        public function set_user_account($username, $professor_id)
        {
            $data = [
                'user_account' => $username
            ];

            $this->db
            ->where('id_professor', $professor_id)
            ->update($this->TABLE_NAME, $data);
        }

        public function store_professor_credentials($professor_id, $email, $adminGroup)
        {
            $query = $this->db
            ->where('id_professor', $professor_id)
            ->get($this->TABLE_NAME);

            $professor = $query->row();

            if(!$professor)
            {
                echo "Nu exista nici-un profesor cu id-ul furnizat!";
                return FALSE;
            }

            if($professor->email)
            {
                echo "Profesorul are deja un email asociat!";
                return FALSE;
            }
            
            $new_password    = generate_random_password(25);
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            
            $data = [
                'email'                   => $email,
                'password'                => $hashed_password,
                'administrative_group_id' => $adminGroup
            ];
            try
            {
                $this->db->db_debug = FALSE;
                $this->db
                ->set($data)
                ->where('id_professor', $professor_id)
                ->update($this->TABLE_NAME);

                $db_error = $this->db->error();

                if ($db_error['code'] != 0) {
                    throw new Exception('Database error! Error Code [' . $db_error['code'] . '] Error: ' . $db_error['message']);
                }
            } 
            catch (Exception $e)
            {
                echo "Eroare in setarea datelor contului profesorului!";
                return FALSE;
            }
            
            $data['password'] = $new_password;

            return $data;
        }

        public function clear_professor_credentials($professor_email)
        {
            $data = [
                'email' => NULL,
                'password' => NULL
            ];

            $this->db
            ->where('email', $professor_email)
            ->update($this->TABLE_NAME, $data);
        }

        public function get_by_email($email)
        {
            $query = $this->db->where('email', $email)->get($this->TABLE_NAME);

            if($query->num_rows() != 1)
            {
                return NULL;
            }

            return $query->row();
        }

        public function authenticate_professor()
        {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            
            $query = $this->db->where('email', $email)->get($this->TABLE_NAME);
            if($query->num_rows() != 1)
            {
                return NULL;
            }

            $professor = $query->row();

            if(password_verify($password, $professor->password) == FALSE)
            {
                return NULL;
            }

            return $professor;
        }

        public function get_professor_rankings($ev_period)
        {   
            $rankings_query = "SELECT distinct professors.id_professor, concat(coalesce(rank, ''), full_name) as full_name, 
            (	
                select count(review_id) from reviews 
                join timetable on reviews.timetable_entry_id = timetable.id_subject 
                where timetable.evaluation_period_id = ". $this->db->escape($ev_period) ." and professors.id_professor = timetable.professor_id
            ) as nr_reviews,
            (
                select count(distinct timetable.subject) from timetable 
                where timetable.professor_id = professors.id_professor and timetable.evaluation_period_id = " . $this->db->escape($ev_period) . "
                
            ) as nr_subjects,
            (
                select avg(review_result) from responses 
                join reviews on responses.review_id = reviews.review_id
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = " . $this->db->escape($ev_period) . " and review_result != 0 and timetable.professor_id = professors.id_professor
            ) as avg_grade,
            (
                select count(review_result) / nr_reviews from responses 
                join reviews on responses.review_id = reviews.review_id
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = " . $this->db->escape($ev_period) . " and review_result = 0 and timetable.professor_id = professors.id_professor
            ) as nr_zero_results,
            (
                select avg(times_participated) from reviews
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = " . $this->db->escape($ev_period) . " and timetable.professor_id = professors.id_professor
            ) as avg_times_participated
            from professors left outer join timetable on professors.id_professor = timetable.professor_id where timetable.evaluation_period_id = " . $this->db->escape($ev_period) . "
            ";

            $query = $this->db->query($rankings_query);
            return $query->result();
        }

        public function get_professor_general_statistics($id, $ev_period)
        {
            $query_stats = "select
            (	
                select count(review_id) from reviews 
                join timetable on reviews.timetable_entry_id = timetable.id_subject 
                where timetable.evaluation_period_id = ". $this->db->escape($ev_period) ." and timetable.professor_id = ".$this->db->escape($id)."
            ) as nr_reviews,
            (
                select count(distinct timetable.subject) from timetable 
                where timetable.professor_id = ".$this->db->escape($id)." and timetable.evaluation_period_id = ". $this->db->escape($ev_period) ."
                
            ) as nr_subjects,
            (
                select avg(review_result) from responses 
                join reviews on responses.review_id = reviews.review_id
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = ". $this->db->escape($ev_period) ." and review_result != 0 and timetable.professor_id = ".$this->db->escape($id)."
            ) as avg_grade,
            (
                select count(review_result) / nr_reviews from responses 
                join reviews on responses.review_id = reviews.review_id
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = ". $this->db->escape($ev_period) ." and review_result = 0 and timetable.professor_id = ".$this->db->escape($id)."
            ) as nr_zero_results,
            (
                select avg(times_participated) from reviews
                join timetable on reviews.timetable_entry_id = timetable.id_subject
                where timetable.evaluation_period_id = ". $this->db->escape($ev_period) ." and timetable.professor_id = ".$this->db->escape($id)."
            ) as avg_times_participated";

            $query = $this->db->query($query_stats);
            return $query->row();
        }

        public function get_by_id($id)
        {
            $query = $this->db->
            where('id_professor', $id)->
            from($this->TABLE_NAME)->
            get();

            return $query->row();
        }

        public function get_professor_avg_grade_evolution($professor_id)
        {
            $avg_grade_evolution_period = "
                select evaluation_period.year_period, evaluation_period.semester, round(avg(review_result),2) as avg_grade from reviews 
                join responses on responses.review_id = reviews.review_id
                join timetable on reviews.timetable_entry_id = timetable.id_subject
            
                join evaluation_period on evaluation_period.id = timetable.evaluation_period_id
                where timetable.professor_id = ".$this->db->escape($professor_id)." and review_result != 0
                group by(timetable.evaluation_period_id) having avg(times_participated) > 0
                order by evaluation_period.year_period asc, evaluation_period.semester asc
            ";

            $query = $this->db->query($avg_grade_evolution_period);
            return $query->result();
        }

        public function get_professor_avg_participation_evolution($professor_id)
        {
            $query_participation = "
            select evaluation_period.year_period, evaluation_period.semester, round(avg(times_participated),2) as avg_participated from reviews 
            join timetable on reviews.timetable_entry_id = timetable.id_subject
            join evaluation_period on evaluation_period.id = timetable.evaluation_period_id
            where timetable.professor_id = ".$this->db->escape($professor_id)."
            group by(timetable.evaluation_period_id) having avg(times_participated) > 0
            order by evaluation_period.year_period asc, evaluation_period.semester asc
            ";

            $query = $this->db->query($query_participation);
            return $query->result();
        }

        public function get_professor_nr_evals_evolution($professor_id)
        {
            $query_nr_evals = "
            select evaluation_period.year_period, evaluation_period.semester, count(review_id) as nr_evals from reviews 
            join timetable on reviews.timetable_entry_id = timetable.id_subject 
            join evaluation_period on timetable.evaluation_period_id = evaluation_period.id
            where timetable.professor_id = ".$this->db->escape($professor_id)."
            group by timetable.evaluation_period_id having avg(times_participated) > 0
            order by evaluation_period.year_period asc, evaluation_period.semester asc";

            $query = $this->db->query($query_nr_evals);
            return $query->result();
        }
    }
?>