<?php
    $route['data/update/(:any)/(:any)'] = 'Crud_controller/update_model_data/$1/$2';
    $route['data/delete/(:any)/(:any)'] = 'Crud_controller/delete_model_data/$1/$2';

    $route['data/get_table_contents'] = 'Data_controller/get_table_contents';
    $route['data/(:any)']             = 'Data_controller/data/$1';
    $route['data']                    = 'Data_controller';