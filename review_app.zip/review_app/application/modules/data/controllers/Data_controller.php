<?php
    class Data_controller extends MX_Controller{

        const RESOURCES = array(
            'css' => array(
                'data_administration_table',
                'general/fa-svg-with-js'
            ),
            'css_remote' => array(
                'https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.css'
            ),
            'js' => array(
                'general/sweetalert.min',
                'general/moment',
                'general/daterangepicker',
                'administration_navigation_handler',
                
            ),
            'js_remote' => array(
                'https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js'
            )
        );

        public function __construct()
        {
            $this->authorization->validate_permission('can_modify_data');
            parent::__construct();
            $this->load->helper('url_helper');

            $this->tables_mapping = $this->config->item('db_tables_mapping');
        }

        public function index()
        {
            $first_table = array_keys($this->tables_mapping)[0];
            $this->data($first_table);
            redirect("data/$first_table");
        }

        public function data($table_name)
        {
            $user = $this->authorization->get_user_session();

            $data['user']  = $user;

            $this->load->helper('url');
            $this->load->helper('general/database');

            $all_tables = array_keys($this->tables_mapping);

            if(!array_key_exists($table_name, $this->tables_mapping))
            {
                $table_name = $all_tables[0];
            }

            $data['all_tables']      = $all_tables;
            $data['current_table']   = $table_name;
            $data['title']           = 'Date';
            $data['resources']       = self::RESOURCES;
            
            $table_cols  = access_array_element([$table_name, 'columns'], $this->tables_mapping);
            if($table_cols == NULL)
            {
                $table_cols = [];
            }

            $join_information = access_array_element([$table_name, 'join'], $this->tables_mapping);
            
            if($join_information)
            {   
                foreach($join_information as $join_dict)
                {
                    $joined_cols_names = access_array_element(['joined_cols'], $join_dict);
                    $table_cols = array_merge($joined_cols_names, $table_cols);
                }
            }

            $data['table_structure'] = $table_cols;
        
            $this->load->view('templates/review_header', $data);
            $this->load->view('data/data_view');
            $this->load->view('templates/review_footer');
        }

        public function get_table_contents()
        {
            $this->load->helper('general/database');
            $tables_mapping = $this->config->item('db_tables_mapping');

            $get_params = $this->input->get();
            get_table_contents($get_params);
        }
    }