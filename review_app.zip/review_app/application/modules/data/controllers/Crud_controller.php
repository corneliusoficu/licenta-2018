<?php
    class Crud_controller extends MX_Controller{

        public function __construct()
        {
            $this->authorization->validate_permission('can_modify_data');
            parent::__construct();
            
            $this->load->helper('url_helper');
            
            $this->load->library('crud_handler');
        }

        public function update_model_data($model_name, $id)
        {      
            //TODO: verify based on user group;
            if(!$this->authorization->is_user_logged_in())
            {
                http_response_code(403);
            }

            $retVal = $this->crud_handler->update_model($model_name, $id);

            $message = '';            

            if($retVal == FALSE)
            {
                $message = $this->crud_handler->get_error_message();
                http_response_code(400);
            }
            else
            {
                $message = 'Resursa a fost modificata cu succes!';
                http_response_code(201);
            }

            header('Content-Type: application/json');
            echo json_encode(['message' => $message]);
        }

        public function delete_model_data($model_name, $id)
        {
            if(!$this->authorization->is_user_logged_in())
            {
                http_response_code(403);
            }

            $retVal = $this->crud_handler->delete_model($model_name, $id);

            $message = '';            

            if($retVal == FALSE)
            {
                $message = $this->crud_handler->get_error_message();
                http_response_code(400);
            }
            else
            {
                $message = 'Resursa a fost stearsa cu succes!';
                http_response_code(204);
            }

            header('Content-Type: application/json');
            echo json_encode(['message' => $message]);
        }

    }