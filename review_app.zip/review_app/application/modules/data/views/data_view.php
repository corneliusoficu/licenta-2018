            <div class="col-administration-content">
                <div class="modal" id="edit-modal" tabindex="-1" role="dialog">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Editati</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="row p-4 inline-items-row" >
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary cursor-p" data-dismiss="modal">Renuntati</button>
                                <button type="button" class="btn btn-success cursor-p save-edit-information-button">Salvati</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row flex-row flex-wrap justify-content-left settings-cards-columns">

                    <?php
                        $db_tables      = get_tables_mapping();
                        
                        foreach($db_tables as $table_id => $table_data)
                        {   
                            $nav_card_class = "card";
                            if($table_id === $current_table)
                            {
                                $nav_card_class .= ' card-box-selected';
                            }
                            $display_name = $table_data['display_name'];
                            echo "<div class=\"$nav_card_class\" id=\"$table_id\">";
                            echo "<div class=\"card-block d-flex flex-column justify-content-center align-items-center\">";
                            if(array_key_exists('icon', $table_data) && isset($table_data['icon']))
                            {
                                echo $table_data['icon'];
                            }
                            
                            echo "<h4 id=\"subject\" class=\"card-title\">$display_name</h4>";
                            echo "</div>";
                            echo "</div>";
                        }   
                        

                    ?>                    
                </div>

                <?php if(isset($table_structure)): ?>
                    <table id="information-table" class="display" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nr. Crt.</th>
                                <?php
                                    foreach($table_structure as $column_id => $column_data)
                                    {
                                        echo "<th>" . access_array_element(["name"], $column_data) . "</th>";
                                    }
                                ?>
                                <th>Actiuni</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nr. Crt.</th>
                                <?php
                                    foreach($table_structure as $column_id => $column_data)
                                    {
                                        echo "<th>" . access_array_element(["name"], $column_data) . "</th>";
                                    }
                                ?>
                                <th>Actiuni</th>
                            </tr>
                        </tfoot>
                        <tbody>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

<?php js('data_administration_table') ?>

<script>
    const URL                = BASE_URL + "data/get_table_contents";
    const TABLE_NAME         = "<?= $current_table ?>";
    const TABLE_COLUMNS_IDS  = <?= json_encode($table_structure) ?>;

    loadDataTable(URL, TABLE_NAME, TABLE_COLUMNS_IDS);
</script>

