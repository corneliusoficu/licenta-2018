<?php
    class Statistics_controller extends MX_Controller{
        
        const RESOURCES = array(
            'css' => array(
                'statistics',
                'general/chartist-plugin-tooltip',
                'general/chartist'
            ),
            'js' => array(
                'general/loader',
                'general/chartist.min',
                'general/chartist-plugin-tooltip',
                'general/sweetalert.min',
                'statistics_chart_generator',
                
            )
        );

        public function __construct()
        {
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->helper('statistics/statistics_helper');

            $this->load->model("generators/evaluation_period");
        }
        
        public function index()
        {
            $this->authorization->validate_permission("can_view_student_statistics");
            
            $user = $this->authorization->get_user_session();
            
            $data['user']         = $user;

            $is_active = $this->evaluation_period->is_an_evaluation_active();

            if(!$is_active)
            {
                $data['is_ev_period_inactive'] = TRUE;
            }
            else
            {
                $data['statistics']   = get_general_statistics();
                $data['student_year'] = get_year_from_group($data['user']->faculty_group);
            }

            $header_data['resources'] = self::RESOURCES;
            $header_data['user']      = $data['user'];
            $header_data['title']     = "Statistici";
            
            $this->load->view('templates/review_header', $header_data);
            $this->load->view('statistics/statistics_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function get_statistics_for_year()
        {

            $user = $this->authorization->get_user_session();

            if(!isset($user->faculty_group))
            {
                $this->output->set_status_header(404)
                             ->set_output("User has no faculty group set!");
                return;
            }

            $student_year = get_year_from_group($user->faculty_group);
            
            $this->load->model('evaluation/review');
            $reviews = $this->review->get_number_of_reviews_for_each_professor_by_year($student_year);
            
            header('Content-Type: application/json');
            echo json_encode($reviews);
        }
    }