<?php
    $route['statistics']                         = 'Statistics_controller';
    $route['statistics/get_statistics_for_year'] = 'Statistics_controller/get_statistics_for_year';