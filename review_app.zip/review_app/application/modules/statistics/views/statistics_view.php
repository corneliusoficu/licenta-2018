<?php if(isset($is_ev_period_inactive)): ?>
    
    <div class="row comeback-message">
        <h5>Perioada de evaluare s-a terminat. Te rugam sa revii alta data.</h5>
    </div>
<?php else: ?>
    <div id="statistics-row">
            <?php if(isset($statistics)): ?>
                <div class="d-flex flex-row flex-wrap information-cards-row">
                    <?php foreach($statistics as $statistic): ?>
                        <?php if(isset($statistic) && array_key_exists('name', $statistic) && array_key_exists('value', $statistic)): ?>
                            <div class="card information-card">
                                <div class="card-body">
                                    <h5 class="card-title"><?=$statistic['name']?></h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="card-title mt-2"><?=$statistic['value']?></h2>
                                </div>
                            </div>
                        <?php endif ?>
                    <?php endforeach ?>
                </div>
            <?php endif ?>
            
            <?php if($student_year): ?>
                <div id="teachers-reviews-nr-chart">
                    <h5>Numarul evaluarilor pentru fiecare profesor din anul <?=$student_year?></h5>
                    <div id="chartContainer"></div>
                </div>
            <?php endif ?>
    </div>
<?php endif ?>