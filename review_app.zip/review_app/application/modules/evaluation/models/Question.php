<?php
    class Question extends CI_Model
    {
        private $TABLE_NAME = "questions";

        public function __construct()
        {
            $this->load->database();
        }

        public function get_all_questions()
        {
            $query = $this->db->get($this->TABLE_NAME);

            $all_questions_data = array_map(function($a){return (array)$a;}, $query->result());
    
            return $all_questions_data;
        }
    }
?>