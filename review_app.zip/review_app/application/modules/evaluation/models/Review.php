<?php
    class Review extends CI_Model
    {   
        
        const TABLE_NAME                   = "responses";
        const TABLE_NAME_REVIEW_RESULT     = "reviews";
        const TABLE_NAME_PROFESSORS        = "professors";
        const TABLE_NAME_TIMETABLE         = "timetable";
        const TABLE_NAME_EVALUATION_PERIOD = "evaluation_period";

        public $error_message = "";

        public function __construct()
        {
            $this->load->database();

            $this->load->model("evaluation/review_value");
            $this->load->model("evaluation/question");
        }

        public function store_new_review($timetable_entry_id)
        {   

            $date = date('Y-m-d H:i:s');
            $new_review_data = array(
                "timetable_entry_id" => $timetable_entry_id,
                "date_added"         => $date
            );

            $positive_remark = $this->input->post('reviewResult')['remarks']['positive'];
            $negative_remark = $this->input->post('reviewResult')['remarks']['negative'];

            if($positive_remark != '')
            {
                if(strlen($positive_remark) > 65535)
                {
                    $this->error_message = "Lungimea comentariului pozitiv depaseste 65535 de caractere";
                    return FALSE;
                }

                $new_review_data['positive_remark'] = $positive_remark;
            }
        
            if($negative_remark != '')
            {
                if(strlen($negative_remark) > 65535)
                {
                    $this->error_message = "Lungimea comentariului negativ depaseste 65535 de caractere";
                    return FALSE;
                }

                $new_review_data['negative_remark'] = $negative_remark;
            }

            $reviewAnswers = $this->input->post('reviewResult')['questionAnswers'];

            if(FALSE == $this->validate_review_integrity($reviewAnswers))
            {
                $this->error_message = "Datele nu sunt valide!";
                return FALSE;
            }

            

            $times_participated = $this->input->post('reviewResult')['timesParticipated'];
            
            if(!in_array($times_participated, range('0', '14')))
            {
                $this->error_message = "Numarul de participari la seminarii/cursuri trebuie sa fie intre 0 si 14!";
                return FALSE;
            }

            $new_review_data['times_participated'] = $times_participated;
            
            $this->db->insert(self::TABLE_NAME_REVIEW_RESULT, $new_review_data);
            $new_review_id = $this->db->insert_id();
            
            foreach($reviewAnswers as $answer)
            {

                $new_review_result_data = array(
                    "review_id"     => $new_review_id,
                    "question_id"   => $answer["questionId"],
                    "review_result" => $answer["questionAnswer"],
                );

                $this->db->insert(self::TABLE_NAME, $new_review_result_data);
            }

            return TRUE;
        }

        private function validate_review_integrity($review_values)
        {
            $valid_review_values_ids = array_map(function($r) { return $r['id']; },$this->review_value->get_all_review_values());
            $questions               = $this->question->get_all_questions();

            $questions_freq = [];

            foreach($questions as $question)
            {
                $questions_freq[$question['id']] = 0;
            }

            foreach($review_values as $review)
            {
                if(!array_key_exists($review['questionId'], $questions_freq))
                {
                    return FALSE;
                }

                if($questions_freq[$review['questionId']] > 0)
                {
                    return FALSE;
                }

                if(!in_array($review['questionAnswer'], $valid_review_values_ids))
                {
                    return FALSE;
                }

                $questions_freq[$review['questionId']] = 1;
            }
            return TRUE;
        }

        public function get_number_of_reviews_for_each_professor_by_year($year)
        {   
            
            $professors  = self::TABLE_NAME_PROFESSORS;
            $reviews     = self::TABLE_NAME_REVIEW_RESULT;
            $timetable   = self::TABLE_NAME_TIMETABLE;
            $eval_period = self::TABLE_NAME_EVALUATION_PERIOD;

            $query = $this->db
            ->select("$professors.rank, $professors.full_name, count(*) as count")
            ->from($reviews)
            ->join($timetable, "$timetable.id_subject = $reviews.timetable_entry_id")
            ->join($professors, "$professors.id_professor = $timetable.professor_id")
            ->join($eval_period, "$eval_period.id = $timetable.evaluation_period_id")
            ->where("$timetable.year", $year)
            ->where("$eval_period.is_current", TRUE)
            ->group_by("$professors.id_professor")
            ->get();

            return (array) $query->result();
        }

        public function get_number_of_reviews_for_active_period($eval_period = NULL)
        {  
            $reviews           = self::TABLE_NAME_REVIEW_RESULT; 
            $timetable         = self::TABLE_NAME_TIMETABLE;
            $evaluation_period = self::TABLE_NAME_EVALUATION_PERIOD;

            $this->db->from($reviews)
            ->join($timetable, "$timetable.id_subject = $reviews.timetable_entry_id")
            ->join($evaluation_period, "$timetable.evaluation_period_id = $evaluation_period.id");
            if($eval_period == NULL)
            {
                $this->db->where("$evaluation_period.is_current", TRUE);
            }
            else
            {
                $this->db->where("$evaluation_period.id", $eval_period->id);
            }

            $number_of_reviews = $this->db->count_all_results();
            return $number_of_reviews;
        }

        public function get_average_grade($evaluation_period = NULL)
        {   
            $responses = self::TABLE_NAME;
            $reviews   = self::TABLE_NAME_REVIEW_RESULT;
            $timetable = self::TABLE_NAME_TIMETABLE;

            $query = $this->db->
            select_avg('review_result')->
            from($responses)->
            join($reviews, "$reviews.review_id = $responses.review_id")->
            join($timetable, "$timetable.id_subject = $reviews.timetable_entry_id")->
            where('evaluation_period_id', $evaluation_period->id)->
            where('review_result != ', 0)->get();
            
            $result = $query->result();
            return round($result[0]->review_result, 2);
        }

        public function get_nr_reviews_distribution_by_years($evaluation_period = NULL)
        {
            $responses = self::TABLE_NAME;
            $reviews   = self::TABLE_NAME_REVIEW_RESULT;
            $timetable = self::TABLE_NAME_TIMETABLE;

            $query = $this->db->
            select('year, count(year) as number')->
            from($reviews)->
            join($timetable, "$reviews.timetable_entry_id = $timetable.id_subject")->
            where("$timetable.evaluation_period_id", $evaluation_period->id)->
            group_by("year")->
            get();

            $distribution = $query->result();
            return $distribution;
        }

        public function get_nr_reviews_evolution()
        {
            $responses         = self::TABLE_NAME;
            $reviews           = self::TABLE_NAME_REVIEW_RESULT;
            $timetable         = self::TABLE_NAME_TIMETABLE;
            $evaluation_period = "evaluation_period";

            $query = $this->db->
            select('year_period, semester, count(*) as nr_reviews')->
            from($reviews)->
            join($timetable, "$reviews.timetable_entry_id = $timetable.id_subject")->
            join($evaluation_period, "$timetable.evaluation_period_id = $evaluation_period.id")->
            group_by('evaluation_period_id')->
            order_by('year_period ASC, semester ASC')->
            get();

            $evolution = $query->result();

            return $evolution;
        }

        public function get_avg_grade_evolution()
        {
            $query = $this->db->query('SELECT year_period, semester, avg(review_result) as avg_grade FROM evaluation.responses 
            join reviews on responses.review_id = reviews.review_id
            join timetable on reviews.timetable_entry_id = timetable.id_subject
            join evaluation_period on timetable.evaluation_period_id = evaluation_period.id
            where review_result != 0
            group by evaluation_period_id
            order by year_period asc, semester asc');

            return $query->result();

        }
    }
?>