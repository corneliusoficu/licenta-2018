<?php
    class Review_value extends CI_Model{
        const TABLE_NAME = "review_values";

        public function __construct()
        {
            $this->load->database();
        }

        public function get_all_review_values()
        {
            $query = $this->db->order_by('id', 'ASC')->get(self::TABLE_NAME);

            return array_map(function($obj){return (array)$obj;}, $query->result());
            
        }

    }