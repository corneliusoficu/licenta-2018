<?php
    class User_review extends CI_Model{
        
        const TABLE_NAME                   = "user_reviews";
        const TIMETABLE_TABLE_NAME         = "timetable";
        const EVALUATION_PERIOD_TABLE_NAME = "evaluation_period";

        public function __construct()
        {
            $this->load->database();
            $this->load->model('data/timetable');
        }

        public function get_number_of_user_reviews_for_active_evaluation($username)
        {   
            $nr_reviews = $this->db
            ->from(self::TABLE_NAME)
            ->join(self::TIMETABLE_TABLE_NAME, self::TIMETABLE_TABLE_NAME.".id_subject = ".self::TABLE_NAME.".subject_id")
            ->join(self::EVALUATION_PERIOD_TABLE_NAME, self::EVALUATION_PERIOD_TABLE_NAME.".id = ".self::TIMETABLE_TABLE_NAME.".evaluation_period_id")
            ->where(self::EVALUATION_PERIOD_TABLE_NAME.".is_current", TRUE)
            ->where(self::TABLE_NAME.".username", $username)
            ->count_all_results();

            return $nr_reviews;
        }

        public function is_user_review_already_existant($username, $subject_id)
        {   


            $subject_information = $this->timetable->get_subject_for_id($subject_id);

            // Returning True because we don't want the student to evaluate an item with unknown id!
            if($subject_information == null)
            {
                return TRUE;
            }

            $query = $this->db
            ->from(self::TABLE_NAME)
            ->join(self::TIMETABLE_TABLE_NAME, self::TABLE_NAME.'.subject_id = '.self::TIMETABLE_TABLE_NAME.'.id_subject')
            ->join(self::EVALUATION_PERIOD_TABLE_NAME, self::TIMETABLE_TABLE_NAME.'.evaluation_period_id = '.self::EVALUATION_PERIOD_TABLE_NAME.'.id')
            ->where('username', $username)
            ->where('subject', $subject_information->subject)
            ->where('type', $subject_information->type)
            ->where('professor_id', $subject_information->professor_id)
            ->get();

            $count = $query->num_rows();

            return $count > 0; 
        }
        
        public function store_new_user_review($username, $subject_id)
        {
            $data = [
                'username'   => $username,
                'subject_id' => $subject_id
            ];

            $this->db
            ->insert(self::TABLE_NAME, $data);
        }

        public function get_number_of_distinct_students($eval_period = NULL)
        {
            $this->db
            ->select('username')
            ->distinct()
            ->from(self::TABLE_NAME)
            ->join(self::TIMETABLE_TABLE_NAME, self::TABLE_NAME . '. subject_id = ' . self::TIMETABLE_TABLE_NAME . '.id_subject')
            ->join(self::EVALUATION_PERIOD_TABLE_NAME, self::TIMETABLE_TABLE_NAME.'.evaluation_period_id = '.self::EVALUATION_PERIOD_TABLE_NAME.'.id');

            if($eval_period == NULL)
            {
                $this->db->where(self::EVALUATION_PERIOD_TABLE_NAME.'.is_current', TRUE);
            }
            else
            {
                $this->db->where(self::EVALUATION_PERIOD_TABLE_NAME.'.id', $eval_period->id);
            }

            return $this->db->count_all_results();
        }

        public function get_average_number_of_reviews($evaluation_period)
        {
            $user_review = self::TABLE_NAME;
            $timetable   = self::TIMETABLE_TABLE_NAME;

            $subquery = $this->db->
            select('count(username) as nr_reviews_users')->
            from($user_review)->
            join($timetable, "$timetable.id_subject = $user_review.subject_id")->
            where("$timetable.evaluation_period_id", $evaluation_period->id)->
            group_by("$user_review.username")
            ->get_compiled_select();

            $query = $this->db->
            select_avg('nr_reviews_users')->
            from("($subquery) studs")->
            get();

            $average = $query->row()->nr_reviews_users;

            return round($average, 2);

        }
    }