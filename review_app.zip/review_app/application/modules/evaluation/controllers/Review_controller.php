<?php
    class Review_controller extends MX_Controller{
        const RESOURCES = array(
            'css' => array(
                'general/select2.min',
                'homepage',
                
            ),
            'js' => array(
                'general/sweetalert.min',
                'general/select2.min',
                'general/jquery.steps.min',
                'review_homepage',
                'new_user_handler',
                'review_modal_mechanics'
            )
        );

        public function __construct()
        {
            $this->authorization->validate_permission("can_review");
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->helper('reviews/reviews_helper');

            $this->load->model('data/timetable');
            $this->load->model('evaluation/review_value');
            $this->load->model('evaluation/user_review');
            $this->load->model('generators/evaluation_period');
        }

        public function index()
        {
            $this->review();
        }

        public function review()
        {
            $user = $this->authorization->get_user_session();

            $this->load->model('timetable');
            $this->load->model('evaluation/question');

            $header_data['user']      = $user;
            $header_data['title']     = "Evaluare";
            $header_data['resources'] = self::RESOURCES;

            $is_active = $this->evaluation_period->is_an_evaluation_active();

            if(!$is_active)
            {
                $data['is_ev_period_inactive'] = TRUE;
            }
            else if($user->is_newcomer == TRUE)
            {
                $data['faculty_groups'] = $this->timetable->get_all_groups_from_timetable();
            }
            else
            {
                $data['user_subjects']             = $this->timetable->get_review_items_for_student_group($user->username, $user->faculty_group);
                $data['questions']                 = $this->question->get_all_questions();
                $data['review_values']             = $this->review_value->get_all_review_values();
                $data['questions_per_page']        = 5;
                $data['times_participated_values'] = range(0, 14);
                array_unshift($data['times_participated_values'], '-');
            }

            $data['user'] = $user;

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('evaluation/homepage', $data);
            $this->load->view('templates/review_footer');
        }

        public function new_review()
        {
            $this->load->model('evaluation/review');
            $user = $this->authorization->get_user_session();

            $user_faculty_group = $user->faculty_group;

            if($user_faculty_group == NULL)
            {
                echo "Nu aveti setata o grupa!";
                http_response_code(400);
                return;
            }

            if(!is_review_valid($user_faculty_group))
            {
                http_response_code(400);
                return;
            }
            
            $timetable_entry_id              = $this->input->post('reviewResult')['timetableId'];
            $did_user_already_review_subject = $this->user_review->is_user_review_already_existant($user->username, $timetable_entry_id);
            
            if($did_user_already_review_subject == TRUE)
            {
                echo "Ai revizuit deja aceasta materie!";
                http_response_code(400);
                return;
            }
            
            $ret_val = $this->review->store_new_review($timetable_entry_id);

            if($ret_val == null)
            {
                echo $this->review->error_message;
                http_response_code(400);
                return;
            }

            $this->user_review->store_new_user_review($user->username, $timetable_entry_id);
            
            http_response_code(201); 
        }

        public function get_reviews_for_query()
        {
            $user = $this->authorization->get_user_session();

            $this->load->model('timetable');
            
            $found_entries = $this->timetable->get_timetable_info_for_year_query(
                $user->username,
                $user->faculty_group, 
                $this->input->get("q")
            );
            
            header('Content-Type: application/json');
            echo json_encode($found_entries);
        }
    }