<?php
    $route['evaluation/review']                = 'Review_controller/review';
    $route['evaluation/get_reviews_for_query'] = 'Review_controller/get_reviews_for_query';
    $route['evaluation/new_review']            = 'Review_controller/new_review';