<?php if(isset($is_ev_period_inactive)): ?>
    
    <div class="row comeback-message">
        <h5>Perioada de evaluare s-a terminat. Te rugam sa revii alta data.</h5>
    </div>
    

<?php elseif($user->is_newcomer == TRUE): ?>

    <div class="text-center newcomer-group">
        <h5>Te rugam sa-ti selectezi grupa din care faci parte pentru a putea continua!</h5>
        <form action="<?php echo base_url() ?>registration/newcomer" method = "POST">
            <div class="group-selection-container mt-3">
                <label for="faculty-group">Grupa:</label>
                <select class="select-group" name="faculty-group">
                    <?php 
                        foreach($faculty_groups as $faculty_group)
                        {
                            echo "<option value=\"$faculty_group\">$faculty_group</option>";
                        }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success mt-3 cursor-p">Continua</button>
        </form>
    </div>

<?php else: ?>

    <div id="review-form-modal" class="modal fade" data-backdrop="static" role="dialog">
        <div class="modal-dialog modal-lg"> 
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Evalueaza<h3>
                    <button type="button" class="close align-self-top" data-dismiss="modal">&times;</button>   
                </div>
                
                <div class="modal-body d-flex flex-column">
                    
                    <p id="timetable-id" hidden></p>
                    <table id="evaluation-information">
                        <tr>
                            <td valign="top">Materie:</td>
                            <td valign="top" id="subject"></td>
                        <tr>
                        <tr>
                            <td valign="top">Tip:</td>
                            <td valign="top" id="type"></td>
                        <tr>
                        <tr>
                            <td valign="top">Profesor:</td>
                            <td valign="top" id="professor"></td>
                        </tr>
                    </table>
                    <hr/>
                    <p class="text-center">Anonimitatea va este garantata 100%. Va rugam sa evaluati cu incredere!</p>
                    <?php 
                        $nr_pages = (int)ceil(count($questions) / $questions_per_page) + 1;
                        $width    = 100 / $nr_pages;
                    ?>
                    
                    <div id="review-form">
                        <div class="progress mb-3">
                            <div class="progress-bar" role="progressbar" style="width: <?=$width?>%;" aria-valuenow="<?=$width?>" aria-valuemin="0" aria-valuemax="100"><?=$width?>%</div>
                        </div>

                        <ul class="nav nav-pills questions-pagination mb-3">
                            <?php for($index = 1; $index <= $nr_pages; $index++): ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php if($index == 1) echo 'active'; ?>" data-toggle="tab" data-step="<?=$index?>" href="#step<?=$index?>"><?=$index?></a>
                                </li>
                            <?php endfor ?>
                        </ul>

                        
                        <div class="tab-content">
                            <div class="review-information">
                                <div class="d-flex flex-column align-items-center">
                                    <?php foreach($review_values as $review_value): ?>
                                        <p><?=$review_value['id']?>=<?=$review_value['value']?>; </p>
                                    <?php endforeach ?>
                                </div>
                            </div>

                            <?php for($index_page = 1; $index_page <= $nr_pages - 1; $index_page++): ?>
                                <div class="tab-pane fade <?php if($index_page == 1) echo 'show active'; ?>" id="step<?=$index_page?>">
                                    <?php 
                                        $lower_bound = $questions_per_page * ($index_page - 1);
                                        $upper_bound = min($lower_bound + $questions_per_page, count($questions));
                                    ?>
                                    <?php for($index = $lower_bound; $index < $upper_bound; $index++): ?>
                                        <div class="form-group question-answer-group">
                                            <label id="<?=$questions[$index]['id']?>" class="form-control-label font-weight-bold question-label"><?=$index + 1?>. <?=$questions[$index]['question_text']?></label>
                                            <div class="rating-selection">
                                                <div id="selection-<?=$questions[$index]['id']?>" class="d-flex flex-row justify-content-around flex-wrap">
                                                    <?php foreach($review_values as $review_value): ?>
                                                        <div class="rating-box" id="<?=$review_value['id']?>">
                                                            <p><?=$review_value['value']?></p>
                                                        </div>
                                                    <?php endforeach ?>
                                                </div>
                                            </div>
                                            <div class="small-rating-selection">
                                                <div class = "d-flex flex-row justify-content-around ">
                                                    <?php foreach($review_values as $review_value): ?>
                                                        <div class="rating-box-id" id="<?=$review_value['id']?>">
                                                            <p><?=$review_value['id']?></p>
                                                        </div>
                                                    <?php endforeach ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endfor ?>
                                    <?php if($index_page == ($nr_pages - 1)): ?>
                                        <div class="form-group d-flex flex-row flex-wrap">
                                            <label id="times-participated-label" class="form-control-label font-weight-bold question-label mr-2">Numarul de cursuri/seminarii la care ai participat: </label> 
                                            <?php if(isset($times_participated_values)): ?>
                                                <select id="times-participated">
                                                    <?php for($index = 0, $len = count($times_participated_values); $index < $len; $index++): ?>
                                                        <option value="<?=$times_participated_values[$index]?>"><?=$times_participated_values[$index]?></option>
                                                    <?php endfor ?>
                                                </select>
                                            <?php endif ?>
                                        </div>
                                    <?php endif ?> 
                                </div> 
                            <?php endfor ?>
                            
                            <div class="tab-pane fade" id="step<?=$index_page?>">
                                <div class="form-group">
                                    <label for="positive-input-textarea" class="form-control-label font-weight-bold">Caracteristici pozitive:</label>
                                    <textarea rows="7" class="form-control" id="positive-remark"></textarea>
                                </div>
                            
                                <div class="form-group">
                                    <label for="negative-input-textarea" class="form-control-label font-weight-bold">Caracteristici negative:</label>
                                    <textarea rows="7" class="form-control" id="negative-remark"></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="wizard-nav-btn-container">
                            <button type="button" class="btn btn-light previous cursor-p mr-2">Inapoi</button>
                            <button type="button" class="btn btn-light next cursor-p">Inainte</button>
                        </div>
                        <h5 id="review-form-error" class="text-center"></h5>
                    </div>

                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary cursor-p" id="btn-close-modal">Inchide</button>
                    <button type="button" class="btn btn-success cursor-p" id="btn-send-review">Salveaza</button>
                </div>
            </div>
        </div>
    </div>

    <div class="row" id="content-row">

        <div class="d-flex flex-column cards-column w-100">

            <div class="search-container">
                <input id="review-search-input" type="text" name="search" placeholder="Materii, Profesori...">
                <i id="review-search-logo" class="fas fa-search"></i>
            </div>
                <div class="row flex-row flex-wrap" id="review-boxes-container">
                    <?php foreach($user_subjects as $entry): ?>
                        <div class="card d-flex flex-column justify-content-between <?php if(!$entry['already_reviewed']){echo 'subject-card';}?>">
                            <div class="card-body card-subject-content text-center">
                                <h4 id="subject" class="card-title"><?=$entry['subject']?></h4>
                                <p id="type" class="card-text"><small class="text-muted"><?=$entry['type']?></small></p>
                                <p id="professor" class="card-text"><?=$entry['rank']?> <?=$entry['full_name']?></p>
                            </div>
                            <div class="card-body card-id-content text-right">
                                <p id="timetable-id" hidden><?=$entry['id']?></p>
                                <?php if($entry['already_reviewed']): ?>
                                    <i class="far fa-check-circle already-reviewed-check"></i>
                                <?php endif ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            
        </div>

    </div>

<?php endif; ?>

