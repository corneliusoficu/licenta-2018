    
    <h4 class="text-center mb-4">Autentificare Profesori</h4>
    <p>Pentru a va putea autentifica trebuie sa aveti o cerere aprobata de catre administrator.</p>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email">
    </div>

    <div class="form-group">
        <label for="last-name">Parola:</label>
        <input type="password" class="form-control" id="password" name="password">
    </div>

    <button id="login-submit-button" type="submit" class="btn btn-primary btn-block">Autentificare</button>

</form>

<div class="d-flex flex-row registration-div justify-content-center">
    <p id="register-text">Nu aveti cont?</p>
    <a class="button secondary" id="register-link" href="<?php echo base_url() . "registration/professors/signup"?>">Inregistrare</a>
</div>
    