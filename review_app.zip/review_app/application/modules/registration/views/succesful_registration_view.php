<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Cerere inregistrata</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="<?php echo assets_base_url()."assets/img/favicon.png"?>" type="image/png">

        <?php 
            css('general/bootstrap.min');
            css('general/select2.min');
            css('succesfull_registration');
        ?>

        <?php
            js('general/jquery-3.2.1.min');
            js('general/popper.min');
            js('general/bootstrap.min');
            js('general/fontawesome-all.min');
        ?>
    </head>

    <body>
        <div class="container-fluid h-100 w-100">
            <div class="row w-100 h-100">
                <div class="col-lg-4 offset-lg-4 h-100">
                    <div class="align-items-center d-flex justify-content-center w-100 h-100">
                        <div class="card w-100 succesful-registration-card">
                            <div class="card-body text-center">
                                <i class="far fa-7x fa-check-circle success-icon"></i>
                                <h3 class="card-title">Cerere inregistrata cu succes!</h3>
                                <p>Dupa ce un administrator va valida cererea, veti primi prin email datele contului!</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </body>
</html>