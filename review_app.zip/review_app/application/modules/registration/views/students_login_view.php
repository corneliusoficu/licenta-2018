<!-- <div class="image-wrapper text-center">
    <img id="logo" class="standard_logo" src="<?php echo base_url() ?>img/logo_fii.png" alt="Fii" name="logo" border="0">
</div>       -->
    
    <div class="form-group">
        <label for="registration-number-input">Cont Fenrir:</label>
        <input type="username" class="form-control" id="registration-number-input" name="username">
    </div>
    <div class="form-group">
        <label for="registration-password">Parola:</label>
        <input type="password" class="form-control" id="registration-password" name="password">
    </div>

    <button id="login-submit-button" type="submit" class="btn btn-primary btn-block">Autentificare</button>

</form>


