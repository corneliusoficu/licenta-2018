    
    <h4 class="text-center mb-4">Cerere pentru cont de profesor</h4>
    <p>Pentru a va crea un cont de profesori in aplicatie, trebuie sa completati datele cerute mai jos, urmand sa primiti un mail de confirmare.</p>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email">
    </div>

    <div class="form-group">
        <label for="last-name">Nume:</label>
        <input type="text" class="form-control" id="last-name" name="last-name">
    </div>

    <div class="form-group">
        <label for="first-name">Prenume:</label>
        <input type="text" class="form-control" id="first-name" name="first-name">
    </div>

    <button id="login-submit-button" type="submit" class="btn btn-primary btn-block">Inregistrare</button>

</form>

<div class="d-flex flex-row registration-div justify-content-center">
    <p id="register-text">Aveți deja cont?</p>
    <a class="button secondary" id="register-link" href="<?php echo base_url() . "registration/professors/signin"?>">Autentificare</a>
</div>
    