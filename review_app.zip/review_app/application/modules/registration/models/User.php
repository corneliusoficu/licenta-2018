<?php 
    class User extends CI_Model
    {
        const TABLE_NAME = "users";
        private $CI = null;

        function __construct()
        {
            parent::__construct();
            $this->load->database();
            
            $this->CI =& get_instance();
            $this->CI->load->model('registration/group');
        }

        function store_user()
        {           
            $username = $this->input->post('username');
            $default_group_id = $this->CI->group->get_default_group_id();
            
            if($default_group_id == null)
            {
                return NULL;
            }
            
            $data = array(
                'username'                => $username,
                'administration_group_id' => $default_group_id
            );

            $this->db->insert(self::TABLE_NAME, $data);

            $query = $this->db->get_where(self::TABLE_NAME, $data);
            
            if($query->num_rows() == 1)
            {
                $row = $query->row();
                return $row;
            }
            else
            {
                return NULL;
            }
        }

        function get_user_by_POST()
        {   
            $is_user_valid    = FALSE;

            $username_POST = $this->security->xss_clean($this->input->post('username'));
            $password_POST = $this->security->xss_clean($this->input->post('password'));

            $query = $this->db
                    ->where('username', $username_POST)
                    ->get(self::TABLE_NAME);

            if($query->num_rows() == 1)
            {
                return $query->row();
            }
            else
            {
                return NULL;
            }
        }

        function store_newcomer_information($username)
        {
            
            $retVal = FALSE;

            $newcomer_group = $this->input->post('faculty-group');

            $retVal = is_name_group($newcomer_group);

            if($retVal == TRUE)
            {
                $this->db->set('is_newcomer', FALSE)
                ->set('faculty_group', $newcomer_group)
                ->where('username', $username)
                ->update(self::TABLE_NAME);
            }

            return $retVal;
        }

        function change_group($username, $current_user_group)
        {
            $put_data = array();
            parse_str(file_get_contents("php://input"), $put_data);
            $new_group = access_array_element(array('new_group'), $put_data);

            if($new_group == null)
            {
                echo "No group selected!";
                return null;
            }

            if(!is_name_group($new_group))
            {
                echo "Wrong name for group!";
                return null;
            }

            if($new_group == $current_user_group)
            {
                return $current_user_group;
            }

            $this->db
            ->set('faculty_group', $new_group)
            ->where('username', $username)
            ->update(self::TABLE_NAME);

            return $new_group;
        }

        function store_professor_account($username)
        {
            $professors_group_id = 4;

            $nr_users_with_username = $this->db
            ->where('username', $username)
            ->count_all_results(self::TABLE_NAME);

            $data = array(
                'username'                => $username,
                'is_active'               => TRUE,
                'faculty_group'           => '',
                'is_newcomer'             => 0,
                'administration_group_id' => $professors_group_id
            );

            if($nr_users_with_username == 1)
            {   
                $this->db
                ->where('username', $username)
                ->update(self::TABLE_NAME, $data);
            }
            else if($nr_users_with_username == 0)
            {
                $this->db->insert(self::TABLE_NAME, $data);
            }

            return TRUE;
        }
    }
