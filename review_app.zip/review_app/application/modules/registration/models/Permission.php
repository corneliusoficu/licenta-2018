<?php
    class Permission extends CI_Model{

        const TABLE_NAME = 'permissions';
        const GROUPS_PERMISSIONS_TABLE = 'groups_permissions';

        function __construct()
        {
            $this->load->database();
        }

        function get_permissions_for_group_id($group_id)
        {   
            $query = $this->db
            ->select('permission_name')
            ->from(self::TABLE_NAME)
            ->join(self::GROUPS_PERMISSIONS_TABLE, self::TABLE_NAME.'.id = '.self::GROUPS_PERMISSIONS_TABLE.'.permission_id')
            ->where(self::GROUPS_PERMISSIONS_TABLE.'.group_id', $group_id)
            ->get();

            return $query->result();
        }
    }