<?php
    class Group extends CI_Model{

        const TABLE_NAME = 'groups';

        function __construct()
        {
            $this->load->database();
        }

        function get_default_group_id()
        {
            $query = $this->db
            ->select_max('id')
            ->get(self::TABLE_NAME);

            if($query->num_rows() == 1)
            {
                $result_obj = $query->row();
                return $result_obj->id;
            }
            return NULL;
        }

        function get_all_groups()
        {
            $query = $this->db->get(self::TABLE_NAME);
            return $query->result();
        }
    }