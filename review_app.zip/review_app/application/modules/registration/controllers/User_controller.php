<?php
    class User_controller extends MX_Controller{

        public function __construct()
        {
            parent::__construct();

            $this->load->helper('url');

            $this->load->model('registration/user');
        }

        public function store_newcomer_information()
        {   
            $retCall = NULL;

            $user = $this->authorization->get_user_session();

            $retCall = array_key_exists('username', $user);

            if($retCall == TRUE)
            {
                $retCall = $this->user->store_newcomer_information($user->username);
            }

            if($retCall == TRUE)
            {
                $faculty_group = $this->input->post('faculty-group');

                $this->authorization->set_user_field('is_newcomer', FALSE);
                $this->authorization->set_user_field('faculty_group', $faculty_group);
            }

            redirect('/evaluation/review');
        }

        public function change_user_group()
        {
            $user = $this->authorization->get_user_session();
            
            $new_group = $this->user->change_group($user->username, $user->faculty_group);

            if($new_group == null)
            {
                http_response_code(400);
                return;
            }
            
            $this->authorization->set_user_field('faculty_group', $new_group);
            
            $response_data = [
                'new_group' => $new_group
            ];

            http_response_code(200);
            echo json_encode($response_data);
        }
        
    }