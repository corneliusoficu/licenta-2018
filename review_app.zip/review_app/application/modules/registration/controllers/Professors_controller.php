<?php
    class Professors_controller extends MX_Controller{
        
        private $VALIDATION_RULES_REGISTRATION = array(
			array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required|valid_email|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati un email!',
                    'max_length' => 'Email-ul depaseste 100 de caractere!',
                    'valid_email' => 'Email-ul trebuie sa fie valid!'
                )
            ),
            array(
                'field' => 'last-name',
                'label' => 'Last name',
                'rules' => 'required|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati numele de familie!',
                    'max_length' => 'Numele de familie depaseste 100 de caractere!'
                )
            ),
            array(
                'field' => 'first-name',
                'label' => 'First name',
                'rules' => 'required|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati prenumele!',
                    'max_length' => 'Prenumele depaseste 100 de caractere!'
                )
            )
        );

        private $VALIDATION_RULES_LOGIN = array(
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required|valid_email|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati un email!',
                    'max_length' => 'Email-ul depaseste 100 de caractere!',
                    'valid_email' => 'Email-ul trebuie sa fie valid!'
                )
            ),
            array(
                'field' => 'password',
                'label' => 'Parola',
                'rules' => 'required|max_length[100]',
                'errors' => array(
                        'required'   => 'Trebuie sa introduceti o parola',
                        'max_length' => 'Parola depaseste 100 de caracere!' 
                ),
            ),
        );

        public function __construct()
        {
            $this->load->library('form_validation', $this);
            
            $this->load->model('data/professor');
            $this->load->model('professors/professor_account_request');
            $this->load->model('registration/permission');
        }

        public function professors_login()
        {

            if($this->authorization->is_user_logged_in())
            {
                redirect('/professors/results');
            }

            $header_data['title']           = 'Autentificare profesori';
            $header_data['destination_url'] = base_url() . "registration/professors/authenticate_professor";

            if($this->session->flashdata('registration_messages'))
            {
                $header_data['error_messages'] = $this->session->flashdata('registration_messages');
            }

            $this->load->view('templates/registration_header', $header_data);
            $this->load->view('registration/professors_login_view');
            $this->load->view('templates/registration_footer');
        }
        
        public function professors_registration()
        {

            if($this->authorization->is_user_logged_in())
            {
                redirect('/professors/results');
            }

            $header_data['title']           = 'Inregistrare Profesori';
            $header_data['destination_url'] = base_url() . "registration/professors/new_account_request";
            
            if($this->session->flashdata('registration_messages'))
            {
                $header_data['error_messages'] = $this->session->flashdata('registration_messages');
            }

        	$this->load->view('templates/registration_header', $header_data);
            $this->load->view('registration/professors_register_view');
            $this->load->view('templates/registration_footer');
        }

        public function new_account_request()
        {
            $this->form_validation->validate_form_data($this->VALIDATION_RULES_REGISTRATION, '/registration/professors/signup');
            $result = $this->professor_account_request->store_new_account_request();
            
            if($result == FALSE)
            {
                $this->session->set_flashdata('registration_messages', array("A mai fost facuta o cerere pentru aceasta adresa de email. Verificati-va mail-ul pentru a va gasi datele de autentificare! Daca intampinati probleme, va rugam trimiteti un mesaj la evaluare-profesori@info.uaic.ro"));
                redirect('/registration/professors/signup');
            }
            
            $this->load->view('registration/succesful_registration_view');

        }

        public function authenticate_professor()
        {
            $this->form_validation->validate_form_data($this->VALIDATION_RULES_LOGIN, '/registration/professors/signin');

            $professor = $this->professor->authenticate_professor();

            if($professor == NULL)
            {
                $this->session->set_flashdata('registration_messages', array("Verificati email-ul sau parola."));
                redirect('/registration/professors/signin');
                return;
            }

            $professor->permissions = $this->permission->get_permissions_for_group_id($professor->administrative_group_id);
            $this->authorization->store_user_session($professor, 'professor');

            redirect('/professors/results');

        }
    }