<?php
    ini_set('max_execution_time', 0); 
	class Login_controller extends MX_Controller{

		private $VALIDATION_RULES = array(
			array(
                'field' => 'username',
                'label' => 'Username',
                'rules' => 'required|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati un nume de cont!',
                    'max_length' => 'Numele de cont depaseste 100 de caractere!'
                )
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'required|max_length[100]',
                'errors' => array(
                    'required' => 'Trebuie sa furnizati o parola!',
                    'max_length' => 'Parola depaseste 100 de caractere!'
                )
            )
        );

        public function __construct()
        {
            parent::__construct();

            $this->load->helper('url');
            $this->load->helper('registration/registration_helper');

        	$this->load->library('session');
            $this->load->library('form_validation', $this);

            $this->load->model('registration/user');
            $this->load->model('registration/permission');
        }

        public function index()
        {
        	redirect('/registration/login');
        }

        public function login()
        {
            if($this->authorization->is_user_logged_in())
            {
                redirect('/evaluation/review');
            }

            if($this->session->flashdata('registration_messages'))
            {
                $header_data['error_messages'] = $this->session->flashdata('registration_messages');
            }

            $header_data['title']           = 'Autentificare';
            $header_data['destination_url'] = base_url() . "registration/login_user";
            
            $this->load->view('templates/registration_header', $header_data);
            $this->load->view('registration/students_login_view');
            $this->load->view('templates/registration_footer');
        }

        public function login_user()
        {   
            $this->form_validation->validate_form_data($this->VALIDATION_RULES, '/registration/login');
            
            if(ENVIRONMENT == 'development')
            {
                $user = $this->input->post('username');
                if($user == 'student_account')
                {
                    $auth_result = TRUE;
                }
                else
                {
                    $auth_result = authenticate_faculty_credentials_IMAP();
                }
            }
            else
            {
                $auth_result = authenticate_faculty_credentials_LDAP();
            }

            if(!$auth_result)
            {   
                $this->session->set_flashdata('registration_messages', array("Verifica numele de cont sau parola."));
                redirect('/registration/login');
                return;
            }

            $user = $this->user->get_user_by_POST();

            if($user != NULL && $user->is_active == FALSE)
            {
                $this->session->set_flashdata('registration_messages', array("Acest cont este dezactivat! Contacteaza-ne la evaluare-profesori@info.uaic.ro pentru lamuriri!"));
                redirect('/registration/login');
                return;
            }

            if($user == NULL)
            {
                $user = $this->user->store_user();
            }

            if($user == NULL)
            {
                $this->session->set_flashdata('registration_messages', array("Eroare fatala, te rugam sa contactezi un administrator!"));
                redirect('/registration/login');
                return;
            }

            $user->permissions = $this->permission->get_permissions_for_group_id($user->administration_group_id);
            $this->authorization->store_user_session($user,'student');
            
            redirect('/evaluation/review');
        }

        //LOGOUT POST
        public function logout_user()
        {
            $this->authorization->logout_user();
        }
	}