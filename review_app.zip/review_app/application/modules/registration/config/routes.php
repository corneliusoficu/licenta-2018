<?php
	$route['registration/login']       = 'Login_controller/login';
	
	$route['registration/login_user']  = 'Login_controller/login_user'; /* POST */
	$route['registration/logout_user'] = 'Login_controller/logout_user'; /* POST */
	
	$route['registration/newcomer']           = 'User_controller/store_newcomer_information'; /* POST */
	$route['registration/change_user_group']  = 'User_controller/change_user_group';

	$route['registration/professors/signup']              = 'Professors_controller/professors_registration';
	$route['registration/professors/signin']              = 'Professors_controller/professors_login';
	$route['registration/professors/new_account_request'] = 'Professors_controller/new_account_request';
	
    $route['registration/professors/authenticate_professor'] = 'Professors_controller/authenticate_professor';