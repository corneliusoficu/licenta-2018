<?php
    class Generators_controller extends MX_Controller{
        
        const RESOURCES = array(
            'css' => array(
                'general/daterangepicker',
                'generator',
                
            ),
            'js'  => array(
                'generators',
                'general/moment',
                'general/daterangepicker'
            )
        );

        public function __construct()
        {   
            $this->authorization->validate_permission("can_generate_new_evaluation_period");
            parent::__construct();

            $this->load->helper('url_helper');
            $this->load->helper('general/datetime_helper');
            $this->load->helper(array('form', 'url'));

            $this->load->model('generators/evaluation_period');
            $this->load->model('data/Timetable');
            $this->load->model('data/Professor');

            $this->load->library('session');
        }

        public function index()
        {

            $header_data['title']     = 'Generatori';
            $header_data['resources'] = self::RESOURCES;
            
            $error = $this->session->flashdata('error');
            $success = $this->session->flashdata('success');

            if(isset($error))
            {
                $data['error_message'] = $error;
            }
            else if(isset($success))
            {
                $data['success_message'] = $success;
            }

            $university_periods_information = determine_university_periods();

            $data['years']     = $university_periods_information["years"];
            $data['cur_index'] = $university_periods_information["current_period_index"];

            $this->load->view('templates/review_header',    $header_data);
            $this->load->view('generators/generators_view', $data);
            $this->load->view('templates/review_footer',    $header_data);
        }

        public function create_new_evaluation_period()
        {      
            $generation_type = $this->input->post("generationType"); 
            
            if(!isset($generation_type))
            {
                $this->session->set_flashdata('error', "Nu a fost furnizata o valoare pentru tipul sursei de date!");
            } 
            else
            {
                switch($generation_type)
                {
                    case 'auto':
                        $this->save_evaluation_period_auto();
                        break;
                    case 'old_scraper_upload':
                        $this->save_evaluation_period_from_arrays_file();
                        break;
                    default:
                        $this->session->set_flashdata('error', "Ne pare rau, sursa de date nu poate fi folosita!");
                        break;
                }
            }
            
            redirect('/generators');
        }

        private function save_evaluation_period_auto()
        {   
            
            $this->load->helper('scrapers/timetable_scraper');
            try
            {
                $timetable_array = extract_timetable();
            }
            catch(Exception $e)
            {
                $this->session->set_flashdata('error', $e->getMessage());
                return;
            }
                
            $evaluation_period_insert_id = $this->evaluation_period->store_new_evaluation_period();

            if($evaluation_period_insert_id == FALSE)
            {
                $error_message = $this->evaluation_period->get_error_message();
                $this->session->set_flashdata('error', $error_message);
                return;
            }

            $this->save_timetable($timetable_array, $evaluation_period_insert_id);
            $this->session->set_flashdata('success', 'Perioada de evaluare adauga cu success impreuna cu datele din orar! Intrati pe pagina de date si verificati consistenta lor!');
            
        }

        private function save_evaluation_period_from_arrays_file()
        {
            $this->load->helper('string');

            $config['upload_path']   = realpath(APPPATH . '../uploads');
            $config['file_name']     = random_string('alnum', 20);
            $config['allowed_types'] = 'txt';
            $config['max_size']      = '100';

            $this->load->library('upload', $config);

            $filename_with_extension = NULL;

            if ( ! $this->upload->do_upload("arrays_file"))
            {      
                $this->session->set_flashdata('error', "Fisierul nu a putut fi uploadat!");
            }
            else
            {   
                $filename_with_extension = $this->upload->data('file_name');
                $this->session->set_flashdata('success', "Perioada de evaluare generata cu success din fisierul furnizat!");
            }

            if($filename_with_extension)
            {
                $this->load->helper('scrapers/adapters/arrays_file_adapter');
                $uploaded_file_complete_path = $config['upload_path'].'\\'.$filename_with_extension;

                $evaluation_period_insert_id = $this->evaluation_period->store_new_evaluation_period();

                $timetable_information = convert_to_current_format($uploaded_file_complete_path);
                $this->save_timetable($timetable_information, $evaluation_period_insert_id);

                unlink($uploaded_file_complete_path);
            }
        }

        private function save_timetable($timetable_information, $evaluation_period_id)
        {
            $this->load->helper('scrapers/adapters/timetable_adapter');
            
            $this->save_each_professor($timetable_information);
            
            $timetable = convert_to_timetable_format($timetable_information);
            
            $this->Timetable->save_timetable($timetable, $evaluation_period_id);
        }

        private function save_each_professor(&$timetable_information)
        {
            
            $name_id_mapping = array();
            foreach($timetable_information as $professor_name => $professor_information)
            {
                $professor_rank = $professor_information['Rank'];
                $professor_id = $this->Professor->insert_or_update($professor_name, $professor_rank);
                $name_id_mapping[$professor_name] = $professor_id;
            }

            foreach($name_id_mapping as $name => $id)
            {
                $timetable_information[$id] = $timetable_information[$name];
                unset($timetable_information[$name]);
            }
        }
    }