<?php
    $route['generators']            = 'Generators_controller';
    $route['generators/evaluation'] = 'Generators_controller/create_new_evaluation_period';