<?php if (isset($error_message)): ?>
    <div class="card mb-3 error-card">
        <div class="card-body">
            <h5 class="card-title">Eroare!</h5>
            <p class="card-text">• <?= $error_message ?></p>
        </div>
    </div>
<?php elseif (isset($success_message)): ?>
    <div class="card mb-3 success-card">
        <div class="card-body">
            <h5 class="card-title">Succes!</h5>
            <p class="card-text">• <?= $success_message ?></p>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <h4>Perioada de evaluare</h4>
        <p>Aici puteti configura o noua perioada de evaluare, in functie de setarile pe care le alegeti. Aplicatia va fi deschisa pentru studenti in intervalul de timp specificat pentru a se putea evalua.</p>
      
        <form action="<?php echo base_url() ?>generators/evaluation" method="POST" enctype="multipart/form-data" accept-charset="utf-8">
            <hr>
            <div class="form-group row">
                <label for="semesterSelect" class="col-sm-2 label-lg col-form-label">Semestru:</label>
                <div class="col-sm-10">
                    <select class="custom-select mr-sm-2" name="semester" id="semesterSelect">
                        <option value="1" selected>Semestrul 1</option>
                        <option value="2">Semestrul 2</option>
                    </select>
                </div>
            </div>

            <div class="form-group row">
                <label for="universityPeriodSelect" class="col-sm-2 label-lg col-form-label">An universitar:</label>
                <div class="col-sm-10">
                    <select class="custom-select mr-sm-2" name="universityPeriod" id="universityPeriodSelect">
                        <?php

                            $length = count($years);
                            for($index = 0; $index < $length; $index++)
                            {   
                                $content = $years[$index]->start_year . " - " . $years[$index]->end_year;
                                if($index == $cur_index)
                                {   
                                    echo "<option selected>$content</option>";
                                }
                                else
                                {
                                    echo "<option>$content</option>";
                                }
                            }
                        ?>
                    </select>
                    
                </div>
            </div>

            <hr>
            
            <div class="form-group row">
                <label for="periodSelectionInput" class="col-sm-2 label-lg col-form-label">Perioada de evaluare:</label>
                <div class="col-xl-3 col-lg-4 col-md-5 col-sm-6 col-10">
                    <input type='text' name="evaluationPeriod" class="form-control" id='periodSelectionInput' />
                </div>
            </div>

            <div class="form-group row">
                <label for="generationMethod" class="col-sm-2 label-lg col-form-label">Sursa de date pentru evaluare:</label>
                <div class="col-lg-10">
                
                    <div class="form-check">
                        <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="generationType" id="exampleRadios1" value="auto" checked>
                            Orar, prin extragere automata
                        </label>
                        <i rel="tooltip" title="Informatiile curente din orar vor fi extrase automat si adaugate in tabele. Studentii vor evalua dupa grupa din care fac parte!" class="fas fa-question-circle"></i>
                    </div>
                    
                    <div class="form-check">
                        <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="generationType" id="exampleRadios2" value="excel">
                            CSV
                        </label>
                        <i rel="tooltip" title="Incarcati un fisier CSV, dupa formatul: 'GRUPA,DISCIPLINA,TIP,PROFESOR'. Studentii vor evalua dupa grupa din care fac parte!" class="fas fa-question-circle"></i>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="generationType" id="exampleRadios2" value="old_scraper_upload">
                            Upload arrays, scraper vechi 
                        </label>
                        <i rel="tooltip" title="Incarcati un fisier ce contine rezultatul obtinut din scraper-ul vechi. Studentii vor putea evalua DOAR dupa anul din care fac parte!" class="fas fa-question-circle"></i>
                    </div>
                    
                    <div id="upload-div" style="visibility: hidden">
                        <label for="file">Fisier: </label>
                        <input type="file" id="file" name="arrays_file" disabled>
                    </div>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-success cursor-p">Generare</button>

        </form>
    </div>
</div>