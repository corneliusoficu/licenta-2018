<?php
    class Evaluation_period extends CI_Model{
        const TABLE_NAME         = "evaluation_period";
        const POSSIBLE_SEMESTERS = [1, 2];

        public $semester;
        public $start_of_evaluation;
        public $end_of_evaluation;
        public $year_period;
        public $is_current;

        private $error_message = "";
        
        public function __construct()
        {
            $this->load->database();
        }

        public function store_new_evaluation_period()
        {   
            $post_data = $this->input->post();

            if(!$this->is_generation_data_valid($post_data))
            {
                return FALSE;
            }

            if($this->db->where('is_current', 1)->get(self::TABLE_NAME)->num_rows() > 0)
            {
                $this->error_message = "Exista deja o evaluare in curs! Anulati precedenta evaluare pentru a adauga una noua!";
                return FALSE;
            }

            $this->is_current           = TRUE;

            $this->db->insert(self::TABLE_NAME, $this);

            return $this->db->insert_id();
        }

        public function get_all_by_date_desc()
        {
            $query = $this->db
            ->from(self::TABLE_NAME)
            ->order_by('year_period DESC, semester DESC')
            ->get();

            return $query->result();
        }

        public function get_error_message()
        {
            return $this->error_message;
        }

        public function is_an_evaluation_active()
        {
            $query = $this->db
            ->from(self::TABLE_NAME)
            ->where('is_current', TRUE)
            ->get();

            if($query->num_rows() >= 1)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }

        private function is_generation_data_valid($post_data)
        {
            return
                $this->validate_semester($post_data) &&
                $this->validate_date_range($post_data) &&
                $this->validate_university_period($post_data);
        }

        private function validate_semester($post_data)
        {   
            if(!array_key_exists("semester", $post_data))
            {
                $this->error_message = "Trebuie introdus semestrul!";
                return FALSE;
            }

            if(!in_array($post_data["semester"], self::POSSIBLE_SEMESTERS))
            {
                $this->error_message = "Semestrul trebuie sa fie 1 sau 2!";
                return FALSE;
            }

            $this->semester = $post_data["semester"];

            return TRUE;
        }

        private function validate_date_range($post_data)
        {   
            define("REGEX_DATE_PERIOD", "/([0-9]{2}-[0-9]{2}-[0-9]{4})/");

            if(!array_key_exists("evaluationPeriod", $post_data))
            {   
                $this->error_message = "Perioada de evaluare trebuie introdusa!";
                return FALSE;
            }

            $evPeriod = $post_data["evaluationPeriod"];

            if(!preg_match_all(REGEX_DATE_PERIOD, $evPeriod, $match))
            {
                $this->error_message = "Format perioada evaluare: ZI-LUNA-AN - ZI-LUNA-AN!";
                return FALSE;
            }

            if(count($match) != 2)
            {
                $this->error_message = "Format perioada evaluare: ZI-LUNA-AN - ZI-LUNA-AN!";
                return FALSE;
            }

            $startPeriod = strtotime($match[0][0]);
            $endPeriod   = strtotime($match[0][1]);

            if($startPeriod > $endPeriod)
            {
                $this->error_message = "Data de inceput trebuie sa fie mai mica decat data de sfarsit!";
                return FALSE;
            }

            $this->start_of_evaluation = date('Y-m-d H:i:s', $startPeriod);
            $this->end_of_evaluation   = date('Y-m-d H:i:s', $endPeriod);

            return TRUE;
        }

        private function validate_university_period($post_data)
        {
            define("REGEX_YEAR_PERIOD", "/[0-9]{4} - [0-9]{4}/");

            if(!array_key_exists("universityPeriod", $post_data))
            {  
                $this->error_message = "Trebuie introdus anul universitar!";
                return FALSE;
            }

            $univPeriod = $post_data["universityPeriod"];

            if(!preg_match(REGEX_YEAR_PERIOD, $univPeriod, $match))
            {
                $this->error_message = "Format an universitar: AN - AN";
                return FALSE;
            }

            $this->year_period = $univPeriod;

            return TRUE;
        }
    }