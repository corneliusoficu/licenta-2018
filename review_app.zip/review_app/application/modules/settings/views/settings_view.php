
<div class="card account-card">
    <div class="card-body">
        <h4 class="card-title">Setari</h4>
        <hr>
        <div class="row row-setting-item tex">
            <div class="col-xl-2 col-lg-2 col-md-2">
                <p>Utilizator:</p>
            </div>
            <div class="col-xl-10 col-lg-10 col-md-2">
                <?php if($user->user_type == 'student'): ?>
                    <p><?php echo ($user->username)?></p>
                <?php elseif($user->user_type == 'professor'): ?>
                    <p><?php echo $user->rank . ' '. $user->full_name; ?></p>
                <?php endif ?>
                
            </div>
        </div>
        <hr>
        <?php if($this->authorization->has_permission('can_change_group')): ?>
            <div class="row row-setting-item tex">
                <div class="col-xl-2 col-lg-2 col-md-2">
                    <p>Grupa:</p>
                </div>
                <div class="col-xl-10 col-lg-10 col-md-2">
                    
                        <?php if(isset($user->faculty_group)): ?>
                            <div class="d-flex text-center group-information">
                                <p id="student-group"><?= $user->faculty_group?></p>
                                <select class="group-select">
                                <?php 
                                    foreach($available_groups as $faculty_group)
                                    {
                                        echo "<option value=\"$faculty_group\">$faculty_group</option>";
                                    }
                                ?>
                                </select>
                                <a class="change-group-btn ml-3 cursor-p"><i class="fas fa-pencil-alt fa-sm align-self-center change-group-btn"></i></a>
                                <a class="save-group-btn ml-3 cursor-p"><i class="fas fa-check fa-sm align-self-center"></i></a>
                                <i class="loading-spinner fas fa-circle-notch fa-spin fa-sm ml-3 align-self-center"></i>
                                <a class="cancel-group-btn ml-3 cursor-p"><i class="fas fa-times fa-sm align-self-center"></i></a>
                            </div>
                        <?php endif ?>
                </div>
            </div>
            <hr>
        <?php endif ?>
        <form action="<?php echo base_url() ?>registration/logout_user" method="POST">
            <button type="submit" class="btn btn-danger cursor-p">Delogare</button>
        </form>
    </div>
</div>
<?php if (isset($error_message_complaint)): ?>
    <div class="card complaint-error-card">
        <div class="card-body">
            <h5 class="card-title">Eroare!</h5>
            <p class="card-text">• <?= $error_message_complaint ?></p>
        </div>
    </div>
<?php elseif (isset($success_message_complaint)): ?>
    <div class="card complaint-success-card">
        <div class="card-body">
            <h5 class="card-title">Succes!</h5>
            <p class="card-text">• <?= $success_message_complaint ?></p>
        </div>
    </div>
<?php endif; ?>
<div class="card complaint-card">
    <div class="card-body">
        <h4 class="card-title">Ceva gresit cu aceasta aplicatie?</h4>
        <p>Lasa-ne un mesaj si vom incerca sa rezolvam cat mai repede.</p>
        <p>Ne puteti lasa un mesaj si la urmatoarea adresa de email: <a href="mailto:evaluare-profesori@info.uaic.ro?Subject=Problema%20aplicatie%20evaluare%20profesori" target="_top">evaluare-profesori@info.uaic.ro</a>.</p>
        <hr>
        <form action="<?php echo base_url()?>settings/complaints" method="POST">
            <textarea class="form-control" name="complaint" id="exampleFormControlTextarea1" rows="5"></textarea>
            <button type="submit" class="btn btn-success cursor-p mt-3">Trimite</button>
        </form>
    </div> 
</div>