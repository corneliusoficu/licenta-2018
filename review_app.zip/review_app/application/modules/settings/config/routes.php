<?php
    $route['settings']            = 'Settings_controller';
    $route['settings/groups']     = 'Settings_controller/get_groups_by_query';
    $route['settings/complaints'] = 'Settings_controller/new_complaint';