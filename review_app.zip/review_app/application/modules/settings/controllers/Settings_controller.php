<?php
    class Settings_controller extends MX_Controller{
        
        const RESOURCES = [
            'css' => [
                'general/select2.min',
                'settings'
            ],
            'js' => [
                'general/select2.min',
                'settings'
            ]
        ];

        public function __construct()
        {
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->helper('frontend/select2_helper');

            $this->load->library('session');

            $this->load->model('data/timetable');
            $this->load->model('complaints/complaint');
        }

        public function index()
        {   
            $user = $this->authorization->get_user_session();

            $error   = $this->session->flashdata('error_complaint');
            $success = $this->session->flashdata('success_complaint');
            if(isset($error))
            {
                $data['error_message_complaint'] = $error;
            }
            if(isset($success))
            {
                $data['success_message_complaint'] = $success;
            }

            $data['user']             = $user;
            $data['available_groups'] = $this->timetable->get_all_groups_from_timetable();

            $header_data['resources'] = self::RESOURCES;
            $header_data['title']     = "Setari";

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('settings/settings_view', $data);
            $this->load->view('templates/review_footer');
        }

        public function get_groups_by_query()
        {
            $this->authorization->validate_permission('can_change_group');
            $groups = $this->timetable->get_groups_by_query();
            $select2_groups = convert_groups_to_select2_format($groups);
            header('Content-Type: application/json');
            echo json_encode($select2_groups);
        }

        public function new_complaint()
        {
            $this->authorization->authorize_logged_in();

            $response = $this->complaint->store_new_complain();

            if(!$response)
            {
                $this->session->set_flashdata('error_complaint', $this->complaint->error_message);
            }
            else
            {
                $this->session->set_flashdata('success_complaint', 'Mesaj inregistrat cu success!');
            }
            
            redirect('/settings');
        }
    }