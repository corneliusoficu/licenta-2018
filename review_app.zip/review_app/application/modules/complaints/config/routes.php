<?php
    $route['complaints'] = 'Complaints_controller';
    $route['complaints/(:any)'] = 'Complaints_controller';