<div class="complaints-container h-100">
    <?php if(isset($results)): ?>
        <?php $index = 0 ?>
        <?php foreach($results as $result): ?>
            <div class="card message-card">
                <div class="card-header cursor-p d-flex align-items-center flex-wrap" id="heading<?=$index?>" data-toggle="collapse" data-target="#collapse<?=$index?>" aria-expanded="true" aria-controls="collapseOne">
                    <p class="mr-auto header-text" >
                        <?php echo substr($result->complaint, 0, 50) . '...' ?>
                    </p>
                    <p class="complaint-date"><?=date("d-M-Y", strtotime($result->date_added));?></p>
                </div>

                <div class="collapse" id="collapse<?=$index?>">
                    <div class="card-body">
                        <p><?=$result->complaint?>    
                    </div>
                </div>
            </div>  
            <?php $index++ ?>
        <?php endforeach ?>
        
        <?php echo $links; ?>

    <?php endif ?>
</div>
