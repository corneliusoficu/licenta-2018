<?php
    class Complaints_controller extends MX_Controller{
        
        const RESOURCES = [
            'css' => [
                'complaints'
            ],
            'js' => [
                'complaints'
            ]
        ];

        public function __construct()
        {
            parent::__construct();
            $this->load->model('complaints/complaint');
            $this->load->helper('url_helper');
            $this->load->library('pagination');
        }

        public function index()
        {
            $this->authorization->validate_permission('can_see_complaints');

            $nr_complaints = $this->complaint->all_complaints_count();
            $config['base_url'] = base_url(). 'complaints';
            $config['total_rows'] = $nr_complaints;
            $config['per_page'] = 10;
            $config["uri_segment"] = 2;
            $config['full_tag_open'] 	= '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close'] 	= '</ul></nav></div>';
            $config['num_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['num_tag_close'] 	= '</span></li>';
            $config['cur_tag_open'] 	= '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close'] 	= '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['next_tagl_close'] 	= '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['prev_tagl_close'] 	= '</span></li>';
            
            $config['first_link'] = '&laquo; Primul';

            $config['first_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';

            $config['last_tag_open'] 	= '<li class="page-item"><span class="page-link">';
            $config['last_tagl_close'] 	= '</span></li>';

            $config['last_link'] = 'Ultimul';

            $this->pagination->initialize($config);
            $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
            
            $complaints = $this->complaint->fetch_complaints($config['per_page'], $page);
            if($complaints != FALSE)
            {   
                $data['results'] = $complaints;
            }
            
            $data['links'] = $this->pagination->create_links();
            
            $header_data['title']     = 'Plangeri';
            $header_data['resources'] = self::RESOURCES;

            $this->load->view('templates/review_header', $header_data);
            $this->load->view('complaints/complaints_view', $data);
            $this->load->view('templates/review_footer');
        }
    }