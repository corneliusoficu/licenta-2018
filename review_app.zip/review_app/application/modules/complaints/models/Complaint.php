<?php
    class Complaint extends CI_Model{
        const TABLE_NAME = 'complains';

        public $error_message = '';

        function __construct()
        {
            parent::__construct();
            $this->load->database();
        }

        public function store_new_complain()
        {
            $complaint = $this->input->post('complaint');
            if(!$complaint)
            {
                $this->error_message = 'Nu a fost furnizat nici-un mesaj!';
                return null;
            }

            if(strlen($complaint) >= 65535)
            {
                $this->error_message = 'Mesajul este mult prea lung!';
                return null;
            }

            $date = date('Y-m-d H:i:s');

            $data = array(
                'complaint'  => $complaint,
                'date_added' => $date
            );

            $this->db->insert(self::TABLE_NAME, $data);

            return TRUE;
        }

        public function fetch_complaints($limit, $start)
        {
            $this->db->limit($limit, $start);
            $query = $this->db
            ->order_by('date_added', 'DESC')
            ->get(self::TABLE_NAME);
            
            if($query->num_rows() > 0)
            {
                foreach($query->result() as $row)
                {
                    $data[] = $row;
                }
                return $data;
            }

            return FALSE;
        }

        public function all_complaints_count()
        {
            return $this->db->count_all(self::TABLE_NAME);
        }
    }

