<?php

    function get_total_number_of_evaluations_statistic($eval_period = NULL)
    {
        $CI =& get_instance();
        $CI->load->model('evaluation/Review');
        $total_nr_reviews = $CI->Review->get_number_of_reviews_for_active_period($eval_period);
        
        return array(
            'name'  => 'Numarul total de evaluari efectuate',
            'value' => $total_nr_reviews
        );
    }

    function get_total_number_of_teachers_statistic($eval_period = NULL)
    {
        $CI =& get_instance();
        $CI->load->model('data/Timetable');
        if($eval_period == NULL)
        {
            $nr_teachers = $CI->Timetable->get_number_of_professors_for_active_period();
        }
        else
        {
            $nr_teachers = $CI->Timetable->get_number_of_professors_for_period($eval_period);
        }

        return array(
            'name'  => 'Numarul total de profesori',
            'value' => $nr_teachers
        );
    }

    function get_total_number_of_subjects_statistic($eval_period = NULL)
    {
        $CI =& get_instance();
        $CI->load->model('data/Timetable');
        $nr_subjects = $CI->Timetable->get_number_of_subjects_for_active_period($eval_period);

        return array(
            'name'  => 'Numarul total de materii',
            'value' => $nr_subjects
        );
    }

    function get_user_number_of_reviews()
    {
        $CI =& get_instance();
        $CI->load->model('evaluation/User_review');

        $user = $CI->authorization->get_user_session();

        $user_nr_reviews = $CI->User_review->get_number_of_user_reviews_for_active_evaluation($user->username);
        
        return array(
            'name' => 'Numarul de evaluari efectuate de tine',
            'value' => $user_nr_reviews
        );
    }

    function get_unique_number_of_users($eval_period = NULL)
    {
        $CI =& get_instance();
        $CI->load->model('evaluation/User_review');

        $nr_users = $CI->User_review->get_number_of_distinct_students($eval_period);

        return array(
            'name' => 'Numarul de studenti care au evaluat',
            'value' => $nr_users
        );
    }

    function get_average_grade($eval_period = NULL)
    {
        $CI =& get_instance();
        $CI->load->model('evaluation/Review');

        $average_grade = $CI->Review->get_average_grade($eval_period);

        return array(
            'name' => 'Nota medie [1 - 4]',
            'value' => $average_grade
        );
    }

    function get_average_nr_reviews_per_user($eval_period)
    {
        $CI =& get_instance();
        $CI->load->model('evaluation/User_review');

        $average_nr_reviews_per_user = $CI->User_review->get_average_number_of_reviews($eval_period);

        return [
            'name'  => 'Medie nr. evaluari per student',
            'value' => $average_nr_reviews_per_user
        ];
    }

    function get_general_statistics()
    {
        $statistics = array();
        $statistics[] = get_user_number_of_reviews();
        $statistics[] = get_total_number_of_evaluations_statistic();
        $statistics[] = get_total_number_of_teachers_statistic();
        $statistics[] = get_total_number_of_subjects_statistic();
        
        return $statistics;
    }

    function get_faculty_statistics($eval_period)
    {
        $statistics   = array();
        $statistics[] = get_total_number_of_evaluations_statistic($eval_period);
        $statistics[] = get_total_number_of_teachers_statistic($eval_period);
        $statistics[] = get_total_number_of_subjects_statistic($eval_period);
        $statistics[] = get_unique_number_of_users($eval_period);
        $statistics[] = get_average_grade($eval_period);
        $statistics[] = get_average_nr_reviews_per_user($eval_period);
        return $statistics;
    }

    function convert_distribution_to_faculty_type($distribution)
    {
        $result = [];
        foreach($distribution as $dist)
        {
            if(substr( $dist->year, 0, 1 ) === "M")
            {
                $result['master'][] = $dist;
            }
            else
            {
                $result['bachelor'][] = $dist;
            }
        }

        return $result;
    }