<?php
    function send_professor_statistics()
    {   
        $dummy_data = array(
            'Vasile',
            "32",
            "15",
            "3.2",
            '+2'
        );

        $output_array['data'] = array();
        array_push($output_array['data'], $dummy_data);


        $output_array['recordsFiltered'] = 1;
        $output_array['recordsTotal']    = 1;
        echo json_encode($output_array);
    }