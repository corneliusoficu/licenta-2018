<?php
    function authenticate_faculty_credentials_IMAP()
    {   
        $ci=& get_instance();
        $faculty_imap_address = $ci->config->item('faculty_imap');     
        $mbox = @imap_open($faculty_imap_address, $_POST['username'], $_POST['password']);
        imap_errors();
        imap_alerts();
        return $mbox;
    }

    function authenticate_faculty_credentials_LDAP()
    {
        $ci=& get_instance();

        $ldapconfig['host']   = '172.17.17.15';
        $ldapconfig['basedn'] = 'dc=info,dc=uaic,dc=ro';

        $ds = ldap_connect($ldapconfig['host']);
        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);

        $dn="uid=". $_POST['username'] .",ou=people,".$ldapconfig['basedn'];

        if ($bind=ldap_bind($ds, $dn, $_POST['password'])) 
        {
            return TRUE;
        } 
        else 
        {
            return FALSE;
        }
    }