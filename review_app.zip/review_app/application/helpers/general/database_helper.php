<?php

    function does_table_exists($tablename)
    {
        return get_database_instance()->table_exists($tablename);
    }

    function get_database_instance()
    {
        $CI =& get_instance();
        $CI->load->database();
        return $CI->db;
    }

    function get_db_tables_mapping()
    {
        $CI =& get_instance();
        return $CI->config->item('db_tables_mapping');
    }

    function generate_join_query($base_table_name, $join_information)
    {
        $q_join = "";

        if($join_information && $base_table_name)
        {
            foreach($join_information as $join_element)
            {
                $joined_table_name = access_array_element(["table_name"], $join_element);
                $on_cols           = access_array_element(["on"], $join_element);

                foreach($on_cols as $first_table_col => $second_table_col)
                {
                    $first_col  = "`$base_table_name`.`$first_table_col`";
                    $second_col = "`$joined_table_name`.`$second_table_col`";

                    $q_join    .= "JOIN `$joined_table_name` ON $first_col = $second_col";
                }
            }
        }
        return $q_join;
    }

    //Pagination using limit query
    function generate_limit_query($get_params)
    {
        $q_limit = "";
        if(isset($get_params['start']) && isset($get_params['length']) && $get_params['length'] != -1)
        {
            $q_limit = "LIMIT " . $get_params['start'] . ", " . $get_params['length'];
        }
        return $q_limit;
    }

    function generate_where_query($get_params, $columns)
    {
        $q_where = "";

        if(isset($get_params['search']['value']) && $get_params['search']['value'] != "")
        {
            $q_where = "WHERE (";
            for($index = 0; $index < count($columns); $index++)
            {
                $q_where .= $columns[$index]." LIKE '%" . $get_params['search']['value'] . "%' OR ";
            }
            $q_where = substr_replace($q_where, "", -3);
            $q_where .= ')';
        }

        return $q_where;
    }

    function generate_order_query($get_params, $columns)
    {
        $q_order = "";
        if(isset($get_params['order']))
        {
            $q_order = "ORDER BY  ";
            foreach($get_params['order'] as $key => $order_col)
            {
                if(isset($order_col['column']) && isset($order_col['dir']))
                {
                    $col_idx = intval($order_col['column']) - 1;
                    $col_dir = $order_col['dir'];
                    $q_order.= "$columns[$col_idx] $col_dir  ";
                }
            }
            $q_order = substr_replace($q_order, "", -2);
            if($q_order == "ORDER BY")
            {
                $q_order = "";
            }
        }
        return $q_order;
    }

    function add_table_name_to_fields($table_name, &$fields)
    {
        $nr_fields = count($fields);
        for($index = 0; $index < $nr_fields; $index++)
        {
            $fields[$index] = "`$table_name`.`$fields[$index]`";
        }
    }

    function add_join_cols_to_columns_list($join_information, &$columns)
    {   
        if(!$join_information)
        {
            return;
        }

        $table_name = "";
        $fields     = [];

        foreach($join_information as $join_element)
        {
            $table_name = access_array_element(['table_name'], $join_element);
            $fields     = access_array_element(['joined_cols'], $join_element, "KEYS");

            if($table_name && $fields)
            {
                add_table_name_to_fields($table_name, $fields);
            }
            
            if(count($fields) > 0)
            {
                $columns = array_merge($fields, $columns);
            }
        }
    }

    //TODO: Error handling + testing
    function get_table_contents($get_params)
    {  
        $is_index_col_in_columns_array = TRUE;
        
        $output_array['data'] = array();

        $table_alias = $get_params['table'];

        $db_tables_mapping = get_db_tables_mapping();
        $table_name = access_array_element([$table_alias,'table_name'], $db_tables_mapping);
        
        $columns = access_array_element([$table_alias, 'columns'], $db_tables_mapping, "KEYS");

        if($columns == null)
        {
            $columns = [];
        }

        $indexed_column = access_array_element([$table_alias, 'index_col'], $db_tables_mapping);
        if($indexed_column == NULL && count($columns) > 0)
        {
            $indexed_column = $columns[0];
        }
        if(!array_key_exists($indexed_column, $columns))
        {
            $is_index_col_in_columns_array = FALSE;
            array_push($columns, $indexed_column);
        }
    
        add_table_name_to_fields($table_name, $columns); 

        $join_information = access_array_element([$table_alias, 'join'], $db_tables_mapping);
        add_join_cols_to_columns_list($join_information, $columns);

        $q_join  = generate_join_query($table_name, $join_information);
        $q_limit = generate_limit_query($get_params);
        $q_where = generate_where_query($get_params, $columns);
        $q_order = generate_order_query($get_params, $columns);

        $fields = implode($columns, ',');

        $custom_query = "SELECT SQL_CALC_FOUND_ROWS $fields FROM $table_name $q_join $q_where $q_order $q_limit";

        $db = get_database_instance();

        $query = $db->query($custom_query);
        
        foreach ($query->result_array() as $row)
        {

            $row["DT_RowId"] = "$row[$indexed_column]";
            
            if($is_index_col_in_columns_array == TRUE)
            {
                unset($row[$indexed_column]);
            }

            array_push($output_array['data'], $row);
        }

        $query_filtered = "SELECT FOUND_ROWS()";
        $query = $db->query($query_filtered);
        $filtered_found = array_values($query->result_array()[0])[0];

        $query_total = "SELECT COUNT(".'`'.$indexed_column.'`'.") FROM $table_name";
        $query = $db->query($query_total);
        $total_found = array_values($query->result_array()[0])[0];

        $output_array['recordsTotal'] = $total_found;
        $output_array['recordsFiltered'] = $filtered_found;

        echo json_encode($output_array);
    }