<?php

    function assets_base_url()
    {
        $ci=& get_instance();
        return $ci->config->item('assets_base_url') . '/';
    }

    function css($name, $extension = '.css')
    {
        echo '<link rel="stylesheet" href="'.assets_base_url().'assets/css/' . $name . "$extension\" type = \"text/css\" media=\"screen\" />";
    }

    function css_remote($remote_location)
    {
        echo "<link rel=\"stylesheet\" href=\"$remote_location\" type = \"text/css\" media=\"screen\" />";
    }

    function js($name)
    {
        echo '<script src="'.assets_base_url().'assets/js/' . $name . '.js"></script>';
    }

    function js_remote($remote_location)
    {
        echo "<script src=\"$remote_location\"></script>";
    }

    function load_js_resources($resources)
    {
        if(isset($resources['js']))
        {
            foreach($resources['js'] as $js_resource)
            {
                js($js_resource);
            }
        }
        if(isset($resources['js_remote']))
        {
            foreach($resources['js_remote'] as $js_resource)
            {
                js_remote($js_resource);
            }
        }
    }

    function load_css_resources($resources)
    {
        if(isset($resources['css']))
        {
            foreach($resources['css'] as $css_resource)
            {
                css($css_resource);
            }
        }

        if(isset($resources['css_remote']))
        {
            foreach($resources['css_remote'] as $css_resource)
            {
                css_remote($css_resource);
            }
        }

        if(isset($resources['scss']))
        {
            foreach($resources['scss'] as $css_resource)
            {
                css($css_resource);
            }
        }
    }

    function load_img($name, $width = NULL, $height = NULL)
    {
        if($width == NULL && $height == NULL)
        {
            echo "<img src=\"".assets_base_url()."assets/img/$name\" alt=\"$name\">";
        }
        else
        {
            echo "<img src=\"".assets_base_url()."assets/img/$name\" alt=\"$name\" height=\"$height\" width=\"$width\">";
        }
    }

    function img_html($name, $width, $height)
    {
        return "<img src=\"".assets_base_url()."assets/img/$name\" alt=\"$name\" height=\"$height\" width=\"$width\">";
    }

?>