<?php
    //Returns elements from array found at position given by structure
    function access_array_element($structure, $array, $element_type = "NONE")
    {
        $information = $array;

        foreach($structure as $level)
        {
            if(isset($information[$level]))
            {
                $information = $information[$level];
            }
            else
            {
                $information = NULL;
                break;
            }
        }

        if($information != NULL)
        {
            switch($element_type)
            {
                case "KEYS":
                    $information = array_keys($information);
                    break;
                case "VALUES":
                    $information = array_values($information);
                    break;
            }
        }
        
        return $information;
    }

    function is_name_group($name)
    {
        $REGEX_VALID_GROUP = "/^I[1-4](([a-zA-Z][0-9]+$)|(E$))?|M[a-zA-Z0-9]+/";
        return preg_match($REGEX_VALID_GROUP, $name) == 1;
    }

    function get_year_from_group($group){
        if(!$group)
        {
            return '';
        }
        $year_from_group_regex = "/(^I(?<year>[1-4]))|(?<year_master>^M[A-Za-z]*[1-2])/";

        preg_match($year_from_group_regex, $group, $matches);
        if(array_key_exists('year', $matches) && $matches['year'] != '')
        {
            return $matches['year'];
        }
        else if(array_key_exists('year_master', $matches) && $matches['year_master'] != '')
        {
            return $matches['year_master'];
        }
        else
        {
            return null;
        }
        
    }

    function get_course_ids_from_group($group)
    {
        $COURSE_REGEXES = array(
            "REGEX_OPTIONAL_COURSE_ID" => "/(?<year_id>^I[1-4])/",
            "REGEX_REGULAR_COURSE_ID"  => "/(?<year_id>^I[1-4][a-zA-Z])/"
        );

        $course_ids = array();
        foreach($COURSE_REGEXES as $regex_name => $regex)
        {
            if(preg_match($regex, $group, $matches) == 1)
            {
                array_push($course_ids, $matches['year_id']);
            }
        }

        return $course_ids;
    }

    function print_arr($array)
    {
        echo "<pre>";
        print_r($array);
        echo "</pre>";
    }

    function get_tables_mapping()
    {
        $CI =& get_instance();
        return $CI->config->item('db_tables_mapping');
    }
?>