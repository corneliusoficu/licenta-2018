<?php

    class University_period{
        public $start_year;
        public $end_year;

        public function __construct($start_year, $end_year)
        {
            $this->start_year = $start_year;
            $this->end_year   = $end_year;
        }
    }

    function determine_current_university_period()
    {   
        $university_period = new University_period(0, 0);

        $current_month = date("m");
        $current_year  = date("Y");

        if($current_month >= 10 && $current_month <= 12)
        {
            $university_period->start_year = $current_year;
            $university_period->end_year   = $current_year + 1;
        }
        else if ($current_month >= 1 && $current_month <= 9)
        {
            $university_period->start_year = $current_year - 1;
            $university_period->end_year   = $current_year;
        }

        return $university_period;
    }

    function determine_university_periods()
    {   
        $nr_periods = 5;

        $current_period = determine_current_university_period();
        $possbile_year_periods = [$current_period];

        $index = 0;
        
        while($index < $nr_periods)
        {
            array_unshift($possbile_year_periods, new University_period($current_period->start_year - $index - 1, $current_period->start_year - $index));
            array_push($possbile_year_periods, new University_period($current_period->end_year + $index, $current_period->end_year + $index + 1));
            $index++;
        }

        return array(
            "years"                => $possbile_year_periods,
            "current_period_index" => $nr_periods
        );
    }  

