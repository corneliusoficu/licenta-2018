<?php
    function convert_groups_to_select2_format($groups)
    {   
        $results = [];
        foreach($groups as $group_item)
        {   
            $group_value = $group_item->group;
            
            if($group_value == null)
            {
                continue;
            }

            $item['id']   = $group_value;
            $item['text'] = $group_value;

            array_push($results, $item);
        }

        return array(
            'results' => $results
        );
    }

    function convert_professors_to_select2_format($professors)
    {
        $results = [];
        foreach($professors as $professor)
        {
            $rank      = $professor->rank;
            $full_name = $professor->full_name;
            $id        = $professor->id_professor;

            $item['id']   = $id;
            $item['text'] = $rank . ' ' . $full_name;

            array_push($results, $item);
        }

        return array(
            'results' => $results
        );
    }