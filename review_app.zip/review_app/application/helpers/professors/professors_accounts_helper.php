<?php
    function store_professor_accounts($accounts, $professors_ids)
    {
        $nr_accounts = count($accounts);
        
        if($nr_accounts != count($professors_ids))
        {
            return FALSE;
        }

        $CI =& get_instance();

        $CI->load->model('data/professor');
        $CI->load->model('registration/user');

        for($index = 0; $index < $nr_accounts; $index++)
        {
            $CI->user->store_professor_account($accounts[$index]);
            $CI->professor->set_user_account($accounts[$index], $professors_ids[$index]);
        }

        return TRUE;
    }

    function get_new_professor_mails_from_file($filepath)
    {
        $CI =& get_instance();
        $CI->load->helper('file');
        $CI->load->library('csv_reader');

        $CI->load->model('data/professor');

        $professors_data = $CI->csv_reader->parse_file($filepath);
        
        $professors = $CI->professor->get_all();
        
        $modified_mails_professors = [];

        foreach($professors as $professor)
        {
            foreach($professors_data as $index => $uploaded_professor)
            {
                if($professor->id_professor === $uploaded_professor['id_professor'])
                {
                    if($professor->email != $uploaded_professor['email'])
                    {
                        $modified_mails_professors[] = $uploaded_professor;
                    }

                    break;
                }
            }
        }
        return $modified_mails_professors;
    }

    function generate_random_password($size)
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $count = mb_strlen($chars);

        for ($i = 0, $result = ''; $i < $size; $i++) 
        {
            $index = rand(0, $count - 1);
            $result .= mb_substr($chars, $index, 1);
        }

        return $result;
    }

    function get_mail_message($email, $password)
    {   

        $url = ENVIRONMENT == 'development' ? 'http://localhost' : 'https://profs-info.uaic.ro/~evaluare-profesori';

        $autenthication_page = $url . base_url() . 'registration/professors/signin';

        return "
            <html>
                <head>
                    <title>Cont Aplicatia de evaluare a profesorilor</title>
                </head>
                <body>
                    <p>Buna ziua,</p>
                    <p>Cererea dumneavastra pentru un cont in aplicatia de evaluare a profesorilor din Facultatea de Informatica Iasi a fost acceptata. Gasiti mai jos datele de conectare:</p>
                    <table>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td>$email</td>
                        </tr>
                        <tr>
                            <td><strong>Parola:</strong></td>
                            <td>$password</td>
                        </tr>
                    </table>
                    <p>Pagina de autentificare o puteti gasi aici: <a href=\"$autenthication_page\">$autenthication_page</a>.</p>
                    <p>Pentru neclaritati va rugam sa trimiteti un email la evaluare-profesori@info.uaic.ro.</p>
                </body>
            </html>
        ";
    }

    function send_credentials_by_email($professor_credentials)
    {   
        $email    = $professor_credentials['email'];
        $password = $professor_credentials['password'];

        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'evaluare.profesori.info.uaic.ro',
            'smtp_pass' => 'Pwd2018)($M',
            'mailtype'  => 'html', 
            'charset'   => 'iso-8859-1',
            'newline'   => "\r\n"
        );

        $ci =& get_instance();
        $ci->load->library('email', $config);

        $message = get_mail_message($email, $password);
        echo $email;
        echo "<br>";
        echo $password;

        $ci->email->from('evaluare.profesori.info.uaic.ro@gmail', 'Evaluare Profesori, Facultatea de Informatica');
        $ci->email->to($email);
        $ci->email->subject('Cerere acceptata');
        $ci->email->message($message);

        $ci->email->send();
        echo $ci->email->print_debugger();
    }