<?php

    function remove_newlines($string)
    {
        $string = trim(preg_replace('/\s+/', '', $string));
        return $string;
    }

    function find_professor_names_from_user_accounts($accounts_string)
    {
        $CI =& get_instance();
        $CI->load->model('data/professor');

        $user_accounts = explode("\n", $accounts_string);
        $user_accounts = array_filter($user_accounts);
        $user_accounts = array_map("remove_newlines", $user_accounts);

        $professor_accounts = $CI->professor->get_all();
        // print_arr($professor_accounts);

        $lowercase_user_accounts = array_map("strtolower", $user_accounts);

        $matched_accounts = [];

        // foreach($user_accounts as $account)
        for($index = 0; $index < count($user_accounts); $index++)
        {
            $best_match['professor'] = $professor_accounts[0];
            $best_match['min_value'] = PHP_INT_MAX;

            foreach($professor_accounts as $professor_account)
            {
                if($professor_account->user_account == $user_accounts[$index])
                {
                    $best_match['professor'] = $professor_account;
                    break;
                }

                $professor_name = strtolower($professor_account->full_name);
                list($last_name, $first_name) = explode(" ", $professor_name, 2);
                $professor_name = $first_name . "." . $last_name;
                $distance = calculate_minimum_distance($professor_name, $lowercase_user_accounts[$index]);
                
                if($distance < $best_match['min_value'])
                {
                    $best_match['professor'] = $professor_account;
                    $best_match['min_value'] = $distance;
                }
            }
            $matched_accounts[$user_accounts[$index]] = $best_match['professor']; 
        }
        return  $matched_accounts;
    }

    /* Implementation of the Levenshtein distance algorithm using dynamic programming*/
    function calculate_minimum_distance($source_string, $target_string)
    {
        $matrix = [];

        $len_source = strlen($source_string);
        $len_target = strlen($target_string);

        for($row = 0; $row <= $len_source; $row++)
        {
            $matrix[$row] = [];
            for($col = 0; $col <= $len_target; $col++)
            {
                $matrix[$row][$col] = 0;
            }
        }

        for($row = 1; $row <= $len_source; $row++)
        {
            $matrix[$row][0] = $row;
        }

        for($col = 1; $col <= $len_target; $col++)
        {
            $matrix[0][$col] = $col;
        }

        for($row = 1; $row <= $len_source; $row++)
        {
            for($col = 1; $col <= $len_target; $col++)
            {
                if($source_string[$row - 1] == $target_string[$col - 1])
                {
                    $substitution_cost = 0;
                }
                else
                {
                    $substitution_cost = 1;
                }

                $matrix[$row][$col] = min(
                    $matrix[$row-1][$col] + 1,
                    $matrix[$row][$col-1] + 1,
                    $matrix[$row-1][$col-1] + $substitution_cost
                );
            }
        }

        $min_value = $matrix[$len_source][$len_target];
        return $min_value;
    }