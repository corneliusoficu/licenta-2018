<?php
    function is_review_valid($user_faculty_group)
    {   
        $CI =& get_instance();
        $CI->load->model('data/timetable');

        $reviewResult = $CI->input->post('reviewResult');

        if($reviewResult == NULL)
        {
            echo "Nu a fost furnizat un raspuns";
            return FALSE;
        }

        $timetableId = access_array_element(['timetableId'], $reviewResult);

        if($timetableId == NULL)
        {
            echo "Nu a fost specificat pentru ce se face evaluarea!";
            return FALSE;
        }

        $times_participated = access_array_element(['timesParticipated'], $reviewResult);

        if($times_participated == NULL)
        {
            echo "Nu a fost specificat un numar de cursuri/seminarii la care s-a participat!";
            return FALSE;
        }

        $evaluation_period = $CI->timetable->get_evaluation_period($timetableId);

        if($evaluation_period == NULL)
        {
            echo "Eroare date server!";
            return FALSE;
        }

        if($evaluation_period->is_current != TRUE)
        {   
            echo "Nu se poate evalua o materie din anii precedenti!";
            return FALSE;
        }

        if(get_year_from_group($user_faculty_group) != get_year_from_group($evaluation_period->group))
        {
            echo "Evaluarea se poate face doar pentru anul din care faci parte!";
            return FALSE;
        }

        return TRUE;
    }