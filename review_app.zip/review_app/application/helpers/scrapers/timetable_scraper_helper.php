<?php

    error_reporting(E_ERROR);
    $ini_contents  = NULL;
    
    function handle_error($error_message)
    {
        throw new Exception($error_message);
    }

    function get_year_from_title($title)
    {
        global $ini_contents;
        $regex = $ini_contents["year_from_title_regex_bachelor"];
        $regex = '/'.$regex.'/';

        $matches = array();
        preg_match_all($regex, $title, $matches);
        $year = $matches[0][0];
        
        if($year == NULL)
        {
            $regex = $ini_contents["year_from_title_regex_master"];
            $regex = '/'.$regex.'/';

            $matches = array();
            preg_match_all($regex, $title, $matches);
            $year = $matches[0][0];
            if($year == NULL)
            {
                handle_error("Cannot get valid year from title!");
            }
        }

        return $year;
        
    }

    function is_empty($val)
    {
        for ($i = 0; $i < strlen($val); $i++)
        {
            if($val[$i] != ' ')
            {
                return 1;
            }
        }
        return 0;
    }

    function populate_timetable_information(&$timetable_information, $cells, $year, $groups = NULL)
    {
        global $ini_contents;

        $ofsset = 0;

        if($cells->length < 9)
        {
            $offset = -1;
        }

        $teachers_col_index = $ini_contents["teachers_col_index"] + $offset;
        $subjects_col_index = $ini_contents["subjects_col_index"] + $offset;
        $type_col_index     = $ini_contents["type_col_index"] + $offset;
        $group_col_index    = $ini_contents["group_col_index"] + $offset;

        $teacher_name = $cells->item($teachers_col_index)->nodeValue;
        $subject =      $cells->item($subjects_col_index)->nodeValue;
        $type    =      $cells->item($type_col_index)->nodeValue;
        
        if($groups == NULL)
        {
            $groups  = $cells->item($group_col_index)->nodeValue;
            $groups  = explode(",", $groups);
        }

        $rank_from_name_regex = $ini_contents["rank_from_name"];
        $rank_from_name_regex = '/'.$rank_from_name_regex.'/';

        $ranks = array();
        preg_match_all($rank_from_name_regex, $teacher_name, $ranks);

        $names = preg_split($rank_from_name_regex, $teacher_name);
        $filtered_names = array_values(array_filter($names, "is_empty"));

        $subject = ltrim(rtrim($subject));
        $type    = ltrim(rtrim($type));
        
        foreach($filtered_names as $index=>$name)
        {
            $name = ltrim(rtrim($name));
            if($name === '' || $name === ' ' || bin2hex($name) == 'c2a0')
            {
                continue;
            }

            if(array_key_exists($name, $timetable_information) == false)
            {
               $timetable_information[$name]['Rank'] = $ranks[0][$index];
               $timetable_information[$name]['Subjects'] = array();
            }

            if(in_array($subject, $timetable_information[$name]['Subjects']) == false)
            {   
                $timetable_information[$name]['Subjects'][$subject]['Year'] = $year;
            }
            if(array_key_exists($type, $timetable_information[$name]['Subjects'][$subject]) == false)
            {
                $timetable_information[$name]['Subjects'][$subject][$type] = array();
            }

            foreach($groups as $group)
            {
                $group = ltrim(rtrim($group));
                if(in_array($group, $timetable_information[$name]['Subjects'][$subject][$type]) == false)
                {
                    array_push($timetable_information[$name]['Subjects'][$subject][$type], $group);
                }
            }
        }
    }

    function load_page($link)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $page = curl_exec($ch);
        
        if(curl_errno($ch))
        {
            handle_error("Curl error: ".curl_error($ch));
        }

        curl_close($ch);

        if($page === false)
        {
            handle_error("Cannot acces the link ".$link);
        }

        return $page;
    }

    function extract_bachelors_information($link, &$timetable_information)
    {
        global $error_message, $ini_contents;

        $page = load_page($link);
        
        $doc = new DOMDocument();

        if($doc->loadHTML($page) == false)
        {
            handle_error("Error loading the page ".$link);
        }

        $text_h2 = $doc->getElementsByTagName($ini_contents["title_tag"]);

        if($text_h2->length > 0)
        {
            $title = $text_h2[0]->nodeValue;
            $year  = get_year_from_title($title);

            $table = $doc->getElementsByTagName('table')->item(0);
            foreach($table->getElementsByTagName('tr') as $row)
            {
                $cells = $row->getElementsByTagName('td');
                if($cells->length > 1)
                {
                    populate_timetable_information($timetable_information, $cells, $year);
                }
            }
        }
        else
        {
            handle_error("Error obtaining year from link: ".$link);
        }
    }

    function extract_masters_information($master_group, $master_link, &$timetable_information)
    {
        $page = load_page($master_link);

        $doc = new DOMDocument();

        if($doc->loadHTML($page) == false)
        {
            handle_error("Error loading the page ".$master_link);
        }

        $table = $doc->getElementsByTagName('table')->item(0);
        
        foreach($table->getElementsByTagName('tr') as $row)
        {
            $cells = $row->getElementsByTagName('td');
            if($cells->length > 1)
            {
               populate_timetable_information($timetable_information, $cells, $master_group, [$master_group]);
            }
        }
    }

    function extract_bachelors_links($filename, $links_name)
    {
        global $error_message, $ini_contents;
        $ret_val = NULL;
        if($ini_contents == NULL)
        {
            $ini_contents = parse_ini_file($filename);
        }
        
        if($ini_contents != false)
        {
            $links = $ini_contents[$links_name];
            if($links != NULL)
            {
                if(count($links) == 0)
                {
                    handle_error("No link provided in the configuration file!");
                }
                else
                {
                    return $links;
                }
            }
            else
            {
                handle_error("Cannot find the required links in the configuration file!");
            }
        }
        else
        {
            handle_error("Cannot open the configuration file!");
        }
    }

    function extract_masters_links($filename, $links_section_name)
    {
        $masters_ini_data = parse_ini_file($filename, TRUE);

        if($masters_ini_data === false)
        {
            handle_error("No master data found for the ini section provided!");
        }

        $masters_links = $masters_ini_data[$links_section_name];
        
        if(count($masters_links) == 0)
        {
            handle_error("No master links provided");
        }

        return $masters_links;
    }

    function extract_timetable()
    {
        $filename = "timetables.ini";
        $links = extract_bachelors_links($filename, 'links');

        $timetable_information = array();
        foreach($links as $link)
        {
            extract_bachelors_information($link, $timetable_information);
        }

        $masters_links = extract_masters_links($filename, "MASTER_LINKS");
        foreach($masters_links as $master_group => $link)
        {
            extract_masters_information($master_group, $link, $timetable_information);
        }

        return $timetable_information;
    }
?>