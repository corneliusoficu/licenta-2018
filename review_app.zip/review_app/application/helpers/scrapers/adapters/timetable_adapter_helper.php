<?php

    

    function adapt_year($year, $group)
    {
        $regex_is_master = "/^M[A-Za-z]*[1-2]$/";
        $val = preg_match($regex_is_master, $group);
        return $val == 1 ? $group : $year;
    }

    function convert_to_timetable_format($timetable_array)
    {   
        $index = 0;
        $timetable = array();
        foreach($timetable_array as $name=>$entry)
        {
            $rank = $entry['Rank'];
            $subjects = $entry['Subjects'];
            foreach($subjects as $subject_name=>$subject_entry)
            {
                $year = $subject_entry['Year'];
                foreach($subject_entry as $key=>$value)
                {
                    if($key != 'Year' && is_array($value))
                    {
                        foreach($value as $group)
                        {
                            $timetable_entry["Rank"] = $rank;
                            $timetable_entry["Id"] = $name;
                            $timetable_entry["Subject"] = $subject_name;
                            $timetable_entry["Group"] = $group;
                            $timetable_entry["Year"] = adapt_year($year, $group);
                            $timetable_entry["Type"] = $key;
                            array_push($timetable, $timetable_entry);
                        }
                    }
                }
            }
        }
        return $timetable;
    }
?>