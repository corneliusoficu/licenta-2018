<?php
    function is_empty($val)
    {
        for ($i = 0; $i < strlen($val); $i++)
        {
            if($val[$i] != ' ')
            {
                return 1;
            }
        }
        return 0;
    }

    /* The following script will match all items of type: $lista_de_evaluat_i1="..." */
    function convert_to_current_format($file_path)
    {   
        $array_names = [
            "\$lista_de_evaluat_i1" => 1, 
            "\$lista_de_evaluat_i2" => 2,
            "\$lista_de_evaluat_i3" => 3
        ];
        $REGEX_MATCH_YEAR                = "/%s=\"(.*?)\"/";
        $REGEX_SPLIT_SUBJECT_INFORMATION = "/#/";
        $REGEX_SPLIT_SUBJECT_DETAILS     ="/\s+-\s+/";
        $REGEX_RANK_FROM_NAME            = "/((drd|Colab|Lect|Conf|dr|Asist|Dr|Prof)\. )+|((drd|Colab|Lect|Conf|dr|Asist|Dr|Prof)\.)+ /";

        $CI =& get_instance();
        $CI->load->helper('file');

        $data = read_file($file_path);

        $timetable_information = array();

        foreach($array_names as $name => $year)
        {
            $name  = preg_quote($name);
            $regex = sprintf($REGEX_MATCH_YEAR, $name);
            preg_match($regex, $data, $matches);
            $content = $matches[1];

            $subjects = preg_split($REGEX_SPLIT_SUBJECT_INFORMATION, $content);
            
            foreach($subjects as $subject)
            {
                list($subject_name, $teacher_full_name, $type) = preg_split($REGEX_SPLIT_SUBJECT_DETAILS, $subject);

                $ranks = array();
                preg_match_all($REGEX_RANK_FROM_NAME, $teacher_full_name, $ranks);

                $names = preg_split($REGEX_RANK_FROM_NAME, $teacher_full_name);
                $filtered_names = array_values(array_filter($names, "is_empty"));

                foreach($filtered_names as $index=>$name)
                {
                    $name = ltrim(rtrim($name));

                    if(array_key_exists($name, $timetable_information) == false)
                    {   
                        if(count($ranks[0]) > 0)
                        {
                            $timetable_information[$name]['Rank'] = $ranks[0][$index];
                        }
                        else
                        {
                            $timetable_information[$name]['Rank'] = '';
                        }
                    }
                    
                    $timetable_information[$name]['Subjects'][$subject_name]['Year'] = $year;
                    $timetable_information[$name]['Subjects'][$subject_name][$type][] = 'I'.$year;
                }
            }
        }

        return $timetable_information;
    }