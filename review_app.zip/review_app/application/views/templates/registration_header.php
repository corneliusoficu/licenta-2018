<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?= $title ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="<?php echo assets_base_url()."assets/img/favicon.png"?>" type="image/png">

        <?php 
            css('general/bootstrap.min');
            css('general/select2.min');
            css('registration');
        ?>

        <?php
            js('general/jquery-3.2.1.min');
            js('general/popper.min');
            js('general/bootstrap.min');
            js('general/select2.min');
            js('registration');
        ?>
    </head>

    <body>
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div id="login-col" class="offset-lg-4 col-lg-4 h-100">
                    <div id="login-wrapper" class="flex-column align-items-center d-flex justify-content-center h-100">
                        <form id="login-form" method="POST" class="w-100" action="<?= $destination_url; ?>">
                            <div class="form-error">
                                <?php if(isset($error_messages)): ?>
                                    <?php foreach ($error_messages as $error_message): ?>
                                        <p>&#8226 <?= $error_message ?></p>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>