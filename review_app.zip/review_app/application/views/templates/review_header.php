<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?=$title?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo assets_base_url()."assets/img/favicon.png"?>" type="image/png">

    <script>
        const BASE_URL = '<?=base_url(); ?>';
    </script>

    <?php 
        css('general/bootstrap.min');
        css('general/global_layout');
        css('general/hamburgers.min');

        if(isset($resources))
        {
            load_css_resources($resources);
        }
        
    ?>
    
    <?php 
        js('general/jquery-3.2.1.min');
        js('general/popper.min');
        js('general/bootstrap.min'); 
        js('general/fontawesome-all.min');
        js('general/general-behaviour');

        if(isset($resources))
        {
            load_js_resources($resources);
        }
    ?>

</head>
<body>
<div class="container-fluid h-100 d-flex flex-column">
    <div class = "row" id="content-row">
        <div class="col-xl-2 col-lg-2" id="controls-column">
            <div class="d-flex flex-row justify-content-between nav-header-container">
                <a class = "align-self-center app-text" href="<?=base_url() . "evaluation/review"?>">Evaluare FII</a>
                <!-- <h3 class="align-self-center app-text">Evaluare FII</h3> -->
                <button class="hamburger hamburger--slider" type="button" aria-expanded="false">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
                
            </div>

            <div class="collapse" id="nav-menu">
                
                <ul id="menu-items-ul">
                    <?php if($this->authorization->has_permission('can_review')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>evaluation/review"><i class="fas fa-star mr-2"></i>Evaluare</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_view_student_statistics')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>statistics"><i class="fas fa-chart-line mr-2"></i>Statistici</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_see_own_results')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>professors/subject-results"><i class="fas fa-book mr-2"></i>Rezultate materii</a>
                        </li>
                    <?php endif ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>professors/faculty-results"><i class="fas fa-university mr-2"></i>Rezultate facultate</a>
                        </li>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>professors/professors-results"><i class="fas fa-chalkboard-teacher mr-2"></i>Rezultate cadre didactice</a>
                        </li>
                    <?php if($this->authorization->has_permission('can_modify_data')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>data"><i class="fas fa-database mr-2"></i>Date</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_generate_new_evaluation_period')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>generators"><i class="fas fa-plus-square mr-2"></i>Generatori</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_create_professor_accounts')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>professors/requests/pending"><i class="fas fa-user-circle mr-2"></i>Conturi Profesori</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_see_complaints')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>complaints"><i class="fa fa-envelope mr-2"></i>Mesaje</a>
                        </li>
                    <?php endif ?>
                    <?php if($this->authorization->has_permission('can_change_settings')): ?>
                        <li>
                            <a class="admin-sidebar-menu-item" href="<?=base_url()?>settings"><i class="fab fa-whmcs mr-2"></i>Setari</a>
                        </li>
                    <?php endif ?>
                </ul>
            </div>
        </div>

        <div class="col-lg-10" id="page-column">